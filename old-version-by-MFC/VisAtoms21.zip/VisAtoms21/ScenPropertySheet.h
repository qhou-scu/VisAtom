// ScenPropertySheet.h : header file
//
#include "PropertySceneVolume.h"
#include "PropertyActionOption.h"
#include "PropertyClipPlane1.h"

/////////////////////////////////////////////////////////////////////////////
// CScenPropertySheet

class CScenPropertySheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CScenPropertySheet)

// Construction
public:
	CScenPropertySheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CScenPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
     CPropertySceneVolume V;
	 CPropertyActionOption A;
	 CPropertyClipPlane1 C;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScenPropertySheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScenPropertySheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CScenPropertySheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
