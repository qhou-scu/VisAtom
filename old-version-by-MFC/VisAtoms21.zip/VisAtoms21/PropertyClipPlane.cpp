// PropertyClipPlane.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertyClipPlane.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane property page

IMPLEMENT_DYNCREATE(CPropertyClipPlane, CPropertyPage)

CPropertyClipPlane::CPropertyClipPlane() : CPropertyPage(CPropertyClipPlane::IDD)
{
	//{{AFX_DATA_INIT(CPropertyClipPlane)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropertyClipPlane::~CPropertyClipPlane()
{
}

void CPropertyClipPlane::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyClipPlane)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyClipPlane, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyClipPlane)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane message handlers
