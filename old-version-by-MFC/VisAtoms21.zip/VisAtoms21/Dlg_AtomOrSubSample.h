// Dlg_AtomOrSubSample.h : header file
//
#define operate_pickedatom    0
#define operate_unpickedatom  1
#define operate_allatom       2
#define operate_subsample     3
/////////////////////////////////////////////////////////////////////////////
// CDlg_AtomOrSubSample dialog

class CDlg_AtomOrSubSample : public CDialog
{
// Construction
public:
	CDlg_AtomOrSubSample(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_AtomOrSubSample)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:
	int choice;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_AtomOrSubSample)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_AtomOrSubSample)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
