// Dlg_CoordNumb.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_CoordNumb dialog
#include "WndGL_xyFig.h"
#include "Atoms21.h"

class CDlg_CoordNumb : public CDialog
{
// Construction
public:
	CDlg_CoordNumb(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_CoordNumb)
	enum { IDD = IDD_COORDNUMB };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_CoordNumb)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_CoordNumb)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckx();
	afx_msg void OnChecky();
	afx_msg void OnCheckz();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio7();
	afx_msg void OnRadio8();
	afx_msg void OnSelchangeAtom1();
	afx_msg void OnSelchangeAtom2();
	afx_msg void OnExit();
	afx_msg void OnButtonStart();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	CWndGL_xyFig Fig;
    CWinThread*Kernal;
    UINT nIDEvent;
public:
	void ImportSample(Atoms21*);

};
