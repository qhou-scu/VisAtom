// Dlg_Choice.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_Choice.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_Choice dialog
CDlg_Choice::CDlg_Choice(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_Choice::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_Choice)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	choice = operate_copyselectedatom;
}


void CDlg_Choice::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_Choice)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_Choice, CDialog)
	//{{AFX_MSG_MAP(CDlg_Choice)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_Choice message handlers

BOOL CDlg_Choice::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(choice == operate_copyselectedatom)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO1);

	if(choice == operate_copysubsample)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO2);


	if(choice == operate_copysample)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO3);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_Choice::OnOK() 
{
	if(((CButton*) GetDlgItem(IDC_RADIO1))->GetCheck() ) 
	{
		choice = operate_copyselectedatom;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO2))->GetCheck() ) 
	{
		choice = operate_copysubsample;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO3))->GetCheck() ) 
	{
		choice = operate_copysample;
	}
	

	CDialog::OnOK();
}

