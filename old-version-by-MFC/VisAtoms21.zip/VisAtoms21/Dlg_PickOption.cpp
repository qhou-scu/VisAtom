// Dlg_PickOption.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_PickOption.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_PickOption dialog


CDlg_PickOption::CDlg_PickOption(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_PickOption::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_PickOption)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	choice = 0;
}


void CDlg_PickOption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_PickOption)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_PickOption, CDialog)
	//{{AFX_MSG_MAP(CDlg_PickOption)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_PickOption message handlers

BOOL CDlg_PickOption::OnInitDialog() 
{
	CDialog::OnInitDialog();
	switch (choice)
	{
	case atom_pick_Option_Single:
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO5, IDC_RADIO1);
	   break;

	case atom_pick_Option_Multiple:
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO5, IDC_RADIO2);
	   break;

	case atom_pick_Option_Subsample:
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO5, IDC_RADIO3);
	   break;

	case atom_pick_Option_Square:
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO5, IDC_RADIO4);
	   break;

	case atom_pick_Option_Tripoints:
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO5, IDC_RADIO5);
	   break;
   }
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_PickOption::OnOK() 
{

	CDialog::OnOK();
}

void CDlg_PickOption::OnRadio1() 
{
  choice = atom_pick_Option_Single;
	
}

void CDlg_PickOption::OnRadio2() 
{
   choice = atom_pick_Option_Multiple;
}

void CDlg_PickOption::OnRadio3() 
{
   choice = atom_pick_Option_Subsample;
	
}

void CDlg_PickOption::OnRadio4() 
{
   choice = atom_pick_Option_Square;
	
}

void CDlg_PickOption::OnRadio5() 
{
   choice = atom_pick_Option_Tripoints;
	
}
