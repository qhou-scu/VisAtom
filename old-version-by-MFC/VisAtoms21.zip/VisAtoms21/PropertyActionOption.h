// PropertyActionOption.h : header file
//
#include "Scene.h"

/////////////////////////////////////////////////////////////////////////////
// CPropertyActionOption dialog

class CPropertyActionOption : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyActionOption)

// Construction
public:
	CPropertyActionOption();
	~CPropertyActionOption();
public:
	int systemchoice;
	float zoomPercent;
	float rotationStepx, rotationStepy, rotationStepz;
	float itransStepx, itransStepy, itransStepz;

// Dialog Data
	//{{AFX_DATA(CPropertyActionOption)
	enum { IDD = IDD_PROPPAGE_SCENE1 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyActionOption)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyActionOption)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
