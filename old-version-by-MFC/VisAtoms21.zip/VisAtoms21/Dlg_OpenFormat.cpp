// Dlg_OpenFormat.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_OpenFormat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_OpenFormat dialog


CDlg_OpenFormat::CDlg_OpenFormat(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_OpenFormat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_OpenFormat)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	int i;
	nCol = 20;
	for(i=0; i<nCol; i++) flag[i] = i+1;
	strcpy(DataName,"");
	for(i=0; i<=1; i++) iCheck[i] = 1;
	for(i=2; i<6; i++) iCheck[i] = 0;
	iShowAgain = 0;
    iAutoGroup = 0; 
	iOpenContinue = 0;
}


void CDlg_OpenFormat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_OpenFormat)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_OpenFormat, CDialog)
	//{{AFX_MSG_MAP(CDlg_OpenFormat)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	ON_BN_CLICKED(IDC_CHECK4, OnCheck4)
	ON_BN_CLICKED(IDC_CHECK5, OnCheck5)
	ON_BN_CLICKED(IDC_CHECK6, OnCheck6)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_CHECK7, OnCheck7)
	ON_BN_CLICKED(IDC_CHECK8, OnCheck8)
	ON_BN_CLICKED(IDC_CHECK9, OnCheck9)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_OpenFormat message handlers
extern "C" { 
           void __stdcall NUMBEROFCOLUME(char*, int*);
           void __stdcall NUMBEROFLINE(char*, int*);
		   void __stdcall READBYCOLUME(char*, int*, int*, int*, int*,int*,int*);
            }

BOOL CDlg_OpenFormat::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	char str[80];

   ((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(iCheck[0]);
   ((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(iCheck[1]);
   ((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(iCheck[2]);
   ((CButton*)GetDlgItem(IDC_CHECK4))->SetCheck(iCheck[3]);
   ((CButton*)GetDlgItem(IDC_CHECK5))->SetCheck(iCheck[4]);
   ((CButton*)GetDlgItem(IDC_CHECK6))->SetCheck(iCheck[5]);

  
   if(iCheck[0])
   {
     sprintf(str,"TYPE      = Column %i",flag[0]);
     ((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(iCheck[1])
   {
	sprintf(str,"POSITION:  X = Column %i",flag[1]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"           Y = Column %i",flag[2]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"           Z = Column %i",flag[3]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(iCheck[2])
   {
	sprintf(str,"VELOCITY: Vx = Column %i",flag[4]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          Vy = Column %i",flag[5]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          Vz = Column %i",flag[6]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(iCheck[3])
   {
	sprintf(str,"FORCE: Fx = Column %i",flag[7]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          Fy = Column %i",flag[8]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          Fz = Column %i",flag[9]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(iCheck[4])
   {
	sprintf(str,"COLOR:    R = Column %i",flag[10]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          G = Column %i",flag[11]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"          B = Column %i",flag[12]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	GetDlgItem(IDC_CHECK9)->ShowWindow(SW_SHOW);
   }
   else
   {
	GetDlgItem(IDC_CHECK9)->ShowWindow(SW_HIDE);
   }

   if(iCheck[5])
   {
	sprintf(str,"RADIU:     r = Column %i",flag[13]);
  	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }

//	if(strlen(DataName) > 0)
//	  NUMBEROFCOLUME(DataName, &nCol);
//	else
//      nCol = 14;
	if(strlen(DataName) <= 0) nCol = 14;

	int i;
	for(i=0; i<20; i++) tflag[i] = flag[i];
	for(i=0; i<nCol; i++)
	{
	   sprintf(str,"Column %i",i+1);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
    }

	SetDlgItemText(IDC_EDIT1,DataName);

	if(iAutoGroup)    ((CButton*)GetDlgItem(IDC_CHECK9))->SetCheck(1);
	else 			  ((CButton*)GetDlgItem(IDC_CHECK9))->SetCheck(0);

	if(iOpenContinue) ((CButton*)GetDlgItem(IDC_CHECK8))->SetCheck(1);
	else 			  ((CButton*)GetDlgItem(IDC_CHECK8))->SetCheck(0);

	if(iShowAgain)    ((CButton*)GetDlgItem(IDC_CHECK7))->SetCheck(1);
	else              ((CButton*)GetDlgItem(IDC_CHECK7))->SetCheck(0);
	


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_OpenFormat::OnCheck1() 
{
   int ifCheck[6];
   char str[80];

   if( ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck()) ifCheck[0] = 1;
   else  ifCheck[0] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck()) ifCheck[1] = 1;
   else	 ifCheck[1] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK3))->GetCheck()) ifCheck[2] = 1;
   else  ifCheck[2] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK4))->GetCheck()) ifCheck[3] = 1;
   else  ifCheck[3] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK5))->GetCheck()) ifCheck[4] = 1;
   else  ifCheck[4] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK6))->GetCheck()) ifCheck[5] = 1;
   else  ifCheck[5] = 0;

   ((CListBox*)GetDlgItem(IDC_LIST2))->ResetContent();
   if(ifCheck[0])
   {
     sprintf(str,"TYPE = Column %i",tflag[0]);
     ((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(ifCheck[1])
   {
	sprintf(str,"X = Column %i",tflag[1]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Y = Column %i",tflag[2]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Z = Column %i",tflag[3]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(ifCheck[2])
   {
	sprintf(str,"Vx = Column %i",tflag[4]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Vy = Column %i",tflag[5]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Vz = Column %i",tflag[6]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(ifCheck[3])
   {
	sprintf(str,"Fx = Column %i",tflag[7]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Fy = Column %i",tflag[8]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"Fz = Column %i",tflag[9]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }
   if(ifCheck[4])
   {
	sprintf(str,"R = Column %i",tflag[10]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"G = Column %i",tflag[11]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	sprintf(str,"B = Column %i",tflag[12]);
	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);

	GetDlgItem(IDC_CHECK9)->ShowWindow(SW_SHOW);
   }
   else
   {
	GetDlgItem(IDC_CHECK9)->ShowWindow(SW_HIDE);
   }

   if(ifCheck[5])
   {
	 sprintf(str,"r = Column %i",tflag[13]);
  	((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   }

}

void CDlg_OpenFormat::OnCheck2() 
{
    OnCheck1();	
}

void CDlg_OpenFormat::OnCheck3() 
{
    OnCheck1();	
}

void CDlg_OpenFormat::OnCheck4() 
{
    OnCheck1();	

}

void CDlg_OpenFormat::OnCheck5() 
{
    OnCheck1();	
}

void CDlg_OpenFormat::OnCheck6() 
{
    OnCheck1();	
}

void CDlg_OpenFormat::OnButton1() 
{
	int i, j,k,l, n;
	i = ((CListBox*)GetDlgItem(IDC_LIST1))->GetCurSel()+1;
	if(i<1) return;
	n = ((CListBox*)GetDlgItem(IDC_LIST2))->GetCurSel()+1;
	if(n<1) return;

	k = 0;
	l = n;
    if( ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k++;

    if( ((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k+=3;

    if( ((CButton*)GetDlgItem(IDC_CHECK3))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k+=3;

    if( ((CButton*)GetDlgItem(IDC_CHECK4))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k+=3;

    if( ((CButton*)GetDlgItem(IDC_CHECK5))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k+=3;

    if( ((CButton*)GetDlgItem(IDC_CHECK6))->GetCheck() )
	{
	  k ++;
	  l --;
	  if(l == 0) j = k;
	}
	else k++;

    j--;

    tflag[j] = i;

    OnCheck1();	

	((CListBox*)GetDlgItem(IDC_LIST2))->SetCurSel(n-1);
}

void CDlg_OpenFormat::OnOK() 
{
   int i;
   if( ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck()) iCheck[0] = 1;
   else  iCheck[0] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck()) iCheck[1] = 1;
   else	 iCheck[1] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK3))->GetCheck()) iCheck[2] = 1;
   else  iCheck[2] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK4))->GetCheck()) iCheck[3] = 1;
   else  iCheck[3] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK5))->GetCheck()) iCheck[4] = 1;
   else  iCheck[4] = 0;
   if( ((CButton*)GetDlgItem(IDC_CHECK6))->GetCheck()) iCheck[5] = 1;
   else  iCheck[5] = 0;

   if(iCheck[0])
   {
	 if(tflag[0] > nCol) goto ERRORFORMAT;
   }
   if(iCheck[1])
   {
	 if(tflag[1] > nCol) goto ERRORFORMAT;
	 if(tflag[2] > nCol) goto ERRORFORMAT;
	 if(tflag[3] > nCol) goto ERRORFORMAT;
   }
   if(iCheck[2])
   {
	 if(tflag[4] > nCol) goto ERRORFORMAT;
	 if(tflag[5] > nCol) goto ERRORFORMAT;
	 if(tflag[6] > nCol) goto ERRORFORMAT;
   }
   if(iCheck[3])
   {
	 if(tflag[7] > nCol) goto ERRORFORMAT;
	 if(tflag[8] > nCol) goto ERRORFORMAT;
	 if(tflag[9] > nCol) goto ERRORFORMAT;
   }
   if(iCheck[4])
   {
	 if(tflag[10] > nCol) goto ERRORFORMAT;
	 if(tflag[11] > nCol) goto ERRORFORMAT;
	 if(tflag[12] > nCol) goto ERRORFORMAT;
   }
   if(iCheck[5])
   {
	 if(tflag[13] > nCol) goto ERRORFORMAT;
   }

   for(i=0; i<20; i++) flag[i] = tflag[i];
	
	CDialog::OnOK();
	return;

ERRORFORMAT:
	MessageBox("Required Column of data is unavailable.", "Error", MB_OK|MB_ICONEXCLAMATION);
	return;
}

void CDlg_OpenFormat::OnCheck7() 
{
   if( ((CButton*)GetDlgItem(IDC_CHECK7))->GetCheck()) iShowAgain = 1;
   else  iShowAgain = 0;
	
}

void CDlg_OpenFormat::OnCheck8() 
{
   if( ((CButton*)GetDlgItem(IDC_CHECK8))->GetCheck()) iOpenContinue = 1;
   else  iOpenContinue = 0;
	
}

void CDlg_OpenFormat::OnCheck9() 
{
   if( ((CButton*)GetDlgItem(IDC_CHECK9))->GetCheck()) iAutoGroup = 1;
   else  iAutoGroup = 0;
	
	
}
