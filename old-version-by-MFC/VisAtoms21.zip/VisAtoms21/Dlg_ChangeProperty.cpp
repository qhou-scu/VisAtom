// Dlg_ChangeProperty.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_ChangeProperty.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_ChangeProperty dialog


CDlg_ChangeProperty::CDlg_ChangeProperty(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_ChangeProperty::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_ChangeProperty)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	R = NULL;
	G = NULL;
	B = NULL;
	A = NULL;
	r = NULL;
	style = NULL;
	style0 = 1;
    m_Sample = NULL;
	curID = 0;
}


void CDlg_ChangeProperty::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_ChangeProperty)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_ChangeProperty, CDialog)
	//{{AFX_MSG_MAP(CDlg_ChangeProperty)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_CBN_SELCHANGE(IDC_COMBO3, OnSelchangeCombo3)
	ON_CBN_SELCHANGE(IDC_COMBO2, OnSelchangeCombo2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_ChangeProperty message handlers

BOOL CDlg_ChangeProperty::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

    int i, n, I;
	char str[80];
	n = m_Sample->GetNumb_of_subSample()-1;
	R = new float[n];
	G = new float[n];
	B = new float[n];
	A = new float[n];
	r = new float[n];
	style = new int[n];

	CComboBox*p1 = (CComboBox*)GetDlgItem(IDC_COMBO3);
	for(i=0; i<n; i++)
	{
	  I = m_Sample->GetTypeSubSampleAssignTo(i+1);
	  m_Sample->GetStyle_subSample(I, &style[i]);
	  m_Sample->GetColor_subSample(I, &R[i], &G[i], &B[i], &A[i]);
	  sprintf(str, "Atoms of type %i",I);
	  p1->AddString(str);
	}
	curID = 0;
	p1->SetCurSel(curID);

    p1 = (CComboBox*)GetDlgItem(IDC_COMBO2);
	p1->AddString("DOT");
	p1->AddString("CIRCLE");
	p1->AddString("WIRE");
	p1->AddString("SOLID");
	p1->AddString("Velocity(wire)");
	p1->AddString("Velocity(solid)");
	p1->AddString("Force(wire)");
	p1->AddString("Force(solid)");

	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(R[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	p->SetRangeMax(200, TRUE);
 	p->SetPos((int)(G[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(B[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(A[curID]*200));

	frontColor.Set(R[curID], G[curID], B[curID],1.f);
	frontColor.Back(bR, bG, bB,1.f);

	RECT rect;
	GetClientRect(&rect);
	rect.right = rect.right-20;
	rect.top   = rect.top  +145;
	rect.left  = rect.right-48;
	rect.bottom  = rect.top+48;
	frontColor.Create(NULL,NULL, WS_VISIBLE|WS_CHILD| WS_CLIPCHILDREN | WS_CLIPSIBLINGS, rect, this, 0, NULL);


	style0 = m_Sample->GetStyle();
	if( (style0&style_mask) == style_SubSamples)
	{
	  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
	  GetDlgItem(IDC_COMBO3)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER1)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER2)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER3)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER4)->EnableWindow(TRUE);
	  p1->SetCurSel(style[curID]-1);
 	  frontColor.Object(style[curID]);
	  //
	  GetDlgItem(IDC_CHECK1)->EnableWindow(FALSE);
	  GetDlgItem(IDC_CHECK2)->EnableWindow(FALSE);

	}
	else
	{
	  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
	  GetDlgItem(IDC_COMBO3)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER1)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER2)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER3)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER4)->EnableWindow(FALSE);
	  p1->SetCurSel((style0&style_mask)-1);
 	  frontColor.Object(style0);
	  
	  GetDlgItem(IDC_CHECK1)->EnableWindow(TRUE);
	  GetDlgItem(IDC_CHECK2)->EnableWindow(TRUE);
    }

	if(style0&style_Independent_radiu) 
		((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(1);
	else 
		((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(0);

	if(style0&style_Independent_color) 
		((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(1);
	else 
		((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(0);

	if(!m_Sample->ifHasRadiu() ) 
		GetDlgItem(IDC_CHECK1)->EnableWindow(FALSE);
	if(!m_Sample->ifHasColor() ) 
		GetDlgItem(IDC_CHECK2)->EnableWindow(FALSE);

	style0 = style0&style_mask;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_ChangeProperty::OnRadio1() 
{
	  if ( ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck() )
	  {
	  GetDlgItem(IDC_COMBO3)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER1)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER2)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER3)->EnableWindow(TRUE);
	  GetDlgItem(IDC_SLIDER4)->EnableWindow(TRUE);
	  ((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(style[curID]-1);

	  GetDlgItem(IDC_CHECK1)->EnableWindow(FALSE);
	  GetDlgItem(IDC_CHECK2)->EnableWindow(FALSE);

      OnSelchangeCombo2();
	  }
	
}

void CDlg_ChangeProperty::OnRadio2() 
{
	  if ( ((CButton*)GetDlgItem(IDC_RADIO2))->GetCheck() )
	  {
	  GetDlgItem(IDC_COMBO3)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER1)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER2)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER3)->EnableWindow(FALSE);
	  GetDlgItem(IDC_SLIDER4)->EnableWindow(FALSE);
	  ((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel( (style0&style_mask)-1);

	  GetDlgItem(IDC_CHECK1)->EnableWindow(TRUE);
	  GetDlgItem(IDC_CHECK2)->EnableWindow(TRUE);
    

/*	  if(style0&style_Independent_radiu) 
		 ( (CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(1);
	  else 
		 ( (CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(0);

	  if(style0&style_Independent_color) 
		 ( (CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(1);
	  else 
		 ( (CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(0);
  */
	  if(!m_Sample->ifHasRadiu() ) 
		GetDlgItem(IDC_CHECK1)->EnableWindow(FALSE);
	  if(!m_Sample->ifHasColor() ) 
		GetDlgItem(IDC_CHECK2)->EnableWindow(FALSE);

      OnSelchangeCombo2();
	  }
}

void CDlg_ChangeProperty::OnSelchangeCombo3() 
{
	
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	R[curID] = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	G[curID] = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	B[curID] = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	A[curID] = p->GetPos()/200.f;
	style[curID] = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel()+1;

	
	CComboBox*p1 = (CComboBox*)GetDlgItem(IDC_COMBO3);
	curID = p1->GetCurSel();
    p1 = (CComboBox*)GetDlgItem(IDC_COMBO2);
	p1->SetCurSel(style[curID]-1);

	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	//p->SetRangeMax(200, TRUE);
	p->SetPos((int)(R[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	//p->SetRangeMax(200, TRUE);
 	p->SetPos((int)(G[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	//p->SetRangeMax(200, TRUE);
	p->SetPos((int)(B[curID]*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	//p->SetRangeMax(200, TRUE);
	p->SetPos((int)(A[curID]*200));

	frontColor.ReSet(R[curID], G[curID], B[curID],1.f);
	frontColor.ResetObject(style[curID]);
}


void CDlg_ChangeProperty::OnOK() 
{

    int i, n, I;
	int flag;

    OnSelchangeCombo3();

	flag = 0;
	if( ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck() )
	{

	  n = m_Sample->GetNumb_of_subSample()-1;
	  //To check if there unavaible variables
	  for(i=0; i<n; i++)
	  {
		if( (style[i] == style_SubSample_WireVelocity) || (style[i] == style_SubSample_SolidVelocity))
			if(!m_Sample->ifHasVelocity()) 
			{
			 flag++;
			 MessageBox("No velocity information available", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 break;
			}

		if( (style[i] == style_SubSample_WireForce ) || (style[i] == style_SubSample_SolidForce ))
			if(!m_Sample->ifHasForce())
			{
			 flag++;
			 MessageBox("No force information available", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 break;
			}
		}
	  
	  //
	  if(!flag) 
	  {
	    m_Sample->SetStyle(0);

	    CComboBox*p1 = (CComboBox*)GetDlgItem(IDC_COMBO3);
	    for(i=0; i<n; i++)
	    {
	      I = m_Sample->GetTypeSubSampleAssignTo(i+1);
	      m_Sample->ChangeStyle_subSample(I, style[i]);
	      m_Sample->ChangeColor_subSample(I, R[i], G[i], B[i], A[i]);
	    }
	   }
	}
	else
	{
	  if( ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() ) 
		  style0 = style0|style_Independent_radiu;
	  if( ((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck() ) 
		  style0 = style0|style_Independent_color;

	  if(style0&style_Independent_color)
			if(!m_Sample->ifHasColor()) 
			{
			 flag++;
			 MessageBox("No color information for each atom", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 goto Error100;
			}
	  if(style0&style_Independent_radiu)
			if(!m_Sample->ifHasRadiu()) 
			{
			 flag++;
			 MessageBox("No radiu information for each atom", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 goto Error100;
			}
	  if( ((style0&style_mask) == style_Velocity_Wire) ||( (style0&style_mask) == style_Velocity_Solid))
			if(!m_Sample->ifHasVelocity()) 
			{
			 flag++;
			 MessageBox("No velocity information availabe", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 goto Error100;
			}
	  if( ( (style0&style_mask) == style_Force_Wire) || ( (style0&style_mask) == style_Force_Solid))
			if(!m_Sample->ifHasForce()) 
			{
			 flag++;
			 MessageBox("No force information availabe", "Error", MB_OK|MB_ICONEXCLAMATION); 
			 goto Error100;
			}


	  if(!flag) m_Sample->SetStyle(style0);
	}

Error100:
	delete R;
	delete G;
	delete B;
	delete A;
	delete r;
	delete style;

	frontColor.DestroyWindow();

	CDialog::OnOK();
}

void CDlg_ChangeProperty::OnSelchangeCombo2() 
{
  if ( ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck() )
  {
   style[curID] = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel()+1;
   frontColor.ResetObject(style[curID]);
  }
  else
  {
   style0  = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel()+1;
   frontColor.ResetObject(style0);
  }
}


BOOL CDlg_ChangeProperty::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	float r, g, b, a;
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	r = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	g = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	b = p->GetPos()/200.f;
	p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	a = p->GetPos()/200.f;
	frontColor.ReSet(r, g, b, a);

	return CDialog::OnNotify(wParam, lParam, pResult);
}

void CDlg_ChangeProperty::OnCancel() 
{
   frontColor.DestroyWindow();

	CDialog::OnCancel();
}
