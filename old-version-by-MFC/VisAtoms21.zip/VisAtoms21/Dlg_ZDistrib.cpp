// Dlg_ZDistrib.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_ZDistrib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_ZDistrib dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SET_ANALYSISDATA(int*,int*,float*,float*,float*);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);
             void __stdcall SETBINS_ZDISTRIB(int*);
             void __stdcall GETBINS_ZDISTRIB(int*);
			 void __stdcall SETMTHICK_ZDISTRIB(float*);
			 void __stdcall GETMTHICK_ZDISTRIB(float*);
			 void __stdcall GETTHICK_ZDISTRIB(float*);
             void __stdcall SETTYPE_ZDISTRIB(int*);
             void __stdcall GETTYPE_ZDISTRIB(int*);
             void __stdcall CAL_ZDISTRIBALL();
			 void __stdcall CAL_ZDISTRIB11();
             void __stdcall CAL_ZDISTRIBLAYERALL();
			 void __stdcall CAL_ZDISTRIBLAYER11();
             void __stdcall GETVALUE_ZDISTRIB(int*, int*,float*, float*);
             void __stdcall END_ZDISTRIB();
             void __stdcall RELEASE_ANALYSISDATA();
          }

CDlg_ZDistrib::CDlg_ZDistrib(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_ZDistrib::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_ZDistrib)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CDlg_ZDistrib::~CDlg_ZDistrib()
{
}

void CDlg_ZDistrib::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_ZDistrib)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_ZDistrib, CDialog)
	//{{AFX_MSG_MAP(CDlg_ZDistrib)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_WM_SIZE()
	ON_CBN_SELCHANGE(IDC_ATOM1, OnSelchangeAtom1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_ZDistrib message handlers

BOOL CDlg_ZDistrib::OnInitDialog() 
{
	CDialog::OnInitDialog();

	RECT rect,rect1;
	int W, H, L, L1;
	this->GetWindowRect(&rect);
	GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;

	Fig.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rect,this,0,NULL);

	float temp;
	int    itemp;
	char str[32];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);

    GETBINS_ZDISTRIB(&itemp);
	sprintf(str,"%i",itemp);
	SetDlgItemText(IDC_EDIT2, str);

    GETMTHICK_ZDISTRIB(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDIT3, str);

    OnRadio1(); 
    OnRadio3(); 

	int i,n;
	GETGROUPNUMB(&n);
	for(i=1;i<=n; i++)
	{
	  sprintf(str,"%i",i);
	  ((CComboBox*)GetDlgItem(IDC_ATOM1))->AddString(str);
	}
    GETTYPE_ZDISTRIB(&i);
	sprintf(str,"%i",i);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM1))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM1))->SetCurSel(i);

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlg_ZDistrib::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  SET_ANALYSISDATA(&nxyz,ityp,x,y,z);
}

void CDlg_ZDistrib::OnRadio1() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
  GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
	
}

void CDlg_ZDistrib::OnRadio2() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
  GetDlgItem(IDC_ATOM1)->EnableWindow(TRUE);

}

void CDlg_ZDistrib::OnChangeEdit2() 
{
  char str[32];
  int err;

  GetDlgItemText(IDC_EDIT2, str,32);
  err = atoi(str);
  if(err <= 0)
  {
	  MessageBox("Warning", "The number of bins smaller than zero", MB_OK);
      GETBINS_ZDISTRIB(&err);	
	  sprintf(str,"%i",err);
      SetDlgItemText(IDC_EDIT2, str);
	  return;
  }
  SETBINS_ZDISTRIB(&err);	
}


void CDlg_ZDistrib::OnExit() 
{
	CDialog::OnOK();
	
}

void CDlg_ZDistrib::OnButtonStart() 
{
	//*** to get the lattice unit
    char str[32];
    float t;
    int err;

    GetDlgItemText(IDC_EDITLU, str,32);
    GETVALUE(str, &t, &err);
    if(t<= 0.f) 
    {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
    }
    SETLATTICEPARA(&t);
	//*** to get the thick
    GetDlgItemText(IDC_EDIT3, str,32);
    GETVALUE(str,&t,&err);
    if(t <= 0.f)
    {
	  MessageBox("Warning", "The thickness of a monolayer smaller than zero", MB_OK);
      GETMTHICK_ZDISTRIB(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDIT3, str);
	  return;
    }
    SETMTHICK_ZDISTRIB(&t);	
	//To start calculation
	float*ZZ, *D;
	int bins,i;

	GETBINS_ZDISTRIB(&bins);
	if(bins == 0) return;
    ZZ = new float[bins];
    D = new float[bins];

	LoadCursor(AfxGetInstanceHandle( ),IDC_WAIT);

    if(IsDlgButtonChecked(IDC_RADIO1)  )
	{
       GetDlgItem(IDC_PROMPT)->SetWindowText("Calculation started...");
       if(IsDlgButtonChecked(IDC_RADIO3))
          CAL_ZDISTRIBALL();
       else
	     {
          CAL_ZDISTRIBLAYERALL();
	     }
	}
	else
	{
       i =( (CComboBox*)GetDlgItem(IDC_ATOM1))->GetCurSel()+1;
       GetDlgItem(IDC_PROMPT)->SetWindowText("Calculation started...");
       if(IsDlgButtonChecked(IDC_RADIO3))
          CAL_ZDISTRIB11();
       else
	     {
          CAL_ZDISTRIBLAYER11();
	     }
	}
    GetDlgItem(IDC_PROMPT)->SetWindowText("");

	//Fig.DeleteFig();
	int FLAG;
    if(IsDlgButtonChecked(IDC_RADIO3))
	{
	  GETVALUE_ZDISTRIB(&FLAG,&bins,ZZ,D);
	  Fig.NewCurve(0, bins, ZZ, D);
	}
	else
	{
	  GETVALUE_ZDISTRIB(&FLAG,&bins,ZZ,D);
      Fig.NewCurve(3, bins, ZZ, D);
     }

	Fig.AutoYRange();
	float thick, alta,temp;
    GETTHICK_ZDISTRIB(&thick);
	GETLATTICEPARA(&alta);
	temp = ((int)(thick/alta) + 1);
	Fig.ChangeXRange(0.f, temp*alta);
	if(temp > 5) temp = 5;
    Fig.ChangeXAxsis_nTick((int)temp);
 	Fig.CreateXAxsisLabel("%5.2f");
    Fig.ChangeXLabelScal(0.07f, 0.08f);
	Fig.CreateXTitle("Z (in lattice unit)");
    Fig.CreateYTitle("D(Z) (in arb.unit)");

	delete ZZ;
	delete D;
	
}

void CDlg_ZDistrib::OnDestroy() 
{
    END_ZDISTRIB();
    RELEASE_ANALYSISDATA();
	CDialog::OnDestroy();
	
}

void CDlg_ZDistrib::OnRadio3() 
{
  CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO3);
	
}

void CDlg_ZDistrib::OnRadio4() 
{
  CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO4);
}


void CDlg_ZDistrib::OnOK() 
{
	OnButtonStart();

}

void CDlg_ZDistrib::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_FIGFRAME) != NULL)
	{
	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 Fig.MoveWindow(&rect, TRUE);
	}
	
}

void CDlg_ZDistrib::OnSelchangeAtom1() 
{
	int i = ((CComboBox*)GetDlgItem(IDC_ATOM1))->GetCurSel()+1;
    SETTYPE_ZDISTRIB(&i);
}
