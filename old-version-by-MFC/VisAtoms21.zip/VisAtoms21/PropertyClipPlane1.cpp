// PropertyClipPlane1.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertyClipPlane1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane1 property page

IMPLEMENT_DYNCREATE(CPropertyClipPlane1, CPropertyPage)

CPropertyClipPlane1::CPropertyClipPlane1() : CPropertyPage(CPropertyClipPlane1::IDD)
{
	//{{AFX_DATA_INIT(CPropertyClipPlane1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	iclipStep[0] = 0.f;
	iclipStep[1] = 0.f;
	iclipStep[2] = 0.f;

	iclipThick[0]= 0.f;
	iclipThick[1]= 0.f;
	iclipThick[2]= 0.f;
	clipState[0] = 0;
	clipState[1] = 0;
	clipState[2] = 0;
}

CPropertyClipPlane1::~CPropertyClipPlane1()
{
}

void CPropertyClipPlane1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyClipPlane1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyClipPlane1, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyClipPlane1)
	ON_BN_CLICKED(IDC_CHECK11, OnCheck11)
	ON_BN_CLICKED(IDC_CHECK12, OnCheck12)
	ON_BN_CLICKED(IDC_CHECK13, OnCheck13)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane1 message handlers

void CPropertyClipPlane1::OnCheck11() 
{
    int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
    
    int flag = ((CButton*)GetDlgItem(IDC_CHECK11))->GetCheck();
	if(flag) clipState[i] = clipState[i]|1;
	else 
	{	int t = clipState[i];
	    t = clipState[i]>>1;
		clipState[i] = t<<1;
	}

	if((clipState[i]&1) == 0)
	{
	   ((CButton*)GetDlgItem(IDC_CHECK11))->SetCheck(FALSE);
	   GetDlgItem(IDC_CHECK12)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECK13)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_SPIN1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_SPIN2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
    }
	else
	{
	   //pair clipplane
	   GetDlgItem(IDC_CHECK13)->EnableWindow(TRUE);
	   if( clipState[i] &2) 
	   {
	      GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
	      GetDlgItem(IDC_SPIN1)->EnableWindow(TRUE);
	   }
	   else
	   {
	      GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	      GetDlgItem(IDC_SPIN1)->EnableWindow(FALSE);
	   }

       //To enable the incerement
	   GetDlgItem(IDC_EDIT2)->EnableWindow(TRUE);
	   GetDlgItem(IDC_SPIN2)->EnableWindow(TRUE);

	   //if shown
	   GetDlgItem(IDC_CHECK12)->EnableWindow(TRUE);
	   if( clipState[i]&8) 
	   {
	      GetDlgItem(IDC_RADIO1)->EnableWindow(TRUE);
	      GetDlgItem(IDC_RADIO2)->EnableWindow(TRUE);
	   }
	   else
	   {
	      GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	      GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	   }

	 }	
}

void CPropertyClipPlane1::OnCheck12() 
{
	   //if shown
       int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

       if( ((CButton*)GetDlgItem(IDC_CHECK12))->GetCheck() ) 
	   {
		  clipState[i] = clipState[i]|8; 
	      GetDlgItem(IDC_RADIO1)->EnableWindow(TRUE);
	      GetDlgItem(IDC_RADIO2)->EnableWindow(TRUE);
	   }
	   else
	   {
		   int t1 = clipState[i]&1;
		   int t2 = clipState[i]&2;
		   int t3 = clipState[i]&4;
		   int t = clipState[i]>>4;
           clipState[i] = t<<4;
		   clipState[i] = clipState[i]|t1|t2|t3;
	       GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	       GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	   }	
}

void CPropertyClipPlane1::OnCheck13() 
{
	   //pair clipplane
       int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

       if( ((CButton*)GetDlgItem(IDC_CHECK13))->GetCheck() ) 
	   {
		  clipState[i] = clipState[i]|2; 
	      GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
	      GetDlgItem(IDC_SPIN1)->EnableWindow(TRUE);
	   }
	   else
	   {
		   int t = clipState[i]>>2;
           clipState[i] = t<<2;
		   clipState[i] = clipState[i]|1;
	       GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	       GetDlgItem(IDC_SPIN1)->EnableWindow(FALSE);
	   }	
}

BOOL CPropertyClipPlane1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
    ((CComboBox*)GetDlgItem(IDC_COMBO1))->AddString("Clip in X direction");	
    ((CComboBox*)GetDlgItem(IDC_COMBO1))->AddString("Clip in Y direction");	
    ((CComboBox*)GetDlgItem(IDC_COMBO1))->AddString("Clip in Z direction");	
    ((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);
	
     OnSelchangeCombo1();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropertyClipPlane1::OnSelchangeCombo1() 
{
    int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if((clipState[i]&1) == 0 && (clipState[i]&2) == 0) 
		((CButton*)GetDlgItem(IDC_CHECK11))->SetCheck(FALSE);
	else ((CButton*)GetDlgItem(IDC_CHECK11))->SetCheck(TRUE);


    if( clipState[i] &2) 
	    ((CButton*)GetDlgItem(IDC_CHECK13))->SetCheck(TRUE);
	else
	    ((CButton*)GetDlgItem(IDC_CHECK13))->SetCheck(FALSE);

     //if shown
	 if( clipState[i]&8) 
	     ((CButton*)GetDlgItem(IDC_CHECK12))->SetCheck(TRUE);
	 else
	     ((CButton*)GetDlgItem(IDC_CHECK12))->SetCheck(FALSE);

	 char str[40];
     sprintf(str, "%-5.1f",iclipThick[i]);
	 SetDlgItemText(IDC_EDIT1, str);
     sprintf(str, "%-5.1f",iclipStep[i]);
	 SetDlgItemText(IDC_EDIT2, str);

     OnCheck11();	
}


void CPropertyClipPlane1::OnChangeEdit1() 
{
    int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	char str[64];

	GetDlgItemText(IDC_EDIT1, str, 64);
    iclipThick[i] = atof(str);
	
}

void CPropertyClipPlane1::OnChangeEdit2() 
{
    int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	char str[64];

	GetDlgItemText(IDC_EDIT2, str, 64);
    iclipStep[i] = atof(str);
}

void CPropertyClipPlane1::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CPropertyPage::OnOK();
}
