#include "stdafx.h"
#include <Glc.h>
#include <math.h>

#include "Sample.h"


//*** to calculate the density of the sample
double Sample::CalDensity_Sample()
{
	// i: the index of subsample
	if(curActive) 
	{
 	  int i;
	  if(x == NULL) return 0;
	  double den = 0.0;
   	  for(i=0; i<nxyz; i++)
	  	 if(!(astatu[i]&atom_Statu_Deleted)) den = den + 1.0;
	  
	  den = den /(sizex*sizey*sizez);
	  return den;
	}
	else
	{
	  if(next == NULL) return 0;
      return next->CalDensity_Sample();
	}

}

//*** to calculate the number density of selected atoms
double Sample::CalDensity_Selected()
{
	// i: the index of subsample
	if(curActive) 
	{
 	  int i, flag;
	  double xl, yl, zl, xl1, yl1, zl1;

	  if(x == NULL) return 0;
	  double den = 0.0;
   	  for(i=0; i<nxyz; i++)
		if(astatu[i]&atom_Statu_Selected)
	    {
	  	 if(!(astatu[i]&atom_Statu_Deleted)) den = den + 1.0;
	    }

	  //to calculate the size
	  flag = 0;
	  for(i=0; i<nxyz; i++)
	  {
		if(astatu[i]&atom_Statu_Selected)
		{
		 if(!flag)
		  {
	  	    xl  = x[i];
	        xl1 = x[i];
	  	    yl  = y[i];
	        yl1 = y[i];
	  	    zl  = z[i];
	        zl1 = z[i];
			flag = 1;
		  }
		  else
		  {
	       if(xl  >  x[i]) xl  = x[i];
	       if(xl1 <  x[i]) xl1 = x[i];
	       if(yl  >  y[i]) yl  = y[i];
	       if(yl1 <  y[i]) yl1 = y[i];
	       if(zl  >  z[i]) zl  = z[i];
	       if(zl1 <  z[i]) zl1 = z[i];
		  }
		  den = den + 1.0;
		}
	  }

	  if(den == 1.0) return 1;
	  if( (xl1-xl)*(yl1-yl)*(zl1-zl) <= 0.f) return 0;
	  return den / ((xl1-xl)*(yl1-yl)*(zl1-zl));
	}
	else
	{
	  if(next == NULL) return 0;
      return next->CalDensity_Selected();
	}

}
