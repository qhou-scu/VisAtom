// Dlg_SFactor.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_SFactor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_SFactor dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SET_ANALYSISDATA(int*,int*,float*,float*,float*);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);

             void __stdcall SETCOORD_SFACTOR(int*, int*);
             void __stdcall GETCOORD_SFACTOR(int*, int*, int*);
             void __stdcall SETKVECTOR_SFACTOR(int*);
             void __stdcall GETKVECTOR_SFACTOR(int*);
             void __stdcall CAL_SFACTOR();
             void __stdcall GETVALUE_SFACTOR(int*,float*,float*);
             void __stdcall END_SFACTOR();
             void __stdcall RELEASE_ANALYSISDATA();

           }

CDlg_SFactor::CDlg_SFactor(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_SFactor::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_SFactor)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg_SFactor::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_SFactor)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_SFactor, CDialog)
	//{{AFX_MSG_MAP(CDlg_SFactor)
	ON_EN_CHANGE(IDC_EDITLU, OnChangeEditlu)
	ON_EN_CHANGE(IDC_EDITX1, OnChangeEditx1)
	ON_EN_CHANGE(IDC_EDITY1, OnChangeEdity1)
	ON_EN_CHANGE(IDC_EDITX2, OnChangeEditx2)
	ON_EN_CHANGE(IDC_EDITY2, OnChangeEdity2)
	ON_EN_CHANGE(IDC_EDITZ1, OnChangeEditz1)
	ON_EN_CHANGE(IDC_EDITZ2, OnChangeEditz2)
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_EN_CHANGE(IDC_EDITX4, OnChangeEditx4)
	ON_EN_CHANGE(IDC_EDITY4, OnChangeEdity4)
	ON_EN_CHANGE(IDC_EDITZ4, OnChangeEditz4)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_EXIT, OnButtonExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_SFactor message handlers

BOOL CDlg_SFactor::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT rect,rect1;
	int W, H, L, L1;
	char str[64];

	this->GetWindowRect(&rect);
	CListCtrl* clist = (CListCtrl*)GetDlgItem(IDC_LIST1);
	clist->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;
	clist->MoveWindow(&rect, TRUE );
	//To initial the summary
	clist->InsertColumn(0, "Structure factor along:", LVCFMT_LEFT,  80, 0);
	clist->InsertColumn(1, "For: all atoms", LVCFMT_LEFT, 72, 1);
	int i,nGroup;
	GETGROUPNUMB(&nGroup);
	for(i=1; i<=nGroup; i++)
	{
	  sprintf(str,"cluster %i",i);
	  clist->InsertColumn(i+1, str, LVCFMT_LEFT, 72, i+1);
	}

	float temp;
	int   ix[3], iy[3], iz[3];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);

    GETCOORD_SFACTOR(ix, iy, iz);
	sprintf(str,"%i",ix[0]);
	SetDlgItemText(IDC_EDITX1, str);
	sprintf(str,"%i",ix[1]);
	SetDlgItemText(IDC_EDITY1, str);
	sprintf(str,"%i",ix[2]);
	SetDlgItemText(IDC_EDITZ1, str);
	sprintf(str,"%i",iy[0]);
	SetDlgItemText(IDC_EDITX2, str);
	sprintf(str,"%i",iy[1]);
	SetDlgItemText(IDC_EDITY2, str);
	sprintf(str,"%i",iy[2]);
	SetDlgItemText(IDC_EDITZ2, str);
	sprintf(str,"%i",iz[0]);
	SetDlgItemText(IDC_EDITX3, str);
	sprintf(str,"%i",iz[1]);
	SetDlgItemText(IDC_EDITY3, str);
	sprintf(str,"%i",iz[2]);
	SetDlgItemText(IDC_EDITZ3, str);
    GETKVECTOR_SFACTOR(ix);
	sprintf(str,"%i",ix[0]);
	SetDlgItemText(IDC_EDITX4, str);
	sprintf(str,"%i",ix[1]);
	SetDlgItemText(IDC_EDITY4, str);
	sprintf(str,"%i",ix[2]);
	SetDlgItemText(IDC_EDITZ4, str);

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_SFactor::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  SET_ANALYSISDATA(&nxyz,ityp,x,y,z);
}

void CDlg_SFactor::OnChangeEditlu() 
{
  char str[32];
  float t;
  int err;

  GetDlgItemText(IDC_EDITLU, str,32);
  GETVALUE(str, &t, &err);
  if(t<= 0.f) 
  {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
  }
  SETLATTICEPARA(&t);	
	
}

void CDlg_SFactor::OnChangeEditx1() 
{
  char str[32];
  int ix[3],iy[3], iz[3];
  
  GetDlgItemText(IDC_EDITX1, str,32);
  ix[0] = atoi(str);
  GetDlgItemText(IDC_EDITY1, str,32);
  ix[1] = atoi(str);
  GetDlgItemText(IDC_EDITZ1, str,32);
  ix[2] = atoi(str);
  
  GetDlgItemText(IDC_EDITX2, str,32);
  iy[0] = atoi(str);
  GetDlgItemText(IDC_EDITY2, str,32);
  iy[1] = atoi(str);
  GetDlgItemText(IDC_EDITZ2, str,32);
  iy[2] = atoi(str);

  SETCOORD_SFACTOR(ix, iy);	
  GETCOORD_SFACTOR(ix, iy, iz);

  sprintf(str,"%i",iz[0]);
  SetDlgItemText(IDC_EDITX3, str);
  sprintf(str,"%i",iz[1]);
  SetDlgItemText(IDC_EDITY3, str);
  sprintf(str,"%i",iz[2]);
  SetDlgItemText(IDC_EDITZ3, str);
}

void CDlg_SFactor::OnChangeEdity1() 
{
   OnChangeEditx1();	
}

void CDlg_SFactor::OnChangeEditx2() 
{
   OnChangeEditx1();	
	
}

void CDlg_SFactor::OnChangeEdity2() 
{
   OnChangeEditx1();	
	
}

void CDlg_SFactor::OnChangeEditz1() 
{
   OnChangeEditx1();	
}

void CDlg_SFactor::OnChangeEditz2() 
{
   OnChangeEditx1();	
}

void CDlg_SFactor::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_LIST1) != NULL)
	{

	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 GetDlgItem(IDC_LIST1)->MoveWindow(&rect, TRUE);
	}
	
}

void CDlg_SFactor::OnDestroy() 
{
    END_SFACTOR();
    RELEASE_ANALYSISDATA();
	CDialog::OnDestroy();
	
}

void CDlg_SFactor::OnChangeEditx4() 
{
  char str[32];
  int i[3];
  
  GetDlgItemText(IDC_EDITX4, str,32);
  i[0] = atoi(str);
  GetDlgItemText(IDC_EDITY4, str,32);
  i[1] = atoi(str);
  GetDlgItemText(IDC_EDITZ4, str,32);
  i[2] = atoi(str);
  SETKVECTOR_SFACTOR(i);
}

void CDlg_SFactor::OnChangeEdity4() 
{
   OnChangeEditx4();	
}

void CDlg_SFactor::OnChangeEditz4() 
{
   OnChangeEditx4();	
}

void CDlg_SFactor::OnButtonStart() 
{
   int nGroup;
   GETGROUPNUMB(&nGroup);
   float Tfactor;
   float*cfactor = new float[nGroup];
   char str[40];
   int i,n,k[3];
 
  CAL_SFACTOR();
  GETVALUE_SFACTOR(&nGroup,cfactor,&Tfactor);  
  CListCtrl*clist = (CListCtrl*)GetDlgItem(IDC_LIST1);
  GETKVECTOR_SFACTOR(k);

  sprintf(str,"[%i,%i,%i]",k[0],k[1],k[2]);
  n = clist->GetItemCount( );
  clist->InsertItem(n, str);
  sprintf(str,"%f",Tfactor);
  clist->SetItemText(n, 1, str);
  for(i=1; i<=nGroup; i++)
  {
     sprintf(str,"%f",cfactor[i-1]);
     clist->SetItemText(n, i+1, str);
  }
  
   delete cfactor;
}

void CDlg_SFactor::OnButtonExit() 
{
	CDialog::OnOK();
	
}

void CDlg_SFactor::OnOK() 
{
    OnButtonStart();
}

