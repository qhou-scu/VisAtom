// Dlg_Density.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_Density dialog

class CDlg_Density : public CDialog
{
// Construction
public:
	CDlg_Density(CWnd* pParent = NULL);   // standard constructor
	Atoms21 *theSample;

// Dialog Data
	//{{AFX_DATA(CDlg_Density)
	enum { IDD = IDD_DENSITYOFSAMPLE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_Density)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_Density)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
