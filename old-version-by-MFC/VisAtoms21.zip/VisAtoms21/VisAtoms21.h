// VisAtoms21.h : main header file for the VISATOMS21 application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21App:
// See VisAtoms21.cpp for the implementation of this class
//

class CVisAtoms21App : public CWinApp
{
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CVisAtoms21App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVisAtoms21App)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CVisAtoms21App)
	afx_msg void OnAppAbout();
	afx_msg void OnToolsAnalysisPaircorrelation();
	afx_msg void OnToolsAnalysisParticledistribustionaround();
	afx_msg void OnToolsAnalysisStructurefactor();
	afx_msg void OnToolsAnalysisParticledistributionalongzaxsis();
	afx_msg void OnToolsAnalysisCoordinationnumberdistribution();
	afx_msg void OnToolsAnalysisShellstructure();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ShowTipAtStartup(void);
private:
	void ShowTipOfTheDay(void);
};


/////////////////////////////////////////////////////////////////////////////
