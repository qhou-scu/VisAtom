// MakeClusters.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "MakeClusters.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMakeClusters

IMPLEMENT_DYNAMIC(CMakeClusters, CPropertySheet)

CMakeClusters::CMakeClusters(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&Boundary);
	AddPage(&DrawingSty);
}

CMakeClusters::CMakeClusters(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&Boundary);
	AddPage(&DrawingSty);
}

CMakeClusters::~CMakeClusters()
{
}


BEGIN_MESSAGE_MAP(CMakeClusters, CPropertySheet)
	//{{AFX_MSG_MAP(CMakeClusters)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMakeClusters message handlers
