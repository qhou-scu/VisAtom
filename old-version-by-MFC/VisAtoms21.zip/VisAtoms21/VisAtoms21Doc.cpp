// VisAtoms21Doc.cpp : implementation of the CVisAtoms21Doc class
//

#include "stdafx.h"
#include "VisAtoms21.h"

#include "VisAtoms21Doc.h"
#include "Dlg_ReadinProgress.h"
#include "ProgDlg.h"
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21Doc

IMPLEMENT_DYNCREATE(CVisAtoms21Doc, CDocument)

BEGIN_MESSAGE_MAP(CVisAtoms21Doc, CDocument)
	//{{AFX_MSG_MAP(CVisAtoms21Doc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21Doc construction/destruction

CVisAtoms21Doc::CVisAtoms21Doc()
{
	frameIDmi =  999999; 
	frameIDmx = -999999; 
	ifNext = 0;
    /* Get the current working directory: */
    _getcwd( WorkDir, 256); 
}

CVisAtoms21Doc::~CVisAtoms21Doc()
{
    char fname[260];

	strcpy(fname,WorkDir);
	strcat(fname,"\\VisAtoms.ini");
	FILE*pf= fopen(fname, "w");
    if( pf != NULL)
	 {
		int n;	
		n = fwrite(fmt.flag, sizeof(int), 20, pf);
		n = fwrite(fmt.iCheck, sizeof(int), 6, pf);
		n = fwrite(&fmt.iAutoGroup, sizeof(int), 1, pf); 
      	fclose(pf);
	 }
}

BOOL CVisAtoms21Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

    char fname[260];

	strcpy(fname,WorkDir);
	strcat(fname,"\\VisAtoms.ini");
	FILE*pf= fopen(fname, "r");
    if( pf != NULL)
	 {
		int n;	
		n = fread(fmt.flag, sizeof(int), 20, pf);
		n = fread(fmt.iCheck, sizeof(int), 6, pf);
		n = fread(&fmt.iAutoGroup, sizeof(int), 1, pf); 
      	fclose(pf);
	 }
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21Doc serialization

void CVisAtoms21Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21Doc diagnostics

#ifdef _DEBUG
void CVisAtoms21Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVisAtoms21Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21Doc commands
//*** the following part is to make subsample
extern "C" { 
           void __stdcall NUMBEROFCOLUME(char*, int*);
           void __stdcall NUMBEROFLINE(char*, int*);
            }

BOOL CVisAtoms21Doc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	strcpy(fmt.DataName, lpszPathName);

	NUMBEROFCOLUME(fmt.DataName, &fmt.nCol);

	if(!fmt.iShowAgain)	
	{
		if(fmt.DoModal() == IDCANCEL) return FALSE; 
	}

	CProgressDlg p;
	p.Create(NULL);
	char str[256];
	strcpy(str, "Read in ");
	strcat(str, fmt.DataName);
    p.SetStatus(str);
    p.StepIt();
    ifInRead = 1;
	NUMBEROFLINE(fmt.DataName, &fmt.nLine);
    sprintf(str, "There are %i atoms to be imported...", fmt.nLine);
    p.SetStatus(str);
    p.StepIt();
	//To get the color or style of subgroup in old sample
	int I = m_Sample.GetNumb_of_subSample();
	int J;
    float*R, *G, *B, *A;
	int *nStyle;

	int i;
	R = new float[I];
	G = new float[I];
	B = new float[I];
	A = new float[I];
	nStyle = new int[I];

	for(i=1; i<I; i++)
	{
       J = m_Sample.GetTypeSubSampleAssignTo(i);
       m_Sample.GetColor_subSample(J, &R[i], &G[i], &B[i], &A[i]);
	   m_Sample.GetStyle_subSample(J, &nStyle[i]);
    }

    //Now begin create the new sample  	
    m_Sample.ReleaseAll();
	m_Sample.MakeActive();
	m_Sample.Import_Config(fmt.DataName, fmt.nLine, fmt.nCol, 1, fmt.iCheck, fmt.flag); 
    sprintf(str, "Import succssfully");
    p.SetStatus(str);
	p.DestroyWindow();

	//To restore the color and style of sybsample
	for(i=1; i<I; i++)
	{
      m_Sample.ChangeColor_subSample(i, R[i], G[i], B[i], A[i]);
	  m_Sample.ChangeStyle_subSample(i, nStyle[i]);
	}
	delete R;
	delete G;
	delete B;
	delete A;
	delete nStyle;


	if(fmt.iAutoGroup) m_Sample.GroupAtomsbyColor();
	ifInRead = 0;

	return TRUE;
}

int CVisAtoms21Doc::GetCurrentFirstFname(char*fname)
{
   char dExt[8];
   int i, idot, id;
   char szFile[260];

     strcpy(szFile, GetPathName( ) );
     idot = 0;
     i = 0;
     while(szFile[i] != NULL)
	  { 
	    if(szFile[i] == '.') idot = i+1;
	    i++;
	  }

	  sprintf(dExt,"");
	  for(i=idot; i<idot+8; i++) dExt[i-idot] = szFile[i];
	  dExt[8] = NULL;
	  id = atoi(dExt);
	  if(id>0)
	  {
	    idot--;
	    sprintf(fname, "");
	    for(i=0; i<idot; i++) fname[i] = szFile[i];
	    fname[i] = NULL;
	   }
	  return id;
}

int CVisAtoms21Doc::ReadPreviousFile() 
{
	char szFile[260];
	char temp[5];

	int i = GetCurrentFirstFname(szFile);

	if(i<=1) 
	{
      return 0;
	}
	else
	{
	  i--;
	  if(i<10) sprintf(temp,  ".000%i", i);
	  if(10<=i && i<100) sprintf(temp, ".00%i",  i);
	  if(100<=i && i<1000) sprintf(temp, ".0%i",  i);
	  if(i>=1000)  sprintf(temp, ".%i",  i);

	  strcat(szFile, temp);
      if( OnOpenDocument(szFile))
	  {
	      SetPathName( szFile, TRUE);
		  i++;
	      if( frameIDmi > i) frameIDmi = i;
	      if( frameIDmx < i) frameIDmx = i;
          UpdateAllViews( NULL, 0L, NULL );
	      ifNext = -1;
	  }
	  else
	  {
		  ifNext = 0;
	  }
	  return 1;
	}
}

int CVisAtoms21Doc::ReadNextFile() 
{
	char szFile[260];
	char temp[5];

	int i = GetCurrentFirstFname(szFile);

	if(i<1) 
      return 0;
	else
	{
	  i++;
	  if(i<10) sprintf(temp,  ".000%i", i);
	  if(10<=i && i<100) sprintf(temp, ".00%i",  i);
	  if(100<=i && i<1000) sprintf(temp, ".0%i",  i);
	  if(i>=1000)  sprintf(temp, ".%i",  i);

	  strcat(szFile, temp);
      if( OnOpenDocument(szFile) )
	  {
	    SetPathName( szFile, TRUE);
		i--;
	    if( frameIDmi > i) frameIDmi = i;
	    if( frameIDmx < i) frameIDmx = i;
        UpdateAllViews( NULL, 0L, NULL );
	    ifNext = 1;
	  }
	  else
	  {
		ifNext = 0;
	  }
	  return 1;
	}
}


int CVisAtoms21Doc::ReadFirstFile() 
{
	char szFile[260];
	char temp[5];

	int i = GetCurrentFirstFname(szFile);

	if(frameIDmi <=1) 
	{
      return 0;
	}
	else
	{
	  i = frameIDmi;
	  if(i<10) sprintf(temp,  ".000%i", i);
	  if(10<=i && i<100) sprintf(temp, ".00%i",  i);
	  if(100<=i && i<1000) sprintf(temp, ".0%i",  i);
	  if(i>=1000)  sprintf(temp, ".%i",  i);

	  strcat(szFile, temp);
      OnOpenDocument(szFile);
	  SetPathName( szFile, TRUE);
      UpdateAllViews( NULL, 0L, NULL );
	  ifNext = 0;
	  fmt.iOpenContinue = 0;
	  return 1;
	}
}

int CVisAtoms21Doc::ReadLastFile() 
{
	char szFile[260];
	char temp[5];

	int i = GetCurrentFirstFname(szFile);

	if(frameIDmx <=1) 
	{
      return 0;
	}
	else
	{
	  i = frameIDmx;
	  if(i<10) sprintf(temp,  ".000%i", i);
	  if(10<=i && i<100) sprintf(temp, ".00%i",  i);
	  if(100<=i && i<1000) sprintf(temp, ".0%i",  i);
	  if(i>=1000)  sprintf(temp, ".%i",  i);

	  strcat(szFile, temp);
      OnOpenDocument(szFile);
	  SetPathName( szFile, TRUE);
      UpdateAllViews( NULL, 0L, NULL );
	  ifNext = 0;
	  fmt.iOpenContinue = 0;
	  return 1;
	}
}


BOOL CVisAtoms21Doc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	
	  
	  if( m_Sample.GetNumberofAtom() <= 0) 
	  {
         MessageBox(NULL, "No atoms to save", "Warning", MB_OK|MB_ICONWARNING);
		 return FALSE;
	  }
  
      FILE*pFile= fopen(lpszPathName, "w");
      m_Sample.Save_Config(pFile);
	  fclose(pFile);
	return TRUE; //CDocument::OnSaveDocument(lpszPathName);
}
