// Dlg_SFactor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_SFactor dialog
#include "Atoms21.h"

class CDlg_SFactor : public CDialog
{
// Construction
public:
	CDlg_SFactor(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_SFactor)
	enum { IDD = IDD_SFACTOR };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_SFactor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_SFactor)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEditlu();
	afx_msg void OnChangeEditx1();
	afx_msg void OnChangeEdity1();
	afx_msg void OnChangeEditx2();
	afx_msg void OnChangeEdity2();
	afx_msg void OnChangeEditz1();
	afx_msg void OnChangeEditz2();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnChangeEditx4();
	afx_msg void OnChangeEdity4();
	afx_msg void OnChangeEditz4();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonExit();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
public:
	void ImportSample(Atoms21*);

};
