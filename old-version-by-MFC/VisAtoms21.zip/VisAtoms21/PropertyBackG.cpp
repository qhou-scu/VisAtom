// PropertyBackG.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertyBackG.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyBackG

IMPLEMENT_DYNAMIC(CPropertyBackG, CPropertySheet)

CPropertyBackG::CPropertyBackG(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&Color);
}

CPropertyBackG::CPropertyBackG(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&Color);
}

CPropertyBackG::~CPropertyBackG()
{
}


BEGIN_MESSAGE_MAP(CPropertyBackG, CPropertySheet)
	//{{AFX_MSG_MAP(CPropertyBackG)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyBackG message handlers
