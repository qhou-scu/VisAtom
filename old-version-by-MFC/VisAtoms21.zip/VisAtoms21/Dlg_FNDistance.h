// Dlg_FNDistance.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_FNDistance dialog
#include "WndGL_xyFig.h"
#include "Atoms21.h"

class CDlg_FNDistance : public CDialog
{
// Construction
public:
	CDlg_FNDistance(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_FNDistance)
	enum { IDD = IDD_FNDistance };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_FNDistance)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_FNDistance)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio5();
	afx_msg void OnRadio6();
	afx_msg void OnChangeEdit2();
	afx_msg void OnDestroy();
	afx_msg void OnExit();
	virtual void OnOK();
	afx_msg void OnButtonStart();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	CWndGL_xyFig Fig;
    CWinThread*Kernal;
    UINT nIDEvent;
public:
	void ImportSample(Atoms21*);

};
