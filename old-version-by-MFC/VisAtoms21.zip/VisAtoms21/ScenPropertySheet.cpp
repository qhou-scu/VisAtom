// ScenPropertySheet.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "ScenPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScenPropertySheet

IMPLEMENT_DYNAMIC(CScenPropertySheet, CPropertySheet)

CScenPropertySheet::CScenPropertySheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&A);
	AddPage(&C);
	AddPage(&V);
}

CScenPropertySheet::CScenPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&A);
	AddPage(&C);
	AddPage(&V);
}

CScenPropertySheet::~CScenPropertySheet()
{
}


BEGIN_MESSAGE_MAP(CScenPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CScenPropertySheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScenPropertySheet message handlers
