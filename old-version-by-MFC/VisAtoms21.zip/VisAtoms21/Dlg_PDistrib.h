// Dlg_PDistrib.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_PDistrib dialog
#include "WndGL_xyFig.h"
#include "Atoms21.h"

class CDlg_PDistrib : public CDialog
{
// Construction
public:
	CDlg_PDistrib(CWnd* pParent = NULL);   // standard constructor
	~CDlg_PDistrib();                      // sdestroyer
// Dialog Data
	//{{AFX_DATA(CDlg_PDistrib)
	enum { IDD = IDD_PARTDISTRIB };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_PDistrib)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_PDistrib)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio3();
	afx_msg void OnRadio4();
	afx_msg void OnChangeEdit2();
	afx_msg void OnDestroy();
	afx_msg void OnButtonStart();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnRadio5();
	afx_msg void OnRadio6();
	afx_msg void OnExit();
	virtual void OnOK();
	afx_msg void OnSelchangeAtom2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	CWndGL_xyFig Fig;
	float xc, yc, zc;
	float x0, y0, z0;
public:
	void ImportSample(Atoms21*);
};
