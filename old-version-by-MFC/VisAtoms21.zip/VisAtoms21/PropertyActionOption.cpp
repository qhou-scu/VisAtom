// PropertyActionOption.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertyActionOption.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyActionOption property page

IMPLEMENT_DYNCREATE(CPropertyActionOption, CPropertyPage)

CPropertyActionOption::CPropertyActionOption() : CPropertyPage(CPropertyActionOption::IDD)
{
	//{{AFX_DATA_INIT(CPropertyActionOption)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
  systemchoice = 0;
  zoomPercent = 0.f;
  rotationStepx = 0.f;
  rotationStepy = 0.f;
  rotationStepz = 0.f;
  itransStepx = 0.f;
  itransStepy = 0.f;
  itransStepz = 0.f;

}

CPropertyActionOption::~CPropertyActionOption()
{
}

void CPropertyActionOption::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyActionOption)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyActionOption, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyActionOption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyActionOption message handlers

BOOL CPropertyActionOption::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if(systemchoice) CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
	else CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);

	
	char str[40];

	sprintf(str,"%-5.1f",rotationStepx);
	SetDlgItemText(IDC_EDIT1, str);
	sprintf(str,"%-5.1f",rotationStepy);
	SetDlgItemText(IDC_EDIT2, str);
	sprintf(str,"%-5.1f",rotationStepz);
	SetDlgItemText(IDC_EDIT3, str);

	sprintf(str,"%-5.1f",itransStepx);
	SetDlgItemText(IDC_EDIT4, str);
	sprintf(str,"%-5.1f",itransStepy);
	SetDlgItemText(IDC_EDIT5, str);
	sprintf(str,"%-5.1f",itransStepz);
	SetDlgItemText(IDC_EDIT6, str);

	sprintf(str,"%-5.1f",zoomPercent);
	SetDlgItemText(IDC_EDIT7, str);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropertyActionOption::OnOK() 
{
   	if( ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck()) 
		  systemchoice = 0;
   	else  systemchoice = 1;

	char str[40];
    GetDlgItemText(IDC_EDIT1, str,40);
    rotationStepx = (float) atof(str);
    GetDlgItemText(IDC_EDIT2, str,40);
    rotationStepy = (float) atof(str);
    GetDlgItemText(IDC_EDIT3, str,40);
    rotationStepz = (float) atof(str);

    GetDlgItemText(IDC_EDIT4, str,40);
    itransStepx = (float) atof(str);
    GetDlgItemText(IDC_EDIT5, str,40);
    itransStepy = (float) atof(str);
    GetDlgItemText(IDC_EDIT6, str,40);
    itransStepz = (float) atof(str);

    GetDlgItemText(IDC_EDIT7, str,40);
    zoomPercent = (float) atof(str);
	
	CPropertyPage::OnOK();
}
