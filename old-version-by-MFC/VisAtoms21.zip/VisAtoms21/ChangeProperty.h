// ChangeProperty.h : header file
//
#include "PropertyDrawingstyle.h"
/////////////////////////////////////////////////////////////////////////////
// CChangeProperty

class CChangeProperty : public CPropertySheet
{
	DECLARE_DYNAMIC(CChangeProperty)

// Construction
public:
	CChangeProperty(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CChangeProperty(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	CPropertyDrawingstyle   DrawingSty;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangeProperty)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChangeProperty();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChangeProperty)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
