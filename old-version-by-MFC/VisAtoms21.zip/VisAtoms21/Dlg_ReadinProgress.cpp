// Dlg_ReadinProgress.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_ReadinProgress.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_ReadinProgress dialog


CDlg_ReadinProgress::CDlg_ReadinProgress(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_ReadinProgress::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_ReadinProgress)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

}


void CDlg_ReadinProgress::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_ReadinProgress)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_ReadinProgress, CDialog)
	//{{AFX_MSG_MAP(CDlg_ReadinProgress)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_ReadinProgress message handlers

BOOL CDlg_ReadinProgress::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(str);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_ReadinProgress::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
}
