// Dlg_AtomOrSubSample.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_AtomOrSubSample.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_AtomOrSubSample dialog


CDlg_AtomOrSubSample::CDlg_AtomOrSubSample(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_AtomOrSubSample::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_AtomOrSubSample)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	choice = operate_pickedatom;

}


void CDlg_AtomOrSubSample::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_AtomOrSubSample)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_AtomOrSubSample, CDialog)
	//{{AFX_MSG_MAP(CDlg_AtomOrSubSample)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_AtomOrSubSample message handlers

BOOL CDlg_AtomOrSubSample::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(choice == operate_pickedatom)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO1);

	if(choice == operate_unpickedatom)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO3);


	if(choice == operate_allatom)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO4);

	if(choice == operate_subsample)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO2);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_AtomOrSubSample::OnOK() 
{
	if(((CButton*) GetDlgItem(IDC_RADIO1))->GetCheck() ) 
	{
		choice = operate_pickedatom;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO2))->GetCheck() ) 
	{
		choice = operate_subsample;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO3))->GetCheck() ) 
	{
		choice = operate_unpickedatom;
	}
	
	if(((CButton*) GetDlgItem(IDC_RADIO4))->GetCheck() ) 
	{
		choice = operate_allatom;
	}
	
	CDialog::OnOK();
}
