// PropertySceneVolume.h : header file
//
#include "Scene.h"
/////////////////////////////////////////////////////////////////////////////
// CPropertySceneVolume dialog

class CPropertySceneVolume : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertySceneVolume)

// Construction
public:
	CPropertySceneVolume();
	~CPropertySceneVolume();

// Dialog Data
	//{{AFX_DATA(CPropertySceneVolume)
	enum { IDD = IDD_PROPPAGE_SCENEVOLUME };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA
public:
	int changed, style, updatechoice;
	float left, right, top, bottom, nearz, farz;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertySceneVolume)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertySceneVolume)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
