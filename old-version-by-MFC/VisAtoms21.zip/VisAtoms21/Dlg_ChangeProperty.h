// Dlg_ChangeProperty.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_ChangeProperty dialog
#include "Atoms21.h"

#include "WndGL_FrontColor.h"

class CDlg_ChangeProperty : public CDialog
{
// Construction
public:
	CDlg_ChangeProperty(CWnd* pParent = NULL);   // standard constructor
	Atoms21*m_Sample;
    float*R;
    float*G;
    float*B;
	float*A;
	float*r;
	float bR, bG, bB;
	int*style;
	int style0;
	int curID;
// Dialog Data
	//{{AFX_DATA(CDlg_ChangeProperty)
	enum { IDD = IDD_DRAWINGSTYLE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_ChangeProperty)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	CWndGL_FrontColor frontColor;
	// Generated message map functions
	//{{AFX_MSG(CDlg_ChangeProperty)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnSelchangeCombo3();
	virtual void OnOK();
	afx_msg void OnSelchangeCombo2();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
