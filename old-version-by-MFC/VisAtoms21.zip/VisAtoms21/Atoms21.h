
#ifndef _ATOMS21
#define _ATOMS21
#include  "Sample.h"

#define  style_SubSamples   0
#define  style_Atom_Dot     1 
#define  style_Atom_Circle  2 
#define  style_Atom_Wire    3 
#define  style_Atom_Solid   4
#define  style_Velocity_Wire   5
#define  style_Velocity_Solid  6
#define  style_Force_Wire      7
#define  style_Force_Solid     8
#define  style_mask          255

#define  style_Independent_radiu 32768
#define  style_Independent_color 16384
#define  style_Independent_mask  49152

#define  style_ClipEnabled      128


class Atoms21:public Sample
{
	private:
    protected:
	   int style;

	   float*vx, *vy, *vz, *fx, *fy, *fz,*r, *R, *G, *B;

	   float vzoom, vFactor, lvzoom, lvFactor, lvm;
	   float fzoom, fFactor, lfzoom, lfFactor, lfm;
    public:
	    Atoms21();
	    Atoms21(Atoms21*);
	    ~Atoms21();
		void ReleaseAll();
		//
		int GetStyle(){return style;};
		void SetStyle(int nStyle) {style = nStyle;};

		float Get_rFactor(){return rFactor;};
		void  Set_rFactor(float newFactor){ rFactor = newFactor;};
		float Get_vFactor(){return vFactor;};
		void  Set_vFactor(float newFactor){ vFactor = newFactor;};
		float Get_lvFactor(){return lvFactor;};
		void  Set_lvFactor(float newFactor){ lvFactor = newFactor;};
		float Get_fFactor(){return fFactor;};
		void  Set_fFactor(float newFactor){ fFactor = newFactor;};
		float Get_lfFactor(){return lfFactor;};
		void  Set_lfFactor(float newFactor){ lfFactor = newFactor;};
		//
		int ifHasVelocity(){ if(vx==NULL || vy==NULL || vz == NULL) return 0; else return 1;};
		int ifHasForce()   { if(fx==NULL || fy==NULL || fz == NULL) return 0; else return 1;};
		int ifHasColor()   { if(R==NULL  ||  G==NULL ||  B == NULL) return 0; else return 1;};
		int ifHasRadiu()   { if(r==NULL) return 0; else return 1;};

		//To edit the atoms
		void CopySample(Atoms21*);
		void CopySubSample(Atoms21*);
		void CopySelectedAtoms(Atoms21*);
		void Paste(Atoms21*);

		void New(int, int, int, int, int, float*, float*);
		void NewByImport(char*, int*);
		void NewByPaste(Sample*);

		void Save_Summary(FILE*);
		void Save_Config_Selected(FILE*);
		void Save_Config_PickedSubsample(FILE*);
		void Save_Config_VisiableAtoms(FILE*);
		void Save_Config(FILE*);

	    //To Read in datas
		int Import_Config(char*, int, int, int, int*, int*);
        int GroupAtomsbyColor(); 

		//This part concerning display property
 		virtual void Paint();
		void Draw();
		void DrawSolidAtoms(int I){Sample::DrawSolidAtoms(I);};
		void DrawWireAtoms(int I){Sample::DrawWireAtoms(I);};
		void DrawDotAtoms(int I){Sample::DrawDotAtoms(I);};
		void DrawCircleAtoms(int I){Sample::DrawCircleAtoms(I);};
		void DrawWireVelocity(int I);
		void DrawSolidVelocity(int I);
		void DrawWireForce(int I);
		void DrawSolidForce(int I);

		void DrawSolidAtoms();
		void DrawWireAtoms();
		void DrawDotAtoms();
		void DrawCircleAtoms();
		void DrawWireVelocity();
		void DrawSolidVelocity();
		void DrawWireForce();
		void DrawSolidForce();

		void DrawSolidAtoms_IC();
		void DrawWireAtoms_IC();
		void DrawDotAtoms_IC();

		void DrawSolidAtoms_IR();
		void DrawWireAtoms_IR();
		void DrawDotAtoms_IR();

		void DrawSolidAtoms_ICR();
		void DrawWireAtoms_ICR();
		void DrawDotAtoms_ICR();


		void Rzoomin();
		void Rzoomout();

		int Lzoomin();
		int Lzoomout();
		void LzoominV();
		void LzoomoutV();
		void LzoominF();
		void LzoomoutF();

		//Dynamics....
		void Thermalize_Sample(float);
		void Thermalize_subSample(int, float);
};

#endif