// MakeClusters.h : header file
//
#include "PropertyBoundry.h"
#include "PropertyDrawingstyle.h"
/////////////////////////////////////////////////////////////////////////////
// CMakeClusters

class CMakeClusters : public CPropertySheet
{
	DECLARE_DYNAMIC(CMakeClusters)

// Construction
public:
	CMakeClusters(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMakeClusters(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:
	CPropertyBoundry Boundary;
	CPropertyDrawingstyle   DrawingSty;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMakeClusters)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMakeClusters();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMakeClusters)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
