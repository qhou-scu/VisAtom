// Dlg_Show.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_Show.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_Show dialog


CDlg_Show::CDlg_Show(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_Show::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_Show)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	theSample = NULL;
	AtomeOrSample = choice_subsample;
}


void CDlg_Show::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_Show)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_Show, CDialog)
	//{{AFX_MSG_MAP(CDlg_Show)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_LBN_SETFOCUS(IDC_LIST1, OnSetfocusList1)
	ON_LBN_SETFOCUS(IDC_LIST2, OnSetfocusList2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_Show message handlers

BOOL CDlg_Show::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(theSample == NULL) return TRUE;
	int i = theSample->GetNumb_of_subSample()-1;
	int j;
	int I;
	char str[40];
	for(j=0; j<i; j++)
	{
	   itoa(j+1, str, 10);
       I = theSample->GetTypeSubSampleAssignTo(j+1);
	   if( theSample->IfVisiableAtomsGroup(I) )
	     ((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
	   else
	     ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
	}


	//get the type for ith subsample
	  GetDlgItem(IDC_STATIC1)->SetWindowText("");
	  GetDlgItem(IDC_STATIC2)->SetWindowText("");
	  GetDlgItem(IDC_STATIC3)->SetWindowText("");
	  GetDlgItem(IDC_STATIC4)->SetWindowText("");
	
	// atom or subsample will be changed
	if(AtomeOrSample == choice_pickedatom)
	{
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
	   GetDlgItem(IDC_LIST1)->EnableWindow( FALSE);
	   GetDlgItem(IDC_LIST2)->EnableWindow( FALSE);
	   GetDlgItem(IDC_BUTTON1)->EnableWindow( FALSE);
	   GetDlgItem(IDC_BUTTON2)->EnableWindow( FALSE);
    }

	if(AtomeOrSample == choice_subsample)
	{
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
	   GetDlgItem(IDC_LIST1)->EnableWindow( TRUE);
	   GetDlgItem(IDC_LIST2)->EnableWindow( TRUE);
	   GetDlgItem(IDC_BUTTON1)->EnableWindow( TRUE);
	   GetDlgItem(IDC_BUTTON2)->EnableWindow( TRUE);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_Show::OnRadio1() 
{
	if( ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck() )
	{
	   AtomeOrSample = choice_pickedatom;
	   GetDlgItem(IDC_LIST1)->EnableWindow( FALSE);
	   GetDlgItem(IDC_LIST1)->EnableWindow( FALSE);
	   GetDlgItem(IDC_LIST2)->EnableWindow( FALSE);
	   GetDlgItem(IDC_BUTTON1)->EnableWindow( FALSE);
	   GetDlgItem(IDC_BUTTON2)->EnableWindow( FALSE);
    }
	
}

void CDlg_Show::OnRadio2() 
{
	if( ((CButton*)GetDlgItem(IDC_RADIO2))->GetCheck() )
	{
	  AtomeOrSample = choice_subsample;
      if( ((CListBox*)GetDlgItem(IDC_LIST2))->GetCount() >0)
	  {
        GetDlgItem(IDC_LIST2)->EnableWindow(TRUE);
	    GetDlgItem(IDC_BUTTON1)->EnableWindow( TRUE);
	  }

      if( ((CListBox*)GetDlgItem(IDC_LIST1))->GetCount() >0)
	  {
        GetDlgItem(IDC_LIST1)->EnableWindow(TRUE);
	    GetDlgItem(IDC_BUTTON2)->EnableWindow( TRUE);
	  }
   }
}

void CDlg_Show::OnSetfocusList1() 
{
     GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);	
     GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	 ((CListBox*)GetDlgItem(IDC_LIST2))->SetCurSel(-1);
}

void CDlg_Show::OnSetfocusList2() 
{
     GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);	
     GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);	
	 ((CListBox*)GetDlgItem(IDC_LIST1))->SetCurSel(-1);
}

void CDlg_Show::OnButton1() 
{
   int i = ((CListBox*)GetDlgItem(IDC_LIST2))->GetCurSel();	
   if(i<0) return;
   char str[40];

   ((CListBox*)GetDlgItem(IDC_LIST2))->GetText(i, str);
   ((CListBox*)GetDlgItem(IDC_LIST2))->DeleteString(i);
   if( ((CListBox*)GetDlgItem(IDC_LIST2))->GetCount() <= 0)
        GetDlgItem(IDC_LIST2)->EnableWindow(FALSE);

   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
   if( ((CListBox*)GetDlgItem(IDC_LIST1))->GetCount() > 0)
        GetDlgItem(IDC_LIST1)->EnableWindow(TRUE);
}

void CDlg_Show::OnButton2() 
{
   int i = ((CListBox*)GetDlgItem(IDC_LIST1))->GetCurSel();	
   if(i<0) return;
   char str[40];

   ((CListBox*)GetDlgItem(IDC_LIST1))->GetText(i, str);
   ((CListBox*)GetDlgItem(IDC_LIST1))->DeleteString(i);
   if( ((CListBox*)GetDlgItem(IDC_LIST1))->GetCount() <= 0)
        GetDlgItem(IDC_LIST1)->EnableWindow(FALSE);
   
   ((CListBox*)GetDlgItem(IDC_LIST2))->AddString(str);
   if( ((CListBox*)GetDlgItem(IDC_LIST2))->GetCount() > 0)
        GetDlgItem(IDC_LIST2)->EnableWindow(TRUE);
}

void CDlg_Show::OnSelchangeList1() 
{
   int i = ((CListBox*)GetDlgItem(IDC_LIST1))->GetCurSel();	
   char str[40];
   float Z, M;
   ((CListBox*)GetDlgItem(IDC_LIST1))->GetText(i, str);
   i = atoi(str);

   int I = theSample->GetTypeSubSampleAssignTo(i);

    theSample->GetAtomSubSampleAssignTo(I, str, &Z, &M);
    GetDlgItem(IDC_STATIC1)->SetWindowText(str);
	sprintf(str, "%f",Z);
	GetDlgItem(IDC_STATIC2)->SetWindowText(str);
	sprintf(str, "%f",M);
	GetDlgItem(IDC_STATIC3)->SetWindowText(str);
	itoa(I,str,10);
	GetDlgItem(IDC_STATIC4)->SetWindowText(str);
}

void CDlg_Show::OnSelchangeList2() 
{
   int i = ((CListBox*)GetDlgItem(IDC_LIST2))->GetCurSel();	
   char str[40];
   float Z, M;
   ((CListBox*)GetDlgItem(IDC_LIST2))->GetText(i, str);
   i = atoi(str);

   int I = theSample->GetTypeSubSampleAssignTo(i);

    theSample->GetAtomSubSampleAssignTo(I, str, &Z, &M);
    GetDlgItem(IDC_STATIC1)->SetWindowText(str);
	sprintf(str, "%f",Z);
	GetDlgItem(IDC_STATIC2)->SetWindowText(str);
	sprintf(str, "%f",M);
	GetDlgItem(IDC_STATIC3)->SetWindowText(str);
	itoa(I,str,10);
	GetDlgItem(IDC_STATIC4)->SetWindowText(str);
	
}

void CDlg_Show::OnOK() 
{
   char str[40];
   int i, j, k, I;
   i = ((CListBox*)GetDlgItem(IDC_LIST2))->GetCount();	
   for(j=0; j<i; j++)
   {
     ((CListBox*)GetDlgItem(IDC_LIST2))->GetText(j, str);
     k = atoi(str);
	 I = theSample->GetTypeSubSampleAssignTo(k);
	 theSample->ShowAtomsGroup(I);
   }


   i = ((CListBox*)GetDlgItem(IDC_LIST1))->GetCount();	
   for(j=0; j<i; j++)
   {
     ((CListBox*)GetDlgItem(IDC_LIST1))->GetText(j, str);
     k = atoi(str);
	 I = theSample->GetTypeSubSampleAssignTo(k);
	 theSample->HideAtomsGroup(I);
   }

	CDialog::OnOK();
}
