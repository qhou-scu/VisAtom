#if !defined(AFX_PROPERTYCLIPPLANE1_H__505A1646_A74C_11D2_A6C2_006097159825__INCLUDED_)
#define AFX_PROPERTYCLIPPLANE1_H__505A1646_A74C_11D2_A6C2_006097159825__INCLUDED_
// _MSC_VER >= 1000
// PropertyClipPlane1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane1 dialog

class CPropertyClipPlane1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyClipPlane1)

// Construction
public:
	CPropertyClipPlane1();
	~CPropertyClipPlane1();
public:
	float   iclipStep[3];
	float   iclipThick[3];
	int     clipState[3];

// Dialog Data
	//{{AFX_DATA(CPropertyClipPlane1)
	enum { IDD = IDD_PROPPAGE_SCENE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyClipPlane1)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyClipPlane1)
	afx_msg void OnCheck11();
	afx_msg void OnCheck12();
	afx_msg void OnCheck13();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnChangeEdit1();
	afx_msg void OnChangeEdit2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYCLIPPLANE1_H__505A1646_A74C_11D2_A6C2_006097159825__INCLUDED_)
