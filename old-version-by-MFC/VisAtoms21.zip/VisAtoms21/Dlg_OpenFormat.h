// Dlg_OpenFormat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_OpenFormat dialog

class CDlg_OpenFormat : public CDialog
{
// Construction
public:
	CDlg_OpenFormat(CWnd* pParent = NULL);   // standard constructor
	int nCol,nLine, flag[20], tflag[20];
	int iCheck[6], iShowAgain, iAutoGroup, iOpenContinue;
	char DataName[260];
// Dialog Data
	//{{AFX_DATA(CDlg_OpenFormat)
	enum { IDD = IDD_OPENFORMAT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_OpenFormat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_OpenFormat)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheck1();
	afx_msg void OnCheck2();
	afx_msg void OnCheck3();
	afx_msg void OnCheck4();
	afx_msg void OnCheck5();
	afx_msg void OnCheck6();
	afx_msg void OnButton1();
	virtual void OnOK();
	afx_msg void OnCheck7();
	afx_msg void OnCheck8();
	afx_msg void OnCheck9();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
