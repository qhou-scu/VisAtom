// Dlg_CoordNumb.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_CoordNumb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_CoordNumb dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SET_ANALYSISDATA(int*,int*,float*,float*,float*);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
             void __stdcall GETPCX(int*);
             void __stdcall SETPCX(int*);
             void __stdcall GETPCY(int*);
             void __stdcall SETPCY(int*);
             void __stdcall GETPCZ(int*);
             void __stdcall SETPCZ(int*);
             void __stdcall GETBOXX(float*);
             void __stdcall SETBOXX(float*);
             void __stdcall GETBOXY(float*);
             void __stdcall SETBOXY(float*);
             void __stdcall GETBOXZ(float*);
             void __stdcall SETBOXZ(float*);
             void __stdcall SETBOND_COORDNUMB(float*);
             void __stdcall GETBOND_COORDNUMB(float*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);
             void __stdcall SETTYPE_COORDNUMB(int*, int*);
             void __stdcall GETTYPE_COORDNUMB(int*, int*);

             void __stdcall CAL_COORDNUMBALL();
             void __stdcall CAL_COORDNUMB1ALL();
             void __stdcall CAL_COORDNUMBALL1();
             void __stdcall CAL_COORDNUMB11();
             void __stdcall GETVALUE_COORDNUMB(int*, int*,float*, float*);
             void __stdcall END_COORDNUMB();
             void __stdcall RELEASE_ANALYSISDATA();

           }

UINT Cal_CoordNumbAllProc( LPVOID pParam )
{
   	CAL_COORDNUMBALL();;
	return 0;	// thread completed successfully
}
 
UINT Cal_CoordNumb1AllProc( LPVOID pParam )
{
   	CAL_COORDNUMB1ALL();;
	return 0;	// thread completed successfully
} 

UINT Cal_CoordNumbAll1Proc( LPVOID pParam )
{
   	CAL_COORDNUMBALL1();;
	return 0;	// thread completed successfully
} 

UINT Cal_CoordNumb11Proc( LPVOID pParam )
{
   	CAL_COORDNUMB11();;
	return 0;	// thread completed successfully
} 


CDlg_CoordNumb::CDlg_CoordNumb(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_CoordNumb::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_CoordNumb)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg_CoordNumb::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_CoordNumb)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_CoordNumb, CDialog)
	//{{AFX_MSG_MAP(CDlg_CoordNumb)
	ON_BN_CLICKED(IDC_CHECKX, OnCheckx)
	ON_BN_CLICKED(IDC_CHECKY, OnChecky)
	ON_BN_CLICKED(IDC_CHECKZ, OnCheckz)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO7, OnRadio7)
	ON_BN_CLICKED(IDC_RADIO8, OnRadio8)
	ON_CBN_SELCHANGE(IDC_ATOM1, OnSelchangeAtom1)
	ON_CBN_SELCHANGE(IDC_ATOM2, OnSelchangeAtom2)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_CoordNumb message handlers
void CDlg_CoordNumb::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  SET_ANALYSISDATA(&nxyz,ityp,x,y,z);
}


BOOL CDlg_CoordNumb::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT rect,rect1;
	int W, H, L, L1;
	this->GetWindowRect(&rect);
	GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;

	Fig.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rect,this,0,NULL);

	float temp;
	int    itemp;
	char str[32];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);

	GETBOXX(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITX, str);
	GETBOXY(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITY, str);
	GETBOXZ(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITZ, str);
    
    GETPCX(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKX,1);
	else
		CheckDlgButton(IDC_CHECKX,0);

    GETPCY(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKY,1);
	else
		CheckDlgButton(IDC_CHECKY,0);

    GETPCZ(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKZ,1);
	else
		CheckDlgButton(IDC_CHECKZ,0);
    OnCheckx();
    OnChecky();
    OnCheckz();

    GETBOND_COORDNUMB(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDIT1, str);

    OnRadio1(); 
    OnRadio7(); 

	int i,n;
	GETGROUPNUMB(&n);
	for(i=1;i<=n; i++)
	{
	  sprintf(str,"%i",i);
	  ((CComboBox*)GetDlgItem(IDC_ATOM1))->AddString(str);
	  ((CComboBox*)GetDlgItem(IDC_ATOM2))->AddString(str);
	}
	int i1, i2;
    GETTYPE_COORDNUMB(&i1, &i2);
	sprintf(str,"%i",i1);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM1))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM1))->SetCurSel(i);
	sprintf(str,"%i",i2);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM2))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM2))->SetCurSel(i);

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);

    Kernal = NULL;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_CoordNumb::OnCheckx() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKX ) )
  {
	  GetDlgItem(IDC_STATICX)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITX)->EnableWindow(TRUE);
      i = 1;
  }
  else
  {
	  GetDlgItem(IDC_STATICX)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
      i = 0; 
 }
 SETPCX(&i);
}

void CDlg_CoordNumb::OnChecky() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKY ) )
  {
	  GetDlgItem(IDC_STATICY)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITY)->EnableWindow(TRUE);
      i = 1;;
  }
  else
  {
	  GetDlgItem(IDC_STATICY)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
      i = 0;
  }
  SETPCY(&i);
}

void CDlg_CoordNumb::OnCheckz() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKZ) )
  {
	  GetDlgItem(IDC_STATICZ)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITZ)->EnableWindow(TRUE);
      i =1;
  }
  else
  {
	  GetDlgItem(IDC_STATICZ)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
      i = 0; 
  }
 SETPCZ(&i);
}

void CDlg_CoordNumb::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_FIGFRAME) != NULL)
	{
	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 Fig.MoveWindow(&rect, TRUE);
	}
}

void CDlg_CoordNumb::OnRadio1() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
  GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
	
}

void CDlg_CoordNumb::OnRadio2() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
  GetDlgItem(IDC_ATOM1)->EnableWindow(TRUE);
	
}

void CDlg_CoordNumb::OnRadio7() 
{
  CheckRadioButton(IDC_RADIO7, IDC_RADIO8, IDC_RADIO7);
  GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
	
}

void CDlg_CoordNumb::OnRadio8() 
{
  CheckRadioButton(IDC_RADIO7, IDC_RADIO8, IDC_RADIO8);
  GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);

}

void CDlg_CoordNumb::OnSelchangeAtom1() 
{
	int i1 = ((CComboBox*)GetDlgItem(IDC_ATOM1))->GetCurSel()+1;
	int i2 = ((CComboBox*)GetDlgItem(IDC_ATOM2))->GetCurSel()+1;
    SETTYPE_COORDNUMB(&i1, &i2);
	
}

void CDlg_CoordNumb::OnSelchangeAtom2() 
{
    OnSelchangeAtom1();	
}

void CDlg_CoordNumb::OnExit() 
{
	CDialog::OnOK();
	
}

void CDlg_CoordNumb::OnOK() 
{
	OnButtonStart();
	
}

void CDlg_CoordNumb::OnButtonStart() 
{
	//*** to get lattice unit
    char str[32];
    float t;
    int err;

    GetDlgItemText(IDC_EDITLU, str,32);
    GETVALUE(str, &t, &err);
    if(t<= 0.f) 
    {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
    }
    SETLATTICEPARA(&t);	
	// to get box size
    GetDlgItemText(IDC_EDITX, str,32);
    GETVALUE(str, &t, &err);
    SETBOXX(&t);	
    GetDlgItemText(IDC_EDITY, str,32);
    GETVALUE(str, &t, &err);
    SETBOXY(&t);	
    GetDlgItemText(IDC_EDITZ, str,32);
    GETVALUE(str, &t, &err);
    SETBOXZ(&t);
	//to get bond range
    GetDlgItemText(IDC_EDIT1, str,32);
    GETVALUE(str, &t, &err);
    if(t <= 0)
    {
	  MessageBox("The bond length should be greater than zero", "",MB_OK);
      GETBOND_COORDNUMB(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDIT1, str);
	  return;
    }
    SETBOND_COORDNUMB(&t);	
	
	//** to begin calculation
    if(IsDlgButtonChecked(IDC_RADIO1)  )
	{
       if(IsDlgButtonChecked(IDC_RADIO7) )
          Kernal = AfxBeginThread(Cal_CoordNumbAllProc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	   else
          Kernal = AfxBeginThread(Cal_CoordNumbAll1Proc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	}
	else
	{
       if(IsDlgButtonChecked(IDC_RADIO7) )
          Kernal = AfxBeginThread(Cal_CoordNumb1AllProc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	   else
          Kernal = AfxBeginThread(Cal_CoordNumb11Proc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	}
	if(Kernal != NULL) //disable all contrals
	{
	   GetDlgItem(IDC_EDITLU)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKX)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKY)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKZ)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO7)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO8)->EnableWindow(FALSE);
	   GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_BUTTON_START)->EnableWindow(FALSE);
       SetTimer(nIDEvent, 100, NULL);
    }

	return;
	
}

void CDlg_CoordNumb::OnTimer(UINT nIDEvent) 
{
    DWORD  lpExitCode;
	if(Kernal == NULL) 
	{
	   GetDlgItem(IDC_PROMPT)->SetWindowText("");
	   return;
	}

	static int i=0;
	GetExitCodeThread(Kernal->m_hThread, &lpExitCode);
	{
	   if(lpExitCode != STILL_ACTIVE)
	   {
	     float X[21], Y[21];
	     int flag,bins;

         GETVALUE_COORDNUMB(&flag,&bins,X,Y);
	     Fig.NewCurve(0, bins, X, Y);
	     Fig.AutoYRange();
         Fig.ChangeXAxsis_nTick(5);
	     Fig.ChangeXRange(0.f, 20.f);
 	     Fig.CreateXAxsisLabel("%5.2f");
         Fig.ChangeXLabelScal(0.07f, 0.08f);
	     Fig.CreateXTitle("Coordination Number");
         Fig.CreateYTitle("Number of atoms");
         Fig.Addsymbole(XY_SYMB_SOLIDCIRCLE);
         Fig.ChangeCurveSymbColor();
         Fig.ChangeCurveSymbSize(0.02f);
		 Invalidate(FALSE);
		 Kernal = NULL;

		 //recover the status
	     GetDlgItem(IDC_EDITLU)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKX)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKY)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKZ)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_CHECKX ) )
         {
	        GetDlgItem(IDC_STATICX)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITX)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICX)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
         }

         if(IsDlgButtonChecked(IDC_CHECKY ) )
         {
	        GetDlgItem(IDC_STATICY)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITY)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICY)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
         }

         if(IsDlgButtonChecked(IDC_CHECKZ ) )
         {
	        GetDlgItem(IDC_STATICZ)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITZ)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICZ)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
         }
	     GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO2)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_RADIO1) )
	       GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
		 else
	       GetDlgItem(IDC_ATOM1)->EnableWindow(TRUE);

	     GetDlgItem(IDC_RADIO7)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO8)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_RADIO7) )
	       GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
		 else
	       GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);
	       GetDlgItem(IDC_BUTTON_START)->EnableWindow(TRUE);
           KillTimer(nIDEvent);
		   GetDlgItem(IDC_PROMPT)->SetWindowText("");
	       CDialog::OnTimer(nIDEvent);
		   return;
	   }
	}
	if(i < 10) 
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("Please Waiting...");
		i++;
	}
	else
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("");
		i++;
		if(i >= 15) i= 0;
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CDlg_CoordNumb::OnDestroy() 
{
	CDialog::OnDestroy();
	
    END_COORDNUMB();
    RELEASE_ANALYSISDATA();
}
