// Dlg_PDistrib.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_PDistrib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_PDistrib dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SET_ANALYSISDATA(int*,int*,float*,float*,float*);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
             void __stdcall GETPCX(int*);
             void __stdcall SETPCX(int*);
             void __stdcall GETPCY(int*);
             void __stdcall SETPCY(int*);
             void __stdcall GETPCZ(int*);
             void __stdcall SETPCZ(int*);
             void __stdcall GETBOXX(float*);
             void __stdcall SETBOXX(float*);
             void __stdcall GETBOXY(float*);
             void __stdcall SETBOXY(float*);
             void __stdcall GETBOXZ(float*);
             void __stdcall SETBOXZ(float*);
             void __stdcall SETMAXR_PARTDISTRIB(float*);
             void __stdcall GETMAXR_PARTDISTRIB(float*);
             void __stdcall SETBINS_PARTDISTRIB(int*);
             void __stdcall GETBINS_PARTDISTRIB(int*);
             void __stdcall SETORIG_PARTDISTRIB(float*, float*,float*);
             void __stdcall GETORIG_PARTDISTRIB(float*,float*,float*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);
             void __stdcall SETTYPE_PARTDISTRIB(int*);
             void __stdcall GETTYPE_PARTDISTRIB(int*);

             void __stdcall CAL_PARTDISTRIBALL();
			 void __stdcall CAL_PARTDISTRIB11();
             void __stdcall GETVALUE_PARTDISTRIB_G(int*, float*, float*);
             void __stdcall GETVALUE_PARTDISTRIB_GT(int*, float*, float*);
             void __stdcall END_PARTDISTRIB();
             void __stdcall RELEASE_ANALYSISDATA();
           }

CDlg_PDistrib::CDlg_PDistrib(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_PDistrib::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_PDistrib)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CDlg_PDistrib::~CDlg_PDistrib()
{

}


void CDlg_PDistrib::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_PDistrib)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_PDistrib, CDialog)
	//{{AFX_MSG_MAP(CDlg_PDistrib)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
	ON_BN_CLICKED(IDC_RADIO6, OnRadio6)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_CBN_SELCHANGE(IDC_ATOM2, OnSelchangeAtom2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_PDistrib message handlers

BOOL CDlg_PDistrib::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT rect,rect1;
	int W, H, L, L1;
	this->GetWindowRect(&rect);
	GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;

	Fig.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rect,this,0,NULL);

	float temp;
	int    itemp;
	char str[32];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);

	sprintf(str,"%f",x0);
	SetDlgItemText(IDC_EDITX, str);
	sprintf(str,"%f",y0);
	SetDlgItemText(IDC_EDITY, str);
	sprintf(str,"%f",z0);
	SetDlgItemText(IDC_EDITZ, str);
    OnRadio3(); 

    GETMAXR_PARTDISTRIB(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDIT1, str);

    GETBINS_PARTDISTRIB(&itemp);
	sprintf(str,"%i",itemp);
	SetDlgItemText(IDC_EDIT2, str);

    OnRadio1(); 
	int i,n;
	GETGROUPNUMB(&n);
	for(i=1;i<=n; i++)
	{
	  sprintf(str,"%i",i);
	  ((CComboBox*)GetDlgItem(IDC_ATOM2))->AddString(str);
	}
    GETTYPE_PARTDISTRIB(&i);
	sprintf(str,"%i",i);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM2))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM2))->SetCurSel(i);

    OnRadio5(); 

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_PDistrib::OnRadio1() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
  GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
}

void CDlg_PDistrib::OnRadio2() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
  GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);
}

void CDlg_PDistrib::OnRadio3() 
{
  CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO3);
  GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
  GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
  GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
  SETORIG_PARTDISTRIB(&xc, &yc, &zc);
}

void CDlg_PDistrib::OnRadio4() 
{
  CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO4);
  GetDlgItem(IDC_EDITX)->EnableWindow(TRUE);
  GetDlgItem(IDC_EDITY)->EnableWindow(TRUE);
  GetDlgItem(IDC_EDITZ)->EnableWindow(TRUE);
  SETORIG_PARTDISTRIB(&x0, &y0, &z0);
}

void CDlg_PDistrib::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  SET_ANALYSISDATA(&nxyz,ityp,x,y,z);

  int i;
  xc = 0.f;
  yc = 0.f;
  zc = 0.f;
  for(i=0; i<nxyz; i++)
  {
	  xc = xc + x[i];
	  yc = yc + x[i];
	  zc = zc + x[i];
  }
  xc =xc/(float)nxyz;
  yc =yc/(float)nxyz;
  zc =zc/(float)nxyz;
  x0 =xc;
  y0 =yc;
  z0 =zc;
  SETORIG_PARTDISTRIB(&x0,&y0,&z0);
}



void CDlg_PDistrib::OnChangeEdit2() 
{
  char str[32];
  int err;

  GetDlgItemText(IDC_EDIT2, str,32);
  err = atoi(str);
  if(err <= 0)
  {
	  MessageBox("The number of bins smaller than zero", "",MB_OK);
      GETBINS_PARTDISTRIB(&err);	
	  sprintf(str,"%i",err);
      SetDlgItemText(IDC_EDIT2, str);
	  return;
  }
  SETBINS_PARTDISTRIB(&err);	
	
}


void CDlg_PDistrib::OnDestroy() 
{
    END_PARTDISTRIB();
    RELEASE_ANALYSISDATA();
	CDialog::OnDestroy();
}


void CDlg_PDistrib::OnButtonStart() 
{
	//** to get the lattice unit
    char str[32];
    float t;
    int err;

    GetDlgItemText(IDC_EDITLU, str,32);
    GETVALUE(str, &t, &err);
    if(t<= 0.f) 
    {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
    }
    SETLATTICEPARA(&t);	
	//** to get the maxma range
    GetDlgItemText(IDC_EDIT1, str,32);
	GETVALUE(str, &t, &err);
    if(t <= 0)
    {
	  MessageBox("The max value of range should be greater than zero","", MB_OK);
      GETMAXR_PARTDISTRIB(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDIT1, str);
	  return;
    }
    SETMAXR_PARTDISTRIB(&t);	
	//** to get the define center
    GetDlgItemText(IDC_EDITX, str,32);
    GETVALUE(str, &x0, &err);
    GetDlgItemText(IDC_EDITX, str,32);
    GETVALUE(str, &y0, &err);
    GetDlgItemText(IDC_EDITX, str,32);
    GETVALUE(str, &z0, &err);

	//*** to begin the calcualtion
	float*R, *G;
	int bins;

	GETBINS_PARTDISTRIB(&bins);
	if(bins == 0) return;
    R  = new float[bins];
    G  = new float[bins];
    if(IsDlgButtonChecked(IDC_RADIO3)  )
       SETORIG_PARTDISTRIB(&xc, &yc, &zc);
	else
       SETORIG_PARTDISTRIB(&x0, &y0, &z0);

    GetDlgItem(IDC_PROMPT)->SetWindowText("Calculation started...");
    if(IsDlgButtonChecked(IDC_RADIO1)  )
	{
       CAL_PARTDISTRIBALL();
	}
	else
	{
       CAL_PARTDISTRIB11();
	}
    GetDlgItem(IDC_PROMPT)->SetWindowText("");
    if(IsDlgButtonChecked(IDC_RADIO5) )
	{
       GETVALUE_PARTDISTRIB_G(&bins,R, G);
	   Fig.NewCurve(0, bins, R, G);
	}
	else
	{
       GETVALUE_PARTDISTRIB_GT(&bins,R, G);
	   Fig.NewCurve(0, bins, R, G);
	}
	Fig.AutoYRange();
	float rmax, alta,temp;
    GETMAXR_PARTDISTRIB(&rmax);
	GETLATTICEPARA(&alta);
	temp = ((int)(rmax/alta)+1);
	Fig.ChangeXRange(0.f, temp*alta);
    if(temp > 5) temp = 5;
    Fig.ChangeXAxsis_nTick((int)temp);

 	Fig.CreateXAxsisLabel("%5.2f");
    Fig.ChangeXLabelScal(0.07f, 0.08f);
	Fig.CreateXTitle("r (in lattice unit)");

    if(IsDlgButtonChecked(IDC_RADIO5) )
       Fig.CreateYTitle("Density in r-r+dr (arb.unit)");
	else
       Fig.CreateYTitle("Number of atom in r-r+dr (arb.unit)");

	delete R;
	delete G;
}

void CDlg_PDistrib::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_FIGFRAME) != NULL)
	{
	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 Fig.MoveWindow(&rect, TRUE);
	}
}

void CDlg_PDistrib::OnRadio5() 
{
  CheckRadioButton(IDC_RADIO5, IDC_RADIO6, IDC_RADIO5);
}

void CDlg_PDistrib::OnRadio6() 
{
  CheckRadioButton(IDC_RADIO5, IDC_RADIO6, IDC_RADIO6);
}

void CDlg_PDistrib::OnExit() 
{
	CDialog::OnOK();
}


void CDlg_PDistrib::OnOK() 
{
	OnButtonStart();
	return;
}


void CDlg_PDistrib::OnSelchangeAtom2() 
{
   int i = ((CComboBox*)GetDlgItem(IDC_ATOM2))->GetCurSel()+1;
   SETTYPE_PARTDISTRIB(&i);
}
