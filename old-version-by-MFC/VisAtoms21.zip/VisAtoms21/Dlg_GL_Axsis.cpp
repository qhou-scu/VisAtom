// Dlg_GL_Axsis.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_GL_Axsis.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_GL_Axsis dialog


CDlg_GL_Axsis::CDlg_GL_Axsis(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_GL_Axsis::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_GL_Axsis)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg_GL_Axsis::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_GL_Axsis)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_GL_Axsis, CDialog)
	//{{AFX_MSG_MAP(CDlg_GL_Axsis)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_GL_Axsis message handlers

BOOL CDlg_GL_Axsis::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT lpRect;
	GetClientRect(&lpRect);
	m_Axsis.Create(NULL,NULL, WS_VISIBLE|WS_CHILD| WS_CLIPCHILDREN | WS_CLIPSIBLINGS, lpRect, this, 0, NULL);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlg_GL_Axsis::UpdateMatrix(double mat[]) 
{
	m_Axsis.UpdateMatrix(mat);
}


void CDlg_GL_Axsis::OnDestroy() 
{
	CDialog::OnDestroy();
	
	m_Axsis.DestroyWindow();

}
