// VisAtoms21Doc.h : interface of the CVisAtoms21Doc class
//
/////////////////////////////////////////////////////////////////////////////
#include "Dlg_OpenFormat.h"
#include "Atoms21.h"

class CVisAtoms21Doc : public CDocument
{
protected: // create from serialization only
	CVisAtoms21Doc();
	DECLARE_DYNCREATE(CVisAtoms21Doc)

// Attributes
public:
	CDlg_OpenFormat fmt;
	int  ifNext;
	int  ifInRead;
// Operations
public:
	char WorkDir[260];
	Atoms21 m_Sample;
	Atoms21 m_SampleCopy; 
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVisAtoms21Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVisAtoms21Doc();
	Atoms21*GetSample(){return &m_Sample;};
	Atoms21*GetSampleTemp(){return &m_SampleCopy;};
    int     GetCurrentFirstFname(char*fname);
	int     ReadFirstFile();
	int     ReadLastFile();
	int     ReadPreviousFile();
	int     ReadNextFile();
	int     frameIDmi, frameIDmx;

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CVisAtoms21Doc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
