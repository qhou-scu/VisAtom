// ChangeProperty.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "ChangeProperty.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChangeProperty

IMPLEMENT_DYNAMIC(CChangeProperty, CPropertySheet)

CChangeProperty::CChangeProperty(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&DrawingSty);
}

CChangeProperty::CChangeProperty(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&DrawingSty);
}

CChangeProperty::~CChangeProperty()
{
}


BEGIN_MESSAGE_MAP(CChangeProperty, CPropertySheet)
	//{{AFX_MSG_MAP(CChangeProperty)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChangeProperty message handlers
