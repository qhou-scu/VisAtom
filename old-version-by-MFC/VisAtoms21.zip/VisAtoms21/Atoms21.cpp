#include "stdafx.h"
#include <Glc.h>
#include <math.h>

#include "Atoms21.h"



void Atoms21::ReleaseAll()
{
	Sample::ReleaseAll();

	if(vx != NULL) delete vx;
	if(vy != NULL) delete vy;
	if(vz != NULL) delete vz;
	if(fx != NULL) delete fx;
	if(fy != NULL) delete fy;
	if(fz != NULL) delete fz;
	if(r  != NULL) delete r;
	if(R  != NULL) delete R;
	if(G  != NULL) delete G;
	if(B  != NULL) delete B;
	vx = NULL;
	vy = NULL;
	vz = NULL;
	fx = NULL;
	fy = NULL;
	 r = NULL;
	 R = NULL;
	 G = NULL;
	 B = NULL;

}



Atoms21::~Atoms21()
{
    ReleaseAll();
}

Atoms21::Atoms21() :Sample()
{
	vx      = NULL;
	vy      = NULL;
	vz      = NULL;
	fx      = NULL;
	fy      = NULL;
	fz      = NULL;
	r       = NULL;
	R       = NULL;
	G       = NULL;
	B       = NULL;

	vzoom = 0.85f;
	vFactor = 0.01f;
	lvzoom = 0.85f;
	lvFactor = 1.00f;
	fzoom = 0.85f;
	fFactor = 0.01f;
	lfzoom = 0.85f;
	lfFactor = 1.00f;

	style = 1;
}

Atoms21::Atoms21(Atoms21*p) :Sample(p)
{
	vx      = NULL;
	vy      = NULL;
	vz      = NULL;
	fx      = NULL;
	fy      = NULL;
	fz      = NULL;
	r       = NULL;
	R       = NULL;
	G       = NULL;
	B       = NULL;

	vzoom = 0.85f;
	vFactor = 0.01f;
	lvzoom = 0.85f;
	lvFactor = 1.00f;
	fzoom = 0.85f;
	fFactor = 0.01f;
	lfzoom = 0.85f;
	lfFactor = 1.00f;
	style = 1;
}


/* To draw the atoms*/
void Atoms21::Paint()
{
	
   if(curActive) 
   {
	 glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	 glMatrixMode(GL_MODELVIEW);
     glEnable(GL_DEPTH_TEST);
	 Draw();
   }
   if(next != NULL) ((Atoms21*)next)->Paint();
   return;
}

//To draw the atoms
void Atoms21::Draw()
{
	
   if(nxyz <= 0) return;

   switch (style&style_mask)
   {
   case style_SubSamples:  //to draw according to properties of subsamples
	   {
         int i,I,k;

		 // firstly, to draw circles if there are
	     for(i=0; i<group->Numb_of_subSample(); i++)
	     {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) 
		   {
		    k = group->GetStyle(I);
	 	    switch (k&0x0000000F)
		    {
		    case style_SubSample_Circle: 
				{
				 Sample::DrawCircleAtoms(I); 
		         break; 
				}
			}
		   }
		 }
		 //then, draw atoms of other style
	     for(i=0; i<group->Numb_of_subSample(); i++)
	     {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) 
		   {
		    k = group->GetStyle(I);
	 	    switch (k&0x0000000F)
		    {
		    case  style_SubSample_Dot: 
				{
				 Sample::DrawDotAtoms(I); 
		         break; 
				}
            case  style_SubSample_Wire:
			    {
				 Sample::DrawWireAtoms(I); 
		         break;
			     }
            case  style_SubSample_Solid:
				{
				  Sample::DrawSolidAtoms(I); 
		         break;
				}
            case  style_SubSample_WireVelocity:
				{
				  DrawWireVelocity(I); 
		         break;
				}
            case  style_SubSample_SolidVelocity:
				{
				  DrawSolidVelocity(I); 
		         break;
				}
            case  style_SubSample_WireForce:
				{
				  DrawWireForce(I); 
		         break;
				}
            case  style_SubSample_SolidForce:
				{
				  DrawSolidForce(I); 
		         break;
				}
		    } //switch
		   } //visiable
		 } // for
		 return ;
	   }
   }

 // to draw atoms according to the properties of each atom
 if((style&style_Independent_radiu) && (style&style_Independent_color) )
 {
   switch (style&style_mask)
   {

   case style_Atom_Dot: 
	    DrawDotAtoms_ICR();
		break;
   case style_Atom_Circle:  
    
   case style_Atom_Wire:  
	   DrawWireAtoms_ICR();
	   break;

   case style_Atom_Solid:  
	   DrawSolidAtoms_ICR();
	   break;
   }
   return;
 }

 if((style&style_Independent_radiu))
 {
   switch (style&style_mask)
   {

   case style_Atom_Dot: 
	    DrawDotAtoms_IR();
		break;
   case style_Atom_Circle:  
    
   case style_Atom_Wire:  
	   DrawWireAtoms_IR();
	   break;

   case style_Atom_Solid:  
	   DrawSolidAtoms_IR();
	   break;
   }
   return;
 }
 
 if((style&style_Independent_color))
 {
   switch (style&style_mask)
   {

   case style_Atom_Dot: 
	    DrawDotAtoms_IC();
        return;
   case style_Atom_Circle:  
    
   case style_Atom_Wire:  
	    DrawWireAtoms_IC();
	    return;
   case style_Atom_Solid:  
	    DrawSolidAtoms_IC();
	    return;
   }
 }
  
 switch (style&style_mask)
 {
  case style_Atom_Dot: 
	    DrawDotAtoms();
		break;
  case style_Atom_Circle:  
	   DrawCircleAtoms();
	   break;
  case style_Atom_Wire:  
	   DrawWireAtoms();
	   break;

   case style_Atom_Solid:  
	   DrawSolidAtoms();
	   break;

   case style_Velocity_Wire:  
	   DrawWireVelocity();
	   break;
   case style_Velocity_Solid:  
	   DrawSolidVelocity();
	   break;
   case style_Force_Wire:  
	   DrawWireForce();
	   break;
   case style_Force_Solid:  
	   DrawSolidForce();
	   break;

 }
 return;
}

//To draw atoms atom by atoms; 
void Atoms21::DrawDotAtoms()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) Sample::DrawDotAtoms(I);
	   }

	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different color
void Atoms21::DrawDotAtoms_IC()
{
   if(nxyz <= 0) return;

       glEnable(GL_DEPTH_TEST);
       glDisable(GL_LIGHTING);
       glPointSize(4.f);
       int i;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
            glColor4f(R[i],G[i],B[i],1.f);
		    glPushName(i);
	        glBegin(GL_POINTS);
		    glVertex3f(x[i], y[i], z[i]);
            glEnd();
		    glPopName();
		  }
	   }

	return;
}


//To draw atoms atom by atoms; the atoms in the same group could have different size
void Atoms21::DrawDotAtoms_IR()
{
    DrawDotAtoms();
	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different size
void Atoms21::DrawDotAtoms_ICR()
{
    DrawDotAtoms_IC();
	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different color
//and size
void Atoms21::DrawSolidAtoms()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) Sample::DrawSolidAtoms(I);
	   }

	return;
}


//To draw atoms atom by atoms; the atoms in the same group could have different color
void Atoms21::DrawSolidAtoms_IC()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Solid();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       int i;
	   float gr;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
	        Balls.ChangeColor(R[i],G[i],B[i]);
		    glPushName(i);
 	            Balls.Moveto(x[i], y[i], z[i]);
				group->GetRadiu(ityp[i], &gr);
	            Balls.ChangeSize(gr);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different radiu
void Atoms21::DrawSolidAtoms_IR()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Solid();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       int i;
	   float gR, gG, gB;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
			group->GetColor(ityp[i], &gR, &gG, &gB);
	        Balls.ChangeColor(gR,gG,gB);
 	        Balls.Moveto(x[i], y[i], z[i]);
	        Balls.ChangeSize(r[i]);
		    glPushName(i);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}


//To draw atoms atom by atoms; the atoms in the same group could have different radiu
void Atoms21::DrawSolidAtoms_ICR()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Solid();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       int i;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
	        Balls.ChangeColor(R[i], G[i], B[i]);
	        Balls.ChangeSize(r[i]);
 	        Balls.Moveto(x[i], y[i], z[i]);
		    glPushName(i);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}


void Atoms21::DrawWireAtoms()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) Sample::DrawWireAtoms(I);
	   }

	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different color
void Atoms21::DrawWireAtoms_IC()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Wire();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       glPointSize(4.f);
       int i;
	   float gr;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
	        Balls.ChangeColor(R[i],G[i],B[i]);
		    glPushName(i);
 	            Balls.Moveto(x[i], y[i], z[i]);
				group->GetRadiu(ityp[i], &gr);
	            Balls.ChangeSize(gr);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different radiu
void Atoms21::DrawWireAtoms_IR()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Wire();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       int i;
	   float gR, gG, gB;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
			group->GetColor(ityp[i], &gR, &gG, &gB);
	        Balls.ChangeColor(gR,gG,gB);
 	        Balls.Moveto(x[i], y[i], z[i]);
	        Balls.ChangeSize(r[i]);
		    glPushName(i);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}

//To draw atoms atom by atoms; the atoms in the same group could have different radiu
void Atoms21::DrawWireAtoms_ICR()
{
   if(nxyz <= 0) return;

       Style  Sty;
       Sphere Balls=Sphere();
	   Sty.Wire();


       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
       int i;
	   for(i=0; i<nxyz; i++)
	   {
		if(astatu[i]&atom_Statu_Visiable)
		 {
	        Balls.ChangeColor(R[i], G[i], B[i]);
	        Balls.ChangeSize(r[i]);
 	        Balls.Moveto(x[i], y[i], z[i]);
		    glPushName(i);
		        Balls.Paint();
		    glPopName();
	     }
	   }

	return;
}


//To draw velocity of all atoms
void Atoms21::DrawWireVelocity()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) DrawWireVelocity(I);
	   }

	return;
}

//To draw atom of type I in style of wire velocity
void Atoms21::DrawWireVelocity(int I)
{
  int j;
  float R, G, B, r;
	   if(group->GetStatu(I)&SubSample_Statu_Visiable)
		 {
           Style  Sty;
           Arrow  V=Arrow();

           glEnable(GL_DEPTH_TEST);
		   glEnable(GL_LIGHTING);
	       Sty.Wire();

           //glLoadName(i+1);
		   group->GetColor(I, &R, &G, &B);
		   group->GetRadiu(I,&r);
	       V.ChangeSize(r);
	       V.ChangeColor(R,G,B);

		   for(j=0; j<nxyz; j++)
	       {
			  if((astatu[j]&atom_Statu_Visiable) && ityp[j] == I)
		      {
 	            V.ResetStartPoint(x[j], y[j], z[j]);
	            V.ResetEndPoint(x[j]+vx[j], y[j]+vy[j], z[j]+vz[j]);
				glPushName(j);
		        V.Paint();
			    glPopName();

			  }
		   }
	   }

	return;
}

//To draw velocity of all atoms
void Atoms21::DrawSolidVelocity()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) DrawSolidVelocity(I);
	   }

	return;
}
//To draw atom of type I in style of solid velocity
void Atoms21::DrawSolidVelocity(int I)
{
  int j;
  float R, G, B, r;
	   if(group->GetStatu(I)&SubSample_Statu_Visiable)
		 {
           Style  Sty;
           Arrow  V=Arrow();

           glEnable(GL_DEPTH_TEST);
		   glEnable(GL_LIGHTING);
	       Sty.Solid();

           //glLoadName(i+1);
		   group->GetColor(I, &R, &G, &B);
		   group->GetRadiu(I,&r);
	       V.ChangeSize(r);
	       V.ChangeColor(R,G,B);

		   for(j=0; j<nxyz; j++)
	       {
			  if((astatu[j]&atom_Statu_Visiable) && ityp[j] == I)
		      {
 	            V.ResetStartPoint(x[j], y[j], z[j]);
	            V.ResetEndPoint(x[j]+vx[j], y[j]+vy[j], z[j]+vz[j]);
				glPushName(j);
		        V.Paint();
			    glPopName();

			  }
		   }
	   }

	return;
}

//To draw force of all atoms
void Atoms21::DrawWireForce()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) DrawWireVelocity(I);
	   }

	return;
}
//To draw atom of type I in style of solid force
void Atoms21::DrawWireForce(int I)
{
  int j;
  float R, G, B, r;
	   if(group->GetStatu(I)&SubSample_Statu_Visiable)
		 {
           Style  Sty;
           Arrow  V=Arrow();

           glEnable(GL_DEPTH_TEST);
		   glEnable(GL_LIGHTING);
	       Sty.Wire();

           //glLoadName(i+1);
		   group->GetColor(I, &R, &G, &B);
		   group->GetRadiu(I,&r);
	       V.ChangeSize(r);
	       V.ChangeColor(R,G,B);

		   for(j=0; j<nxyz; j++)
	       {
			  if((astatu[j]&atom_Statu_Visiable) && ityp[j] == I)
		      {
 	            V.ResetStartPoint(x[j], y[j], z[j]);
	            V.ResetEndPoint(x[j]+fx[j], y[j]+fy[j], z[j]+fz[j]);
				glPushName(j);
		        V.Paint();
			    glPopName();

			  }
		   }
	   }

	return;
}

//To draw force of all atoms
void Atoms21::DrawSolidForce()
{
   
   if(nxyz <= 0) return;

       int i,I;
	   for(i=0; i<group->Numb_of_subSample(); i++)
	   {
		   I = group->GetType(i+1);
		   if(group->IfVisiable(I)) DrawWireVelocity(I);
	   }

	return;
}
//To draw atom of type I in style of solid force
void Atoms21::DrawSolidForce(int I)
{
  int j;
  float R, G, B, r;
	   if(group->GetStatu(I)&SubSample_Statu_Visiable)
		 {
           Style  Sty;
           Arrow  V=Arrow();

           glEnable(GL_DEPTH_TEST);
		   glEnable(GL_LIGHTING);
	       Sty.Solid();

           //glLoadName(i+1);
		   group->GetColor(I, &R, &G, &B);
		   group->GetRadiu(I,&r);
	       V.ChangeSize(r);
	       V.ChangeColor(R,G,B);

		   for(j=0; j<nxyz; j++)
	       {
			  if((astatu[j]&atom_Statu_Visiable) && ityp[j] == I)
		      {
 	            V.ResetStartPoint(x[j], y[j], z[j]);
	            V.ResetEndPoint(x[j]+fx[j], y[j]+fy[j], z[j]+fz[j]);
				glPushName(j);
		        V.Paint();
			    glPopName();

			  }
		   }
	   }

	return;
}


void Atoms21::DrawCircleAtoms()
{
   
   if(nxyz <= 0) return;

     int i,I;
	 for(i=0; i<group->Numb_of_subSample(); i++)
	 {
	   I = group->GetType(i+1);
	   if(group->IfVisiable(I)) Sample::DrawCircleAtoms(I);
	 }
}


//
extern "C" { 
           void __stdcall READBYCOLUME(char*, int*, int*, int*, int*, int*, float*);
            }
//To import the configure for the atoms
int Atoms21::Import_Config(char fname[], int nLine, int nCol, int nStep, int fmt[], int flag[]) 
{

	 int i,j,k, nVar;

	  float *tvar;
	  int tflag[20];

	  nxyz = nLine;

	  nVar = 0;
	  if(fmt[0]) 
  	  {  
		 tflag[nVar]= flag[0];
		 nVar++;
	  }
	  if(fmt[1]) 
  	  {  
		 tflag[nVar]= flag[1];
		 nVar++;
		 tflag[nVar]= flag[2];
		 nVar++;
		 tflag[nVar]= flag[3];
		 nVar++;
	  }
	  if(fmt[2]) 
  	  {  
		 tflag[nVar]= flag[4];
		 nVar++;
		 tflag[nVar]= flag[5];
		 nVar++;
		 tflag[nVar]= flag[6];
		 nVar++;
	  }
	  if(fmt[3]) 
  	  {  
		 tflag[nVar]= flag[7];
		 nVar++;
		 tflag[nVar]= flag[8];
		 nVar++;
		 tflag[nVar]= flag[9];
		 nVar++;
	  }
	  if(fmt[4]) 
  	  {  
		 tflag[nVar]= flag[10];
		 nVar++;
		 tflag[nVar]= flag[11];
		 nVar++;
		 tflag[nVar]= flag[12];
		 nVar++;
	  }
	  if(fmt[5]) 
  	  {  
		 tflag[nVar]= flag[13];
		 nVar++;
	  }
	  
	  tvar  = new float[nVar*nxyz];
      READBYCOLUME(fname, &nLine, &nStep, &nCol, &nVar, tflag, tvar);
	  
	  j = 0;
	  if(fmt[0]) 
  	  {  
		 ityp = new int[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     ityp[i] = tvar[k]+0.001;
			 k = k+nVar;
		 }
		 j++;
	  }
	  if(fmt[1]) 
  	  {  
		 x = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     x[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;
		 y = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     y[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;
		 z = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     z[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;
	  }
	  if(fmt[2]) 
  	  {  
		 vx = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     vx[i] = tvar[k]*lvFactor;
			 k = k+nVar;
		 }
		 j++;
		 vy = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     vy[i] = tvar[k]*lvFactor;
			 k = k+nVar;
		 }
		 j++;
		 vz = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     vz[i] = tvar[k]*lvFactor;
			 k = k+nVar;
		 }
		 j++;
	  }
	  if(fmt[3]) 
  	  {  
		 fx = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     fx[i] = tvar[k]*lfFactor;
			 k = k+nVar;
		 }
		 j++;
		 fy = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     fy[i] = tvar[k]*lfFactor;
			 k = k+nVar;
		 }
		 j++;
		 fz = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     fz[i] = tvar[k]*lfFactor;
			 k = k+nVar;
		 }
		 j++;
	  }
	  if(fmt[4]) 
  	  {  
		 R = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     R[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;
		 G = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     G[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++; 
		 B = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     B[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;

	  }
	  if(fmt[5]) 
  	  {  
		 r = new float[nxyz];
		 k = j;
		 for(i=0; i<nxyz; i++) 
		 { 
		     r[i] = tvar[k];
			 k = k+nVar;
		 }
		 j++;
	  }

	  astatu = new int[nxyz];
	  for(i=0; i<nxyz; i++) astatu[i] = atom_Statu_Visiable;

	  //To create subsamples
	  if(!fmt[0]) 
	  {
		ityp = new int[nxyz];
		for(i=0; i<nxyz; i++) ityp[i] = 1;
        group->New(1, 0.7f, 0.7f, 0.7f);
        group->Add_atoms(1, nxyz);
	    group->Rzoom(1, rFactor);
      }
	  else
	  {
		int nmax, nmin;
		nmax = 0;
		nmin = 10000000;
		for(i=0; i<nxyz; i++) 
		{ if(ityp[i] > nmax) nmax = ityp[i];
		  if(ityp[i] < nmin) nmin = ityp[i];
		}
		for(i=nmin; i<=nmax; i++) 
		{
		  group->New(i, 0.7f, 0.7f, 0.7f);
	      group->Rzoom(i, rFactor);
		}
		for(i=0; i<nxyz; i++) 
            group->Add_atoms(ityp[i], 1);
	  }	  
	  //To arrange the color for subsamples
	  if(!fmt[4])
	  {
		 int I;
		 float R, G, B;
		 for(i=0; i<group->Numb_of_subSample(); i++)
		 {
			 R = (float)rand()/(float)RAND_MAX;
			 G = (float)rand()/(float)RAND_MAX;
			 B = (float)rand()/(float)RAND_MAX;
			 I = group->GetType(i);
			 group->ChangeColor(I, R, G, B);
		 }
	  }
	  else
	  {
		 for(i=0; i<nxyz; i++)
			 group->ChangeColor(ityp[i], R[i], G[i], B[i]);
	  }
	  
      delete tvar;
	  return nxyz;
}


//To group the atoms by thire color
int Atoms21::GroupAtomsbyColor() 
{

	 int i,nType, style1;
	 float tR, tG, tB;

	 if(R == NULL) return 0;
	 if(G == NULL) return 0;
	 if(B == NULL) return 0;
	 tR = -1.f;
	 tG = -1.f;
	 tB = -1.f;
	 nType = 0;
	 style1 = group->GetStyle(1);
	 for(i=0; i<nxyz; i++)
	 {
	   if( (R[i] != tR) || (G[i] != tG) || (B[i] != tB) ) 
	   {  
		   tR = R[i];
		   tG = G[i];
		   tB = B[i];
		   nType++;
		   if(!group->IfExist(nType) ) 
		   {
			  group->New(nType, tR, tG, tB);
			  group->ChangeStyle(nType,style1);
	          group->Rzoom(nType, rFactor);
		   }
	       group->ChangeColor(nType, tR, tG, tB);
	   }
	   ityp[i] = nType;
	 }

	 int I = group->Numb_of_subSample();
	 for(i=0; i<I; i++)	group->Delete_atoms(i);
	 
	 for(i=0; i<nxyz; i++)
	 {
		group->Add_atoms(ityp[i],1);
	 }

	 return nType;
}


/* To multiply a factor to the radiu of all kinds of atoms*/
void Atoms21::Rzoomin()
{
	float tR;
	if(rzoom<=1.f) tR=1.f/rzoom;
	else tR = rzoom;
    rFactor = rFactor*tR;
    group->Rzoom(tR);
	if(r == NULL) return;

	int i;
	for(i=0; i<nxyz; i++) r[i] = r[i]*tR;
}

/* To multiply a factor to the radiu of all kinds of atoms*/
void Atoms21::Rzoomout()
{
	float tR;
	if(rzoom >1.f) tR=1.f/rzoom;
	else tR = rzoom;
    rFactor = rFactor*tR;
    group->Rzoom(tR);
	if(r == NULL) return;

	int i;
	for(i=0; i<nxyz; i++) r[i] = r[i]*tR;
}


//To change length of vectors
void Atoms21::LzoominV()
{
	float tL;
	int   i;

	 if(vzoom>=1.f) tL=1.f/vzoom;
	 else tL=vzoom;

	 for(i=0; i<nxyz; i++)
	 {
	    vx[i] = vx[i]*tL;
	    vy[i] = vy[i]*tL;
	    vz[i] = vz[i]*tL;
	 } 
    lvFactor *= tL; 
}


void Atoms21::LzoomoutV()
{
	float tL;
	int i;

    if(vzoom<=1.f) tL=1.f/vzoom;
    else tL=vzoom;
    for(i=0; i<nxyz; i++)
    {
     vx[i] = vx[i]*tL;
     vy[i] = vy[i]*tL;
     vz[i] = vz[i]*tL;
    } 
    lvFactor *= tL; 
	return;
}

//To change length of vectors
void Atoms21::LzoominF()
{
	float tL;
	int   i;

	 if(fzoom>=1.f) tL=1.f/fzoom;
	 else tL=fzoom;

	 for(i=0; i<nxyz; i++)
	 {
	    fx[i] = fx[i]*tL;
	    fy[i] = fy[i]*tL;
	    fz[i] = fz[i]*tL;
	 } 
    lfFactor *= tL; 
}


void Atoms21::LzoomoutF()
{
	float tL;
	int i;

    if(fzoom<=1.f) tL=1.f/fzoom;
    else tL=fzoom;
    for(i=0; i<nxyz; i++)
    {
     fx[i] = fx[i]*tL;
     fy[i] = fy[i]*tL;
     fz[i] = fz[i]*tL;
    } 
    lfFactor *= tL; 
	return;
}

//To change length of vectors
int Atoms21::Lzoomin()
{
	int   i,I,n;
	int   iF, iV;

	 n = group->Numb_of_subSample();

	 iF = 0;
	 iV = 0;
	 for(i=0; i<n; i++)
	 {
		int type;
		I = group->GetType(i);
		type = group->GetStyle(I);
		
		if(type == style_SubSample_WireVelocity || type == style_SubSample_SolidVelocity)
			iV = 1;
		if(type == style_SubSample_WireForce || type == style_SubSample_SolidForce)
			iF = 1;
	 }

     if(style == style_Velocity_Wire || style == style_Velocity_Solid) iV = 1;
     if(style == style_Force_Wire || style == style_Force_Solid) iF = 1;

	 if(iV) LzoominV();
	 if(iF) LzoominF();

	 return (iV|iF); 
}

//To change length of vectors
int Atoms21::Lzoomout()
{
	int   i,I,n;
	int   iF, iV;

	 n = group->Numb_of_subSample();

	 iF = 0;
	 iV = 0;
	 for(i=0; i<n; i++)
	 {
		int type;
		I = group->GetType(i);
		type = group->GetStyle(I);
		
		if(type == style_SubSample_WireVelocity || type == style_SubSample_SolidVelocity)
			iV = 1;
		if(type == style_SubSample_WireForce || type == style_SubSample_SolidForce)
			iF = 1;
	 }
     if(style == style_Velocity_Wire || style == style_Velocity_Solid) iV = 1;
     if(style == style_Force_Wire || style == style_Force_Solid) iF = 1;

	 if(iV) LzoomoutV();
	 if(iF) LzoomoutF();

	 return (iV|iF); 
}


//To copy a source sample
void Atoms21::CopySample(Atoms21*source)
{

  Sample::CopySample(source);

  style = source->style;
  vzoom = source->vzoom;
  vFactor = source->vFactor;
  lvzoom = source->lvzoom;
  lvFactor = source->lvFactor;
  lvm = source->lvm;

  fzoom = source->fzoom;
  fFactor = source->fFactor;
  lfzoom = source->lfzoom;
  lfFactor = source->lfFactor;
  lfm = source->lfm;

  if(vx != NULL) delete vx;
  if(vy != NULL) delete vy;
  if(vz != NULL) delete vz;
  if(fx != NULL) delete fx;
  if(fy != NULL) delete fy;
  if(fz != NULL) delete fz;
  if(R != NULL) delete R;
  if(G != NULL) delete G;
  if(B != NULL) delete B;
  if(r != NULL) delete r;

  int i;
  if( (source->vx != NULL) && (source->vy != NULL) && (source->vz != NULL) )
  {  vx = new float[nxyz];
	 vy = new float[nxyz];
	 vz = new float[nxyz];
     for(i=0; i<nxyz; i++)
     {
	   vx[i] = source->vx[i];
	   vy[i] = source->vy[i];
	   vz[i] = source->vz[i];
     }
  }

  if( (source->fx != NULL) && (source->fy != NULL) && (source->fz != NULL) ) 
  { 
	fx = new float[nxyz];
	fy = new float[nxyz];
	fz = new float[nxyz];
    for(i=0; i<nxyz; i++)
    {
	  fx[i] = source->fx[i];
	  fy[i] = source->fy[i];
	  fz[i] = source->fz[i];
	}
  }

  if( (source->R != NULL) && (source->G != NULL) && (source->B != NULL) )
  {
	 R = new float[nxyz];
	 G = new float[nxyz];
	 B = new float[nxyz];
     for(i=0; i<nxyz; i++)
     {
	  R[i] = source->R[i];
	  G[i] = source->G[i];
	  B[i] = source->B[i];
	 }
  }

}

//To copy a source sample
void Atoms21::CopySelectedAtoms(Atoms21*source)
{

  Sample::CopySelectedAtoms(source);

  if(nxyz == 0) return;

  style = source->style;
  vzoom = source->vzoom;
  vFactor = source->vFactor;
  lvzoom = source->lvzoom;
  lvFactor = source->lvFactor;
  lvm = source->lvm;

  fzoom = source->fzoom;
  fFactor = source->fFactor;
  lfzoom = source->lfzoom;
  lfFactor = source->lfFactor;
  lfm = source->lfm;

  if(vx != NULL) delete vx;
  if(vy != NULL) delete vy;
  if(vz != NULL) delete vz;
  if(fx != NULL) delete fx;
  if(fy != NULL) delete fy;
  if(fz != NULL) delete fz;
  if(R != NULL) delete R;
  if(G != NULL) delete G;
  if(B != NULL) delete B;
  if(r != NULL) delete r;

  int i, ic;
  if( (source->vx != NULL) && (source->vy != NULL) && (source->vz != NULL) )
  {
	 vx = new float[nxyz];
	 vy = new float[nxyz];
	 vz = new float[nxyz];

     ic = 0;
     for(i=0; i<source->nxyz; i++)
     {
      if((source->astatu[i]&atom_Statu_Selected) && 
	    (source->astatu[i]&atom_Statu_Visiable) )
	    {
	     vx[ic] = source->vx[i];
	     vy[ic] = source->vy[i];
	     vz[ic] = source->vz[i];
	     ic++;
         }
	 }
  }

  if( (source->fx != NULL) && (source->fy != NULL) && (source->fz != NULL) )
  {	  
    fx = new float[nxyz];
    fy = new float[nxyz];
    fz = new float[nxyz];

    ic = 0;
    for(i=0; i<source->nxyz; i++)
    {
       if((source->astatu[i]&atom_Statu_Selected) && 
	   (source->astatu[i]&atom_Statu_Visiable) )
	   {
	    fx[ic] = source->fx[i];
	    fy[ic] = source->fy[i];
	    fz[ic] = source->fz[i];
		ic++;
	   }
	 }
  }

  if( (source->R != NULL) && (source->G != NULL) && (source->B != NULL) )
  {
	 R = new float[nxyz];
	 G = new float[nxyz];
	 B = new float[nxyz];

     ic = 0;
     for(i=0; i<source->nxyz; i++)
     {
       if((source->astatu[i]&atom_Statu_Selected) && 
	   (source->astatu[i]&atom_Statu_Visiable) )
       {
	     R[ic] = source->R[i];
	     G[ic] = source->G[i];
	     B[ic] = source->B[i];
	     ic++;
	   }
	}
  }

}


//To copy a source sample
void Atoms21::CopySubSample(Atoms21*source)
{

  Sample::CopySubSample(source);

  if(nxyz == 0) return;

  style = source->style;
  vzoom = source->vzoom;
  vFactor = source->vFactor;
  lvzoom = source->lvzoom;
  lvFactor = source->lvFactor;
  lvm = source->lvm;

  fzoom = source->fzoom;
  fFactor = source->fFactor;
  lfzoom = source->lfzoom;
  lfFactor = source->lfFactor;
  lfm = source->lfm;

  if(vx != NULL) delete vx;
  if(vy != NULL) delete vy;
  if(vz != NULL) delete vz;
  if(fx != NULL) delete fx;
  if(fy != NULL) delete fy;
  if(fz != NULL) delete fz;
  if(R != NULL) delete R;
  if(G != NULL) delete G;
  if(B != NULL) delete B;
  if(r != NULL) delete r;

  int i, ic, I;
  I = ityp[0];

  if( (source->vx != NULL) && (source->vy != NULL) && (source->vz != NULL) )
  {
	vx = new float[nxyz];
	vy = new float[nxyz];
	vz = new float[nxyz];

    ic = 0;
    for(i=0; i<source->nxyz; i++)
    {
      if(source->ityp[i] == I )
	  {
	   vx[ic] = source->vx[i];
	   vy[ic] = source->vy[i];
	   vz[ic] = source->vz[i];
	   ic++;
       }
	}
  }

  if( (source->fx != NULL) && (source->fy != NULL) && (source->fz != NULL) ) 
  {
	 fx = new float[nxyz];
	 fy = new float[nxyz];
	 fz = new float[nxyz];

     ic = 0;
     for(i=0; i<source->nxyz; i++)
     {
        if(source->ityp[i] == I )
	    {
	      fx[ic] = source->fx[i];
	      fy[ic] = source->fy[i];
	      fz[ic] = source->fz[i];
		  ic++;
		}
	  }
   }

  if( (source->R != NULL) && (source->G != NULL) && (source->B != NULL) )
  {
	 R = new float[nxyz];
	 G = new float[nxyz];
	 B = new float[nxyz];

     ic = 0;
     for(i=0; i<source->nxyz; i++)
     {
       if(source->ityp[i] == I )
       {
	     R[ic] = source->R[i];
	     G[ic] = source->G[i];
	     B[ic] = source->B[i];
	     ic++;
	   }
	  }
   }

}



//To paste a source to this
void Atoms21::Paste(Atoms21*source)
{

 float *ox, *oy, *oz;
 int i, nnxyz;


 ox = new float[nxyz];
 oy = new float[nxyz];
 oz = new float[nxyz];

 nnxyz = nxyz + source->nxyz;
 
 if( (vx != NULL) && (vy != NULL) && (vz != NULL) )
 {
   for(i=0; i<nxyz; i++)
   {
    ox[i] = vx[i];
    oy[i] = vy[i];
    oz[i] = vz[i];
   }
   delete vx;
   delete vy;
   delete vz;
   vx = new float[nnxyz];
   vy = new float[nnxyz];
   vz = new float[nnxyz];

   for(i=0; i<nxyz; i++)
   {
    vx[i] = ox[i];
    vy[i] = oy[i];
    vz[i] = oz[i];
   }
   //to paste
   if( (source->vx != NULL) && (source->vy != NULL) && (source->vz != NULL) )
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       vx[i] = source->vx[i];
       vy[i] = source->vy[i];
       vz[i] = source->vz[i];
      }
    }
    else
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       vx[i] = 0.f;
       vy[i] = 0.f;
       vz[i] = 0.f;
      }
    }
 }

 //To paste force
 if( (fx != NULL) && (fy != NULL) && (fz != NULL) )
 {
   for(i=0; i<nxyz; i++)
   {
    ox[i] = fx[i];
    oy[i] = fy[i];
    oz[i] = fz[i];
   }
   delete fx;
   delete fy;
   delete fz;
   fx = new float[nnxyz];
   fy = new float[nnxyz];
   fz = new float[nnxyz];

   for(i=0; i<nxyz; i++)
   {
    fx[i] = ox[i];
    fy[i] = oy[i];
    fz[i] = oz[i];
   }
   //to paste
   if( (source->fx != NULL) && (source->fy != NULL) && (source->fz != NULL) )
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       fx[i] = source->fx[i];
       fy[i] = source->fy[i];
       fz[i] = source->fz[i];
      }
    }
    else
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       fx[i] = 0.f;
       fy[i] = 0.f;
       fz[i] = 0.f;
      }
    }
 }

 //To paste color
 if( (R != NULL) && (G != NULL) && (B != NULL) )
 {
   for(i=0; i<nxyz; i++)
   {
    ox[i] = R[i];
    oy[i] = G[i];
    oz[i] = B[i];
   }
   delete R;
   delete G;
   delete B;
   R = new float[nnxyz];
   G = new float[nnxyz];
   B = new float[nnxyz];

   for(i=0; i<nxyz; i++)
   {
    R[i] = ox[i];
    G[i] = oy[i];
    B[i] = oz[i];
   }
   //to paste
   if( (source->R != NULL) && (source->G != NULL) && (source->B != NULL) )
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       R[i] = source->R[i];
       G[i] = source->G[i];
       B[i] = source->B[i];
      }
    }
    else
   {
      for(i=nxyz; i<nnxyz; i++)
      {
       R[i] = 0.f;
       G[i] = 0.f;
       B[i] = 0.f;
      }
    }
 }
 
 Sample::Paste(source);

}

//Purpose: to save information about the sample
void Atoms21::Save_Summary(FILE*pFile) 
{
	Sample::Save_Summary(pFile);
}

//Purpose: to save the configure of a picked subsample
void Atoms21::Save_Config_PickedSubsample(FILE*pFile) 
{
	if(curActive)
	{
  	  int i, I;
	  if(curID <= 0) return;
	  I = ityp[curID-1];
	  if(vx!=NULL && vy!=NULL && vz!=NULL) 
	  {
	  for(i=0; i<nxyz; i++)
	  	 if(ityp[i] == I)
		   fprintf(pFile, "%i, %16e,%16e,%16e,%16e,%16e,%16e\n",ityp[i],x[i],y[i],z[i],vx[i],vy[i],vz[i]);
	  }
	  else
	  {
	  for(i=0; i<nxyz; i++)
	  	 if(ityp[i] == I)
		   fprintf(pFile, "%i, %16e, %16e, %16e\n",ityp[i], x[i], y[i], z[i]);
	  }

	}
	else
	{
		if(next == NULL) return;
        ((Atoms21*)next)->Save_Config_PickedSubsample(pFile);
	}

}

//Purpose: to save the configure of selected atoms
void Atoms21::Save_Config_Selected(FILE*pFile) 
{
	if(curActive)
	{
  	  int i,j, J;
      J = group->Numb_of_type();
	  for(j=1; j<=J; j++)
	  {
	     if(vx!=NULL && vy!=NULL && vz!=NULL) 
		 {
		   for(i=0; i<nxyz; i++)
	  	   if(astatu[i]&atom_Statu_Selected)
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e, %16e, %16e, %16e, %16e, %16e\n",
			         j,x[i],y[i],z[i],vx[i],vy[i],vz[i]);
		   }
		 }
		 else
		 {
		   for(i=0; i<nxyz; i++)
	  	   if(astatu[i]&atom_Statu_Selected)
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e, %16e, %16e\n",j, x[i], y[i], z[i]);
		   }
		 }

	   }
	}
	else
	{
		if(next == NULL) return;
        ((Atoms21*)next)->Save_Config_Selected(pFile);
	}

}

//Purpose: to save the configure of a picked subsample
void Atoms21::Save_Config_VisiableAtoms(FILE*pFile) 
{
	if(curActive)
	{
  	  int i,j, J;
      J = group->Numb_of_type();
	  for(j=1; j<=J; j++)
	  {
	     if(vx!=NULL && vy!=NULL && vz!=NULL) 
		 {
		  for(i=0; i<nxyz; i++)
	  	   if(astatu[i]&atom_Statu_Visiable)
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e,%16e,%16e,%16e,%16e,%16e\n",
			          j,x[i],y[i],z[i],vx[i],vy[i],vz[i]);
		   }
		 }
		 else
		 {
		  for(i=0; i<nxyz; i++)
	  	   if(astatu[i]&atom_Statu_Visiable)
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e, %16e, %16e\n",j, x[i], y[i], z[i]);
		   }
		 }
	  }

	}
	else
	{
		if(next == NULL) return;
        ((Atoms21*)next)->Save_Config_VisiableAtoms(pFile);
	}

}

//Purpose: to save the configure
void Atoms21::Save_Config(FILE*pFile) 
{
	if(curActive)
	{
  	  int i,j, J;
      J = group->Numb_of_type();
	  for(j=1; j<=J; j++)
	  {
	     if(vx!=NULL && vy!=NULL && vz!=NULL) 
		 {
		  for(i=0; i<nxyz; i++)
	  	   if(!(astatu[i]&atom_Statu_Deleted))
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e,%16e,%16e,%16e,%16e,%16e\n",
			          j,x[i],y[i],z[i],vx[i],vy[i],vz[i]);
		   }
		 }
		 else
		 {
		  for(i=0; i<nxyz; i++)
	  	   if(!(astatu[i]&atom_Statu_Deleted))
		   { 
		     if(ityp[i] == j)
		     fprintf(pFile, "%i, %16e, %16e, %16e\n",j, x[i], y[i], z[i]);
		   }
		 }
	  }

	}
	else
	{
		if(next == NULL) return;
        ((Atoms21*)next)->Save_Config(pFile);
	}
}


void Atoms21::New(int lattice, int type, int nx,int ny,int nz,float a[], float c[])
{
	Sample::New(lattice, type, nx,ny,nz,a,c);
	vx = NULL;
	vy = NULL;
	vz = NULL;
	fx = NULL;
	fy = NULL;
	 r = NULL;
	 R = NULL;
	 G = NULL;
	 B = NULL;
}

void Atoms21::NewByImport(char fname[], int flag[]  )
{
	Sample::NewByImport(fname, flag); 
	vx = NULL;
	vy = NULL;
	vz = NULL;
	fx = NULL;
	fy = NULL;
	 r = NULL;
	 R = NULL;
	 G = NULL;
	 B = NULL;

}

/* To create a new sample by paste from a copy buffer*/
void Atoms21::NewByPaste(Sample*p)
{
	Sample::NewByPaste(p); 
	vx = NULL;
	vy = NULL;
	vz = NULL;
	fx = NULL;
	fy = NULL;
	 r = NULL;
	 R = NULL;
	 G = NULL;
	 B = NULL;
}







