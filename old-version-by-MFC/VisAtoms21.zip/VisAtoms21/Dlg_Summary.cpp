// Dlg_Summary.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_Summary.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_Summary dialog


CDlg_Summary::CDlg_Summary(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_Summary::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_Summary)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	theSample = NULL;
}


void CDlg_Summary::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_Summary)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_Summary, CDialog)
	//{{AFX_MSG_MAP(CDlg_Summary)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_Summary message handlers

BOOL CDlg_Summary::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(theSample == NULL)
	{
	  MessageBox( "No information of sample availabe", "Warning", MB_ICONEXCLAMATION|MB_OK);
	  OnOK();
	  return TRUE;
	}

	//initialize the list box
	char str[256], symb[40];;
	float x, y, z,a;
	int i, I, J, n;

	x = theSample->GetBoxSizeX();
	y = theSample->GetBoxSizeY();
	z = theSample->GetBoxSizeZ();
	sprintf(str, "Box size = (%6.2f*%6.2f*%6.2f)",x, y, z);
	((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	x = theSample->GetLatticeUnitX();
	y = theSample->GetLatticeUnitY();
	z = theSample->GetLatticeUnitZ();
	sprintf(str, "Lenght of lattice = %6.2f, %6.2f, %6.2f",x, y, z);
	((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	n = theSample->NumberofAtom(); 
	sprintf(str, "Totoal number of atoms =  %i",  n);
	((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	I = theSample->GetNumb_of_subSample()-1;
	sprintf(str, "Number of subsample  =  %i",  I);
	((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
	sprintf(str, "");
	((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	for(i=1; i<=I; i++)
	{
       J = theSample->GetTypeSubSampleAssignTo(i);
	   sprintf(str, "*******Fot %ith subsample(type %i):",i, J);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	   theSample->GetAtomSubSampleAssignTo(J, symb, &x, &y);
	   sprintf(str, "%s, atomic number = %5.2f, atomic mass = %5.2f",symb,x, y);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

 	   n = theSample->GetNumbofAtom_subSample(J);
	   sprintf(str, "Number of atoms for the subsample = %i",n);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	   theSample->GetSubSampleCenterofMass_in(J, &x, &y, &z);
	   sprintf(str, "Center of mass = (%6.3e, %6.3e, %6.3e)",x, y, z);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	   theSample->GetSubSampleBoxRangeX_in(J, &x, &y);
	   sprintf(str, "xmin = %5.2f, xmax = %5.2f", x, y);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	   theSample->GetSubSampleBoxRangeY_in(J, &x, &y);
	   sprintf(str, "ymin = %5.2f, ymax = %5.2f", x, y);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);

	   theSample->GetSubSampleBoxRangeZ_in(J, &x, &y);
	   sprintf(str, "zmin = %5.2f, zmax = %5.2f", x, y);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);


       theSample->GetColor_subSample(J, &x, &y, &z, &a);
	   sprintf(str, "Color and opacity = (%4.2f, %4.2f, %4.2f, %4.2f)",x, y, z, a);
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
    
	   //group->GetRadiu(J, &R);
	   //fprintf(pFile, "    Size                              = %f\n",R);
	   theSample->GetStyle_subSample(J, &n);
	   switch (n)
	   {
	   case 1:
	             sprintf(str, "Drawing style = DOT");
			     break;
	   case 2:
	             sprintf(str, "Drawing style = CIRCLE");
			     break;
	   case 3:
	             sprintf(str, "Drawing style = WIRE SPHERE");
			     break;
	   case 4:
	             sprintf(str, "Drawing style = SOLID SPHERE");
			     break;
	   }
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
	   sprintf(str, "");
	   ((CListBox*)GetDlgItem(IDC_LIST1))->AddString(str);
	  }



	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_Summary::OnOK() 
{
	theSample = NULL;
	CDialog::OnOK();
}
