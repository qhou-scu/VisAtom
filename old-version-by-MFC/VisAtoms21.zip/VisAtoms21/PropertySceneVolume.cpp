// PropertySceneVolume.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertySceneVolume.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertySceneVolume property page

IMPLEMENT_DYNCREATE(CPropertySceneVolume, CPropertyPage)

CPropertySceneVolume::CPropertySceneVolume() : CPropertyPage(CPropertySceneVolume::IDD)
{
	//{{AFX_DATA_INIT(CPropertySceneVolume)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
    changed = 0;
	style = scene_Style_Ortho;
    updatechoice = 0;
	left  = 0.f;
	right = 0.f;
	top   = 0.f;
	bottom= 0.f;
	nearz  = 0.f;
	farz   = 0.f; 
}

CPropertySceneVolume::~CPropertySceneVolume()
{
}

void CPropertySceneVolume::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertySceneVolume)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertySceneVolume, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertySceneVolume)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertySceneVolume message handlers
extern "C" void __stdcall GETVALUE(char*,float*,int*ERR);

void CPropertySceneVolume::OnOK() 
{

  if( ((CButton*) GetDlgItem(IDC_RADIO1))->GetCheck() )
  {
     if(style == scene_Style_Perspective) changed = 1;
	  style = scene_Style_Ortho; 

  }
   else
  {
     if(style == scene_Style_Ortho) changed = 1;
	   style = scene_Style_Perspective;
  }

  if( ((CButton*)GetDlgItem(IDC_RADIO3))->GetCheck()) 
	    updatechoice = scene_Update_Automatic;
  else  updatechoice = scene_Update_ByRequire;


  if( ((CButton*) GetDlgItem(IDC_CHECK1))->GetCheck() )
	 style = style|scene_Style_ShowVolume; 

  char str[64];
  float temp;
  int err;
  GetDlgItemText(IDC_EDIT1, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != left) 
  {  changed = 1;
     left = temp;
  }

  GetDlgItemText(IDC_EDIT2, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != top) 
  { changed = 1;
    top = temp;
  }

  GetDlgItemText(IDC_EDIT3, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != nearz) 
  { changed = 1;
    nearz = temp;
  }

  GetDlgItemText(IDC_EDIT4, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != right) 
  { changed = 1;
    right = temp;
  }

  GetDlgItemText(IDC_EDIT5, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != bottom) 
  { changed = 1;
    bottom = temp;
  }

  GetDlgItemText(IDC_EDIT6, str,64);
  GETVALUE(str, &temp, &err);
  if(temp != farz) 
  { changed = 1;
    farz = temp;
  }

  CPropertyPage::OnOK();
}

BOOL CPropertySceneVolume::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
    if(style&scene_Style_Perspective) 
	  CheckRadioButton( IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
	else
	  CheckRadioButton( IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);

	if(updatechoice) CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO4);
	else CheckRadioButton(IDC_RADIO3, IDC_RADIO4, IDC_RADIO3);


    if(style&scene_Style_ShowVolume) 
	  ((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(1);
	else
	  ((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(0);

	char str[40];
	sprintf(str,"%-5.2f",left);
	SetDlgItemText(IDC_EDIT1, str);
	sprintf(str,"%-5.2f",right);
	SetDlgItemText(IDC_EDIT4, str);
	sprintf(str,"%-5.2f",top);
	SetDlgItemText(IDC_EDIT2, str);
	sprintf(str,"%-5.2f",bottom);
	SetDlgItemText(IDC_EDIT5, str);
	sprintf(str,"%-5.2f",nearz);
	SetDlgItemText(IDC_EDIT3, str);
	sprintf(str,"%-5.2f",farz);
	SetDlgItemText(IDC_EDIT6, str);

	changed = 0;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}



