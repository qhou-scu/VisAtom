// Dlg_PCorre.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_PCorre.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_PCorre dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SET_ANALYSISDATA(int*,int*,float*,float*,float*);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
             void __stdcall GETPCX(int*);
             void __stdcall SETPCX(int*);
             void __stdcall GETPCY(int*);
             void __stdcall SETPCY(int*);
             void __stdcall GETPCZ(int*);
             void __stdcall SETPCZ(int*);
             void __stdcall GETBOXX(float*);
             void __stdcall SETBOXX(float*);
             void __stdcall GETBOXY(float*);
             void __stdcall SETBOXY(float*);
             void __stdcall GETBOXZ(float*);
             void __stdcall SETBOXZ(float*);
             void __stdcall SETMAXR_PAIRCORRE(float*);
             void __stdcall GETMAXR_PAIRCORRE(float*);
             void __stdcall SETBINS_PAIRCORRE(int*);
             void __stdcall GETBINS_PAIRCORRE(int*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);
             void __stdcall SETTYPE_PAIRCORRE(int*, int*);
             void __stdcall GETTYPE_PAIRCORRE(int*, int*);

             void __stdcall CAL_PAIRCORREALL();
			 void __stdcall CAL_PAIRCORRE11();
             void __stdcall GETVALUE_PAIRCORRE(int*,float*, float*);
             void __stdcall END_PAIRCORRE();
             void __stdcall RELEASE_ANALYSISDATA();
           }

UINT Cal_PairCorreAllProc( LPVOID pParam )
{
   	CAL_PAIRCORREALL();
	return 0;	// thread completed successfully
} 

UINT Cal_PairCorre11Proc( LPVOID pParam )
{
   	CAL_PAIRCORRE11();
	return 0;	// thread completed successfully
} 

CDlg_PCorre::CDlg_PCorre(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_PCorre::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_PCorre)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CDlg_PCorre::~CDlg_PCorre()
{
}

void CDlg_PCorre::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_PCorre)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_PCorre, CDialog)
	//{{AFX_MSG_MAP(CDlg_PCorre)
	ON_BN_CLICKED(IDC_CHECKX, OnCheckx)
	ON_BN_CLICKED(IDC_CHECKY, OnChecky)
	ON_BN_CLICKED(IDC_CHECKZ, OnCheckz)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_CBN_SELCHANGE(IDC_ATOM1, OnSelchangeAtom1)
	ON_CBN_SELCHANGE(IDC_ATOM2, OnSelchangeAtom2)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_PCorre message handlers

BOOL CDlg_PCorre::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT rect,rect1;
	int W, H, L, L1;
	this->GetWindowRect(&rect);
	GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;

	Fig.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rect,this,0,NULL);

	float temp;
	int    itemp;
	char str[32];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);

	GETBOXX(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITX, str);
	GETBOXY(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITY, str);
	GETBOXZ(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITZ, str);
    
    GETPCX(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKX,1);
	else
		CheckDlgButton(IDC_CHECKX,0);

    GETPCY(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKY,1);
	else
		CheckDlgButton(IDC_CHECKY,0);

    GETPCZ(&itemp);
    if(itemp)
		CheckDlgButton(IDC_CHECKZ,1);
	else
		CheckDlgButton(IDC_CHECKZ,0);
    OnCheckx();
    OnChecky();
    OnCheckz();

    GETMAXR_PAIRCORRE(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDIT1, str);

    GETBINS_PAIRCORRE(&itemp);
	sprintf(str,"%i",itemp);
	SetDlgItemText(IDC_EDIT2, str);

    OnRadio1(); 

	int i,n;
	GETGROUPNUMB(&n);
	for(i=1;i<=n; i++)
	{
	  sprintf(str,"%i",i);
	  ((CComboBox*)GetDlgItem(IDC_ATOM1))->AddString(str);
	  ((CComboBox*)GetDlgItem(IDC_ATOM2))->AddString(str);
	}
	int i1, i2;
    GETTYPE_PAIRCORRE(&i1, &i2);
	sprintf(str,"%i",i1);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM1))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM1))->SetCurSel(i);
	sprintf(str,"%i",i2);
	i = ((CComboBox*)GetDlgItem(IDC_ATOM2))->FindString(-1, str); 
    ((CComboBox*)GetDlgItem(IDC_ATOM2))->SetCurSel(i);

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);

    Kernal = NULL;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_PCorre::OnCheckx() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKX ) )
  {
	  GetDlgItem(IDC_STATICX)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITX)->EnableWindow(TRUE);
      i = 1;
  }
  else
  {
	  GetDlgItem(IDC_STATICX)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
      i = 0; 
 }
 SETPCX(&i);
}

void CDlg_PCorre::OnChecky() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKY ) )
  {
	  GetDlgItem(IDC_STATICY)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITY)->EnableWindow(TRUE);
      i = 1;;
  }
  else
  {
	  GetDlgItem(IDC_STATICY)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
      i = 0;
  }
  SETPCY(&i);
}

void CDlg_PCorre::OnCheckz() 
{
  int i;
  if(IsDlgButtonChecked(IDC_CHECKZ) )
  {
	  GetDlgItem(IDC_STATICZ)->EnableWindow(TRUE);
	  GetDlgItem(IDC_EDITZ)->EnableWindow(TRUE);
      i =1;
  }
  else
  {
	  GetDlgItem(IDC_STATICZ)->EnableWindow(FALSE);
	  GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
      i = 0; 
  }
 SETPCZ(&i);
}

void CDlg_PCorre::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_FIGFRAME) != NULL)
	{
	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 Fig.MoveWindow(&rect, TRUE);
	}
	
}


void CDlg_PCorre::OnRadio1() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
  GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
  GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
}

void CDlg_PCorre::OnRadio2() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
  GetDlgItem(IDC_ATOM1)->EnableWindow(TRUE);
  GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);
}

void CDlg_PCorre::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  SET_ANALYSISDATA(&nxyz,ityp,x,y,z);
}


void CDlg_PCorre::OnButtonStart() 
{
	//*** to get lattice unit
    char str[32];
    float t;
    int err;

    GetDlgItemText(IDC_EDITLU, str,32);
    GETVALUE(str, &t, &err);
    if(t<= 0.f) 
    {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
    }
    SETLATTICEPARA(&t);	
	// to get box size
    GetDlgItemText(IDC_EDITX, str,32);
    GETVALUE(str, &t, &err);
    SETBOXX(&t);	
    GetDlgItemText(IDC_EDITY, str,32);
    GETVALUE(str, &t, &err);
    SETBOXY(&t);	
    GetDlgItemText(IDC_EDITZ, str,32);
    GETVALUE(str, &t, &err);
    SETBOXZ(&t);
	//to get maxma range
    GetDlgItemText(IDC_EDIT1, str,32);
    GETVALUE(str, &t, &err);
    if(t <= 0)
    {
	  MessageBox("The max value of range should be greater than zero", "",MB_OK);
      GETMAXR_PAIRCORRE(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDIT1, str);
	  return;
    }
    SETMAXR_PAIRCORRE(&t);	
	
	//** to begin calculation
	SetCursor(LoadCursor(NULL,IDC_WAIT));

    if(IsDlgButtonChecked(IDC_RADIO1)  )
	{
       //CAL_PAIRCORREALL();
      Kernal = AfxBeginThread(Cal_PairCorreAllProc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	}
	else
	{
      //CAL_PAIRCORRE11();
      Kernal = AfxBeginThread(Cal_PairCorre11Proc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	}
	if(Kernal != NULL) //disable all contrals
	{
	   GetDlgItem(IDC_EDITLU)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKX)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKY)->EnableWindow(FALSE);
	   GetDlgItem(IDC_CHECKZ)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_BUTTON_START)->EnableWindow(FALSE);
       SetTimer(nIDEvent, 100, NULL);
    }

	return;
}


void CDlg_PCorre::OnChangeEdit2() 
{
  char str[32];
  int err;

  GetDlgItemText(IDC_EDIT2, str,32);
  err = atoi(str);
  if(err <= 0)
  {
	  MessageBox("The number of bins smaller than zero", "",MB_OK);
      GETBINS_PAIRCORRE(&err);	
	  sprintf(str,"%i",err);
      SetDlgItemText(IDC_EDIT2, str);
	  return;
  }
  SETBINS_PAIRCORRE(&err);	

}


void CDlg_PCorre::OnDestroy() 
{
    END_PAIRCORRE();
    RELEASE_ANALYSISDATA();
	CDialog::OnDestroy();
}

void CDlg_PCorre::OnExit() 
{
	CDialog::OnOK();
}

void CDlg_PCorre::OnOK() 
{
	OnButtonStart();
	return;
}

void CDlg_PCorre::OnSelchangeAtom1() 
{
	int i1 = ((CComboBox*)GetDlgItem(IDC_ATOM1))->GetCurSel()+1;
	int i2 = ((CComboBox*)GetDlgItem(IDC_ATOM2))->GetCurSel()+1;
    SETTYPE_PAIRCORRE(&i1, &i2);
}

void CDlg_PCorre::OnSelchangeAtom2() 
{
     OnSelchangeAtom1();	
}

void CDlg_PCorre::OnTimer(UINT nIDEvent) 
{
    DWORD  lpExitCode;
	if(Kernal == NULL) 
	{
	   GetDlgItem(IDC_PROMPT)->SetWindowText("");
	   return;
	}
	static int i=0;
	GetExitCodeThread(Kernal->m_hThread, &lpExitCode);
	{
	   if(lpExitCode != STILL_ACTIVE)
	   {
	     float*R, *G;
	     int bins;

	     GETBINS_PAIRCORRE(&bins);
	     if(bins == 0) return;
         R = new float[bins];
         G = new float[bins];

         GETVALUE_PAIRCORRE(&bins,R,G);
	     Fig.NewCurve(0, bins, R, G);
	     Fig.AutoYRange();
	     float rmax, alta,temp;
	     GETMAXR_PAIRCORRE(&rmax);
	     GETLATTICEPARA(&alta);
	     temp = ((int)(rmax/alta)+1);
	     Fig.ChangeXRange(0.f, temp*alta);
         if(temp > 5) temp = 5;
         Fig.ChangeXAxsis_nTick((int)temp);
 	     Fig.CreateXAxsisLabel("%5.2f");
         Fig.ChangeXLabelScal(0.07f, 0.08f);
	     Fig.CreateXTitle("r (in lattice unit)");
         Fig.CreateYTitle("G(r) (in arb.unit)");
	     delete R;
	     delete G;
		 Invalidate(FALSE);
		 Kernal = NULL;

		 //recover the status
	     GetDlgItem(IDC_EDITLU)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKX)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKY)->EnableWindow(TRUE);
	     GetDlgItem(IDC_CHECKZ)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_CHECKX ) )
         {
	        GetDlgItem(IDC_STATICX)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITX)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICX)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITX)->EnableWindow(FALSE);
         }

         if(IsDlgButtonChecked(IDC_CHECKY ) )
         {
	        GetDlgItem(IDC_STATICY)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITY)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICY)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITY)->EnableWindow(FALSE);
         }

         if(IsDlgButtonChecked(IDC_CHECKZ ) )
         {
	        GetDlgItem(IDC_STATICZ)->EnableWindow(TRUE);
	        GetDlgItem(IDC_EDITZ)->EnableWindow(TRUE);
         }
         else
         {
	        GetDlgItem(IDC_STATICZ)->EnableWindow(FALSE);
	        GetDlgItem(IDC_EDITZ)->EnableWindow(FALSE);
         }
	     GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_EDIT2)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO2)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_RADIO1) )
		 {
	       GetDlgItem(IDC_ATOM1)->EnableWindow(FALSE);
	       GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
		 }
		 else
		 {
	       GetDlgItem(IDC_ATOM1)->EnableWindow(TRUE);
	       GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);
		 }
	     GetDlgItem(IDC_BUTTON_START)->EnableWindow(TRUE);
         KillTimer(nIDEvent);
		 GetDlgItem(IDC_PROMPT)->SetWindowText("");
	     CDialog::OnTimer(nIDEvent);
		 return;
	   }
	}
	if(i < 10) 
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("Please Waiting...");
		i++;
	}
	else
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("");
		i++;
		if(i >= 15) i= 0;
	}

	CDialog::OnTimer(nIDEvent);
}
