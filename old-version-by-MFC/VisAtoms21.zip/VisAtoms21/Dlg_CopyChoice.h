// Dlg_CopyChoice.h : header file
//
#define operate_copyselectedatom    0
#define operate_copysubsample       1
#define operate_copysample          2
/////////////////////////////////////////////////////////////////////////////
// CDlg_CopyChoice dialog

class CDlg_CopyChoice : public CDialog
{
// Construction
public:
	CDlg_CopyChoice(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_CopyChoice)
	enum { IDD = IDD_DIALOG8 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:
     int choice;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_CopyChoice)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_CopyChoice)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
