// PropertyBackground.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "PropertyBackground.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyBackground property page

IMPLEMENT_DYNCREATE(CPropertyBackground, CPropertyPage)

CPropertyBackground::CPropertyBackground() : CPropertyPage(CPropertyBackground::IDD)
{
	//{{AFX_DATA_INIT(CPropertyBackground)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
    R = 0.0f;
    G = 0.0f;
    B = 0.0f;
	A = 1.f;

}

CPropertyBackground::~CPropertyBackground()
{
}

void CPropertyBackground::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyBackground)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyBackground, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyBackground)
	ON_NOTIFY(NM_CLICK, IDC_SLIDER1, OnClickSlider1)
	ON_NOTIFY(NM_SETFOCUS, IDC_SLIDER1, OnSetfocusSlider1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyBackground message handlers

BOOL CPropertyBackground::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(R*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	p->SetRangeMax(200, TRUE);
 	p->SetPos((int)(G*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(B*200));
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	p->SetRangeMax(200, TRUE);
	p->SetPos((int)(A*200));

	BackColor.Set(R, G, B, A);
	RECT rect;
	GetClientRect(&rect);
	rect.right = rect.right-30;
	rect.top   = rect.top  +32;
	rect.left  = rect.right-64;
	rect.bottom  = rect.top+64;
	BackColor.Create(NULL,NULL, WS_VISIBLE|WS_CHILD| WS_CLIPCHILDREN | WS_CLIPSIBLINGS, rect, this, 0, NULL);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropertyBackground::OnOK() 
{
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	R = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	G = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	B = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	A = (float)p->GetPos( )/(float)p->GetRangeMax();

	BackColor.DestroyWindow();
	
	CPropertyPage::OnOK();
}

void CPropertyBackground::OnClickSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	float r, g, b, a;
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	r = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	g = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	b = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	a = (float)p->GetPos( )/(float)p->GetRangeMax();

	BackColor.ReSet(R, G, B, A);
	*pResult = 0;
}

void CPropertyBackground::OnSetfocusSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	float r, g, b, a;
	CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	r = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	g = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	b = (float)p->GetPos( )/(float)p->GetRangeMax();
    p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	a = (float)p->GetPos( )/(float)p->GetRangeMax();

	BackColor.ReSet(R, G, B, A);
	
	*pResult = 0;
}



BOOL CPropertyBackground::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	     float r, g, b, a;
	     r = R;
	     g = G;
	     b = B;
	     a = A;
	     CSliderCtrl*p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	     if(p != NULL) r = (float)p->GetPos( )/(float)p->GetRangeMax();
         p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER2);
	     if(p != NULL) g = (float)p->GetPos( )/(float)p->GetRangeMax();
         p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER3);
	     if(p != NULL) b = (float)p->GetPos( )/(float)p->GetRangeMax();
         p = (CSliderCtrl*)GetDlgItem(IDC_SLIDER4);
	     if(p != NULL) a = (float)p->GetPos( )/(float)p->GetRangeMax();

	     if(BackColor.GetSafeHwnd()) BackColor.ReSet(r, g, b, a);
	
	return CPropertyPage::OnNotify(wParam, lParam, pResult);
}

void CPropertyBackground::OnCancel() 
{
	BackColor.DestroyWindow();

	CPropertyPage::OnCancel();
}
