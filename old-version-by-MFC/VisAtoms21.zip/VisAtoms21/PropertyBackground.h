// PropertyBackground.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyBackground dialog
#include "WndGL_BackColor.h"

class CPropertyBackground : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyBackground)

// Construction
public:
	CPropertyBackground();
	~CPropertyBackground();

// Dialog Data
	//{{AFX_DATA(CPropertyBackground)
	enum { IDD = IDD_PROPPAGE_DISPLAYBACKGROUND };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

public:
	float R, G, B, A;
	CWndGL_BackColor BackColor;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyBackground)
	public:
	virtual void OnOK();
	virtual void OnCancel();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyBackground)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetfocusSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
