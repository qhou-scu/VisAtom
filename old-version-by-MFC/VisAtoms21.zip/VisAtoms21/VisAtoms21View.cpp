// VisAtoms21View.cpp : implementation of the CVisAtoms21View class
//

#include "stdafx.h"

#include "VisAtoms21.h"
#include "VisAtoms21Doc.h"
#include "VisAtoms21View.h"

#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View

IMPLEMENT_DYNCREATE(CVisAtoms21View, CView)

BEGIN_MESSAGE_MAP(CVisAtoms21View, CView)
	//{{AFX_MSG_MAP(CVisAtoms21View)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_BUTTON32772, OnButton32772)
	ON_COMMAND(ID_BUTTON32773, OnButton32773)
	ON_COMMAND(ID_BUTTON32774, OnButton32774)
	ON_COMMAND(ID_BUTTON32775, OnButton32775)
	ON_COMMAND(ID_BUTTON32779, OnButton32779)
	ON_COMMAND(ID_BUTTON32780, OnButton32780)
	ON_COMMAND(ID_BUTTON32782, OnButton32782)
	ON_COMMAND(ID_BUTTON32783, OnButton32783)
	ON_COMMAND(ID_BUTTON32784, OnButton32784)
	ON_COMMAND(ID_BUTTON32785, OnButton32785)
	ON_COMMAND(ID_BUTTON32787, OnButton32787)
	ON_COMMAND(ID_BUTTON32788, OnButton32788)
	ON_COMMAND(ID_BUTTON32789, OnButton32789)
	ON_COMMAND(ID_BUTTON32790, OnButton32790)
	ON_COMMAND(ID_BUTTON32791, OnButton32791)
	ON_COMMAND(ID_BUTTON32792, OnButton32792)
	ON_COMMAND(ID_BUTTON32794, OnButton32794)
	ON_COMMAND(ID_BUTTON32795, OnButton32795)
	ON_COMMAND(ID_BUTTON32806, OnButton32806)
	ON_COMMAND(ID_BUTTON32807, OnButton32807)
	ON_COMMAND(ID_BUTTON32808, OnButton32808)
	ON_COMMAND(ID_BUTTON32809, OnButton32809)
	ON_COMMAND(ID_BUTTON32810, OnButton32810)
	ON_COMMAND(ID_BUTTON32811, OnButton32811)
	ON_COMMAND(ID_BUTTON32836, OnButton32836)
	ON_COMMAND(ID_BUTTON32842, OnButton32842)
	ON_COMMAND(ID_BUTTON32845, OnButton32845)
	ON_COMMAND(ID_BUTTON32857, OnButton32857)
	ON_COMMAND(ID_BUTTON32858, OnButton32858)
	ON_COMMAND(ID_BUTTON32859, OnButton32859)
	ON_COMMAND(ID_BUTTON32860, OnButton32860)
	ON_COMMAND(ID_BUTTON32861, OnButton32861)
	ON_COMMAND(ID_BUTTON32871, OnButton32871)
	ON_COMMAND(ID_OPTION_BACKGROUND, OnOptionBackground)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_EDIT_PROPERTY, OnEditProperty)
	ON_COMMAND(ID_EDIT_SHOW, OnEditShow)
	ON_COMMAND(ID_EDIT_HIDE, OnEditHide)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_OPTION_SCENE, OnOptionScene)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_ACTION_CLIPPLANE_INVERTDIRECTIONOFCLIPPLANEINX, OnActionClipplaneInvertdirectionofclipplaneinx)
	ON_COMMAND(ID_ACTION_CLIPPLANE_INVERTDIRECTIONOFCLIPPLANEINY, OnActionClipplaneInvertdirectionofclipplaneiny)
	ON_COMMAND(ID_ACTION_CLIPPLANE_INVERTDIRECTIONOFCLIPPLANEINZ, OnActionClipplaneInvertdirectionofclipplaneinz)
	ON_COMMAND(ID_FILE_SAVEIMAGEAS, OnFileSaveimageas)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_TOOLS_SUMMARY, OnToolsSummary)
	ON_COMMAND(ID_OPTION_PICKATOM, OnOptionPickatom)
	ON_COMMAND(ID_TOOLS_GROUPATOMSBYCOLOR, OnToolsGroupatomsbycolor)
	ON_COMMAND(ID_BUTTON32777, OnButton32777)
	ON_COMMAND(ID_BUTTON32778, OnButton32778)
	ON_COMMAND(ID_OPTIONS_FILEFORMAT, OnOptionsFileformat)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_COMMAND(ID_TOOLS_MAKEMOVIE, OnToolsMakemovie)
	ON_COMMAND(ID_TOOLS_DENSITYOFSAMPLE, OnToolsDensityofsample)
	ON_COMMAND(ID_EDIT_NORMALIZATION, OnEditNormalization)
	ON_COMMAND(ID_EDIT_MAKESUBSAMPLE, OnEditMakesubsample)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View construction/destruction

CVisAtoms21View::CVisAtoms21View()
{
   iMovie = 0;
   iMovieOpen = 0;
}

CVisAtoms21View::~CVisAtoms21View()
{
}

BOOL CVisAtoms21View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View drawing

void CVisAtoms21View::OnDraw(CDC* pDC)
{
   CVisAtoms21Doc* pDoc = GetDocument();
   ASSERT_VALID(pDoc);

   static int firstdraw = 1;

   m_Sample     = pDoc->GetSample(); 
   m_SampleCopy = pDoc->GetSampleTemp();
   m_Sample->MakeActive();

	SetCursor(LoadCursor(NULL,IDC_WAIT));
	
	// Make the rendering context current
	wglMakeCurrent(m_hDC,m_hRC);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	// Call our external OpenGL code
	if(firstdraw && (m_Sample->NumberofAtom()<=0) )
	{
    /*  Text Welcome = Text(&Font,"VisAtoms");

	  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	  glMatrixMode(GL_MODELVIEW);
      glEnable(GL_DEPTH_TEST);
	  Welcome.ChangeColor(0.5f, 0.4f, 0.3f);
	  Welcome.ChangeSize(0.7f, 0.2f);
	  Welcome.ChangeNormal(0.1f, 0.1f, 1.f);
      Welcome.ChangeAline(TEXT_ALINE_CENTER, TEXT_ALINE_BOTTOM);
      Welcome.Paint();

	  Welcome.ChangeString(&Font, "Welcome to");
	  Welcome.ChangeCenter(-0.45f, 0.45f, 0.f);
	  Welcome.ChangeSize(0.3f, 0.05f);
	  Welcome.ChangeNormal(0.f, 0.f, 1.f);
      Welcome.ChangeAline(TEXT_ALINE_RIGHT, TEXT_ALINE_TOP);
      Welcome.Paint();

	  Welcome.ChangeColor(0.f, 0.f, .5f);
	  Welcome.ChangeString(&Font, "Universite Libre de Bruxelles");
	  Welcome.ChangeCenter(0.45f, -0.3f, 0.f);
	  Welcome.ChangeSize(0.35f, 0.05f);
      Welcome.ChangeAline(TEXT_ALINE_CENTER, TEXT_ALINE_BOTTOM);
      Welcome.Paint();
	  Welcome.ChangeString(&Font, "and");
	  Welcome.ChangeCenter(0.45f, -0.35f, 0.f);
	  Welcome.ChangeSize(0.1f, 0.04f);
      Welcome.ChangeAline(TEXT_ALINE_CENTER, TEXT_ALINE_CENTER);
      Welcome.Paint();
	  Welcome.ChangeString(&Font, "Sichuan University");
	  Welcome.ChangeCenter(0.45f, -0.4f, 0.f);
	  Welcome.ChangeSize(0.3f, 0.05f);
      Welcome.ChangeAline(TEXT_ALINE_CENTER, TEXT_ALINE_TOP);
      Welcome.Paint();
	 */
	}
	else
	{
     firstdraw = 0;
 	 m_Sample->Paint();
     SCENE.Paint();
	 }
	 // Swap our scene to the front
	 SwapBuffers(m_hDC);

	 // 
	 if(iMovie)
	 {
		AviSnapshot.CreateFramFromViewport();
        AviSnapshot.SaveCurrentFrame(); 
	 }

	// Allow other rendering contexts to co-exist
	wglMakeCurrent(m_hDC,NULL);
  
	Focus.left = 0;
	Focus.right = 0;
	Focus.top   = 0;
	Focus.bottom= 0;

	if(pDoc->fmt.iOpenContinue) 
	{
	   switch (pDoc->ifNext)	
	   {
	   case 1:
		    OnButton32789();
			break;
	   case -1:
		    OnButton32788();
			break;
	   }
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View printing

BOOL CVisAtoms21View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CVisAtoms21View::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{

	wglMakeCurrent(m_hDC,m_hRC);
	//To get the rotation matrix
    double mat[16];
    glGetDoublev(GL_MODELVIEW_MATRIX, mat);
	wglMakeCurrent(NULL,NULL);
	Scene pSCENE;

	short cxPage, cyPage;   // Dimensions of Printed Page
	BOOL bMetaFile = FALSE;	// MetaFile capabilities exist
	OSVERSIONINFO osVersion;// OS identifier
	HGLRC hRC;				// Rendering context for printer
	DOCINFO docInfo;        // Document Info

	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),  // Size of this structure
		1,                              // Version of this structure    
		PFD_DRAW_TO_WINDOW |                    // Draw to Window (not to bitmap)
		PFD_SUPPORT_OPENGL |                          // Support OpenGL calls in window
		PFD_SUPPORT_GDI,                                                // Allow GDI drawing in window too
		PFD_TYPE_RGBA,                          // RGBA Color mode
		16,                                     // Want 16bit color 
		0,0,0,0,0,0,                            // Not used to select mode
		0,0,                                    // Not used to select mode
		0,0,0,0,0,                              // Not used to select mode
		16,                                     // Size of depth buffer
		0,                                      // Not used to select mode
		0,                                      // Not used to select mode
		PFD_MAIN_PLANE,                         // Draw in main plane
		0,                                      // Not used to select mode
		0,0,0 };                                // Not used to select mode

	// Initialize DocInfo structure
	docInfo.cbSize = sizeof(DOCINFO);
	docInfo.lpszDocName = "VisAtoms Rendering";
	docInfo.lpszOutput = NULL;


	// Check for Metafile capabilities (NT 4.0 or greater, no Windows95)
	GetVersionEx(&osVersion);

	// If NT AND version 4.x or greater
	if(osVersion.dwPlatformId == VER_PLATFORM_WIN32_NT &&
		osVersion.dwMajorVersion >= 4)
		bMetaFile = TRUE;

	// If no metafile capabilies, create the rendering context now
	if(!bMetaFile)
		{
		// Now we have a printer device context, create a pixel format,
		// and rendering context

		// Choose a pixel format that best matches that described in pfd
		int nPixelFormat = ChoosePixelFormat(pDC->m_hDC, &pfd);

		if(nPixelFormat == 0)
			{
			MessageBox("Cannot choose a pixel format for this printer!",NULL,
					MB_OK | MB_ICONSTOP);
			return;
			}

		// Set the pixel format for the device context
		if(!SetPixelFormat(pDC->m_hDC, nPixelFormat, &pfd))
			{
			MessageBox("Error Setting pixel format for this printer!",NULL,
					MB_OK | MB_ICONSTOP);
			return;
			}


		// Create the Rendering context and execute the OpenGL Commands
		hRC = wglCreateContext(pDC->m_hDC);
		wglMakeCurrent(pDC->m_hDC, hRC);
		}
		
	// Start the document and page
	StartDoc(pDC->m_hDC, &docInfo);
	StartPage(pDC->m_hDC);

	// If we are Metafile enabled, then create rendering context here
	if(bMetaFile)
		{
		// Now we have a printer device context, create a pixel format,
		// and rendering context

		// Choose a pixel format that best matches that described in pfd
		int nPixelFormat = ChoosePixelFormat(pDC->m_hDC, &pfd);

		if(nPixelFormat == 0)
			{
			MessageBox("Cannot choose a pixel format for this printer!",NULL,
					MB_OK | MB_ICONSTOP);
			return;
			}

		// Set the pixel format for the device context
		if(!SetPixelFormat(pDC->m_hDC, nPixelFormat, &pfd))
			{
			MessageBox("Error Setting pixel format for this printer!",NULL,
					MB_OK | MB_ICONSTOP);
			return;
			}


		// Create the Rendering context and execute the OpenGL Commands
		hRC = wglCreateContext(pDC->m_hDC);
		wglMakeCurrent(pDC->m_hDC, hRC);
		}

	// Get the dimensions of the page
	cxPage = GetDeviceCaps(pDC->m_hDC, HORZRES);
	cyPage = GetDeviceCaps(pDC->m_hDC, VERTRES);

	if( cxPage <= cyPage)
	    glViewport(0, 0, cxPage, cyPage);
	else
	    glViewport(0, 0, cxPage, cyPage);

	pSCENE.CreateScene();
    pSCENE.TurnLighton(1);	
    pSCENE.TurnLighton(2);	
	glMultMatrixd(mat);

	SetCursor(LoadCursor(NULL,IDC_WAIT));

	m_Sample->Paint();

	EndPage(pDC->m_hDC); // Finish writing to the page
	EndDoc(pDC->m_hDC); // End the print job

	// Clean up the rendering context
	wglMakeCurrent(NULL,NULL);
	wglDeleteContext(hRC);
	// TODO: add extra initialization before printing
}

void CVisAtoms21View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View diagnostics

#ifdef _DEBUG
void CVisAtoms21View::AssertValid() const
{
	CView::AssertValid();
}

void CVisAtoms21View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVisAtoms21Doc* CVisAtoms21View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVisAtoms21Doc)));
	return (CVisAtoms21Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21View message handlers


int CVisAtoms21View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	int nPixelFormat;					// Pixel format index
	m_hDC = ::GetDC(m_hWnd);			// Get the Device context

	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),	// Size of this structure
		1,								// Version of this structure	
		PFD_DRAW_TO_WINDOW |			// Draw to Window (not to bitmap)
		PFD_SUPPORT_OPENGL |			// Support OpenGL calls in window
		PFD_DOUBLEBUFFER,				// Double buffered mode
		PFD_TYPE_RGBA,					// RGBA Color mode
		24,								// Want 24bit color 
		0,0,0,0,0,0,					// Not used to select mode
		0,0,							// Not used to select mode
		0,0,0,0,0,						// Not used to select mode
		64,								// Size of depth buffer
		0,								// Not used to select mode
		0,								// Not used to select mode
		PFD_MAIN_PLANE,					// Draw in main plane
		0,								// Not used to select mode
		0,0,0 };						// Not used to select mode

	// Choose a pixel format that best matches that described in pfd
	nPixelFormat = ChoosePixelFormat(m_hDC, &pfd);

	// Set the pixel format for the device context
	VERIFY(SetPixelFormat(m_hDC, nPixelFormat, &pfd));

	// Create the rendering context
	m_hRC = wglCreateContext(m_hDC);

	// Make the rendering context current, perform initialization, then
	// deselect it
	VERIFY(wglMakeCurrent(m_hDC,m_hRC));
    //Font.Create(m_hDC, "Arial", 128, 2.f);

	wglMakeCurrent(NULL,NULL);
	return 0;
}

void CVisAtoms21View::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	wglMakeCurrent(m_hDC,m_hRC);
	//To store the old rotation matrix
    double mat[16];
    glGetDoublev(GL_MODELVIEW_MATRIX, mat);
	mat[14] = 0.0;

	if(cy == 0) cy = 1;
	if(cx == 0) cx = 1;
	// Set viewport and clipping volume
	if( cx <= cy)
	    glViewport(0, 0, cx, cy);
	else
	    glViewport(0, 0, cx, cy);

	SCENE.CreateScene();
    SCENE.TurnLighton(1);	
    SCENE.TurnLighton(2);	
	glMultMatrixd(mat);
    glGetDoublev(GL_MODELVIEW_MATRIX, mat);	 

    int clipState =   SCENE.IsClipPlaneEnabled(1);
        SCENE.Response(action_Object_Clipx);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
		
        clipState =   SCENE.IsClipPlaneEnabled(2);
        SCENE.Response(action_Object_Clipy);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
		  
        clipState =   SCENE.IsClipPlaneEnabled(3);
        SCENE.Response(action_Object_Clipz);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
  	    
	wglMakeCurrent(NULL,NULL);
    Invalidate(FALSE);
	  
}

void CVisAtoms21View::OnDestroy() 
{
	CView::OnDestroy();
	
	// Clean up rendering context stuff
	wglDeleteContext(m_hRC);
	::ReleaseDC(m_hWnd,m_hDC);
	
}


//** to get the current trnasformation matrix
void CVisAtoms21View::GetTransMatrix(double mat[]) 
{
	wglMakeCurrent(m_hDC,m_hRC);
    glGetDoublev(GL_MODELVIEW_MATRIX, mat);
	wglMakeCurrent(NULL,NULL);
	
}


void CVisAtoms21View::OnButton32772() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationX);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnButton32773() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationX);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32774() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationY);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32775() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationY);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32779() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationZ);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32780() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_RotationZ);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32782() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_Zoom);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32783() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_Zoom);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32784() 
{
    m_Sample->Rzoomin();
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32785() 
{
     m_Sample->Rzoomout();
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}


void CVisAtoms21View::OnButton32790() 
{
    if( ((CVisAtoms21Doc*)GetDocument())->ReadLastFile())
	{
       Invalidate(FALSE);
	}
	else
	{
      MessageBox("Fail to open the last file", "Error", MB_OK|MB_ICONASTERISK);
	}

}

void CVisAtoms21View::OnButton32789() 
{
    if( ((CVisAtoms21Doc*)GetDocument())->ReadNextFile())
	{
       Invalidate(FALSE);
	}
	else
	{
      MessageBox("Fail to open next file", "Error", MB_OK|MB_ICONASTERISK);
	}
}

void CVisAtoms21View::OnButton32787() 
{
    if( ((CVisAtoms21Doc*)GetDocument())->ReadFirstFile())
	{
       Invalidate(FALSE);
	}
	else
	{
      MessageBox("Fail to open the first file", "Error", MB_OK|MB_ICONASTERISK);
	}

	
}

void CVisAtoms21View::OnButton32788() 
{
    if( ((CVisAtoms21Doc*)GetDocument())->ReadPreviousFile())
	{
       Invalidate(FALSE);
	}
	else
	{
      MessageBox("Fail to open previous file", "Error", MB_OK|MB_ICONASTERISK);
	}
}

void CVisAtoms21View::OnButton32791() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateX);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnButton32792() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateX);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnButton32794() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateY);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32795() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateY);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnOptionBackground() 
{
	static CPropertyBackG  Back("Background", NULL, 0);
	if( Back.DoModal() == IDCANCEL) return;
	wglMakeCurrent(m_hDC,m_hRC);
	   glClearColor(Back.Color.R, Back.Color.G, Back.Color.B, Back.Color.A);
	wglMakeCurrent(NULL,NULL);
    Invalidate(FALSE);
}

void CVisAtoms21View::OnLButtonDown(UINT nFlags, CPoint point) 
{
	switch (m_Sample->GetPickOption())
	{
	case atom_pick_Option_Single:
	case atom_pick_Option_Subsample:
		if(m_Sample->GetPickStatu() != atom_pick_Statu_nopicked) 
		      DrawFocusRect(m_hDC, &Focus);
		     break;
	case atom_pick_Option_Square:
		 DrawFocusRect(m_hDC, &Focus);
		 break;
	}

	wglMakeCurrent(m_hDC,m_hRC);
	  m_Sample->PickAtom(point.x, point.y, &SCENE, &curX, &curY, &curZ);
	wglMakeCurrent(NULL,NULL);


	switch (m_Sample->GetPickOption())
	{
	case atom_pick_Option_Single:
	case atom_pick_Option_Subsample:
	case atom_pick_Option_Multiple:
	case atom_pick_Option_Tripoints:
		{
	     if(m_Sample->GetPickStatu() != atom_pick_Statu_nopicked) 
		 {
	     Focus.left   = point.x-3;
	     Focus.right  = point.x+3;
	     Focus.top    = point.y-3;
	     Focus.bottom = point.y+3;
	     DrawFocusRect(m_hDC, &Focus);
		 }
		 break;
		}
	case atom_pick_Option_Square:
		{
	      Focus.left   = point.x;
	      Focus.top    = point.y;
	      Focus.right   = point.x;
	      Focus.bottom  = point.y;
		 break;
		}

	}

	CView::OnLButtonDown(nFlags, point);
}

void CVisAtoms21View::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(nFlags&MK_LBUTTON == MK_LBUTTON)
	{
	 wglMakeCurrent(m_hDC,m_hRC);
	  m_Sample->MovePickedAtom(point.x, point.y, &SCENE, &curX, &curY, &curZ);
	 wglMakeCurrent(NULL,NULL);
	 switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
	        Focus.right  = point.x;
	        Focus.bottom = point.y;
		    DrawFocusRect(m_hDC, &Focus);
		    break;
		   }
	 }

    }

	CView::OnMouseMove(nFlags, point);
}

void CVisAtoms21View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	wglMakeCurrent(m_hDC,m_hRC);
	if(m_Sample->DropPickedAtom(point.x, point.y, &SCENE, &curX, &curY, &curZ)) 
		Invalidate(FALSE); 
	wglMakeCurrent(NULL,NULL);


	CView::OnLButtonUp(nFlags, point);
}


void CVisAtoms21View::OnEditProperty() 
{
	CDlg_ChangeProperty P;

	if(m_Sample->GetNumb_of_subSample() <= 1)
	{
	MessageBox("Nothing to change.", "Warning", 	MB_ICONASTERISK|MB_OK);
	return;
	}
	 

	P.m_Sample = (Atoms21*)m_Sample->GetcurActiveSample();

	wglMakeCurrent(m_hDC,m_hRC);
	float color[4];
	  glGetFloatv(GL_COLOR_CLEAR_VALUE, color);
	  P.bR = color[0];
	  P.bG = color[1];
	  P.bB = color[2];
	wglMakeCurrent(NULL,NULL);

	if(P.DoModal() == IDCANCEL) return;

	if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		
}

void CVisAtoms21View::OnEditShow() 
{
	CDlg_AtomOrSubSample which;

   if(which.DoModal() == IDCANCEL) return;
	
   if(m_Sample->GetcurActiveSample() == NULL)
   {
      MessageBox( "You should create sample first.", "Warning", MB_ICONASTERISK|MB_OK); 
      return;
   }

   switch (which.choice)
   {
   case operate_pickedatom:
	   {
		m_Sample->Show_SelectedAtoms( );
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_unpickedatom:
	   {
		m_Sample->Show_unSelectedAtoms( );
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_allatom:
	   {
		m_Sample->Show_AllAtoms( );
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_subsample:
	   {
          CDlg_Show P;
	      P.theSample = m_Sample->GetcurActiveSample();
          if(P.DoModal() == IDCANCEL) return;
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		  break;
	   }
   }
}

void CVisAtoms21View::OnEditHide() 
{
	CDlg_AtomOrSubSample which;

   if(which.DoModal() == IDCANCEL) return;
	
   if(m_Sample->GetcurActiveSample() == NULL)
   {
      MessageBox( "You should create sample first.", "Warning", MB_ICONASTERISK|MB_OK); 
      return;
   }

   switch (which.choice)
   {
   case operate_pickedatom:
	   {
		m_Sample->Hide_SelectedAtoms( );
        if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_unpickedatom:
	   {
		m_Sample->Hide_unSelectedAtoms( );
	    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_allatom:
	   {
		m_Sample->Hide_AllAtoms( );
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_subsample:
	   {
          CDlg_Show P;
	      P.theSample = m_Sample->GetcurActiveSample();
          if(P.DoModal() == IDCANCEL) return;
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		  break;
	   }
   }
	
}

void CVisAtoms21View::OnEditDelete() 
{
	CDlg_AtomOrSubSample which;

   if(which.DoModal() == IDCANCEL) return;
	
   if(m_Sample->GetcurActiveSample() == NULL) return;

   switch (which.choice)
   {
   case operate_pickedatom:
	   {
		m_Sample->Delete_SelectedAtoms( );
        if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
   case operate_unpickedatom:
	   {
		m_Sample->Delete_unSelectedAtoms( );
	    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   }
	   /*   case operate_allatom:
	   {
		m_Sample->Hide_AllAtoms( );
	      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		break;
	   } */
   case operate_subsample:
	   {
	     m_Sample->Delete_SubSample();
	     if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		 break;
	   } 
   } 
	
}


void CVisAtoms21View::OnOptionScene() 
{
   CScenPropertySheet p("Option for scene", this, 0);
   
   p.V.style = SCENE.GetStyle();
   p.V.left  = SCENE.GetVolumeX0();
   p.V.right = SCENE.GetVolumeX1();
   p.V.bottom= SCENE.GetVolumeY0();
   p.V.top   = SCENE.GetVolumeY1();
   p.V.nearz = SCENE.GetVolumeZ0();
   p.V.farz  = SCENE.GetVolumeZ1();
   p.V.updatechoice  = SCENE.GetUpdateStyle();

   p.A.systemchoice  = SCENE.GetSystemStyle();
   p.A.rotationStepx = SCENE.CurrentRotationStepx();
   p.A.rotationStepy = SCENE.CurrentRotationStepy();
   p.A.rotationStepz = SCENE.CurrentRotationStepz();
   p.A.itransStepx   = SCENE.CurrentTransStepx();
   p.A.itransStepy   = SCENE.CurrentTransStepy();
   p.A.itransStepz   = SCENE.CurrentTransStepz();
   p.A.zoomPercent   = SCENE.CurrentZoomPercent();

   p.C.iclipStep[0] =   SCENE.CurrentClipStepx();
   p.C.iclipStep[1] =   SCENE.CurrentClipStepy();
   p.C.iclipStep[2] =   SCENE.CurrentClipStepz();
   p.C.iclipThick[0] =  SCENE.CurrentClipPairThickx();
   p.C.iclipThick[1] =  SCENE.CurrentClipPairThicky();
   p.C.iclipThick[2] =  SCENE.CurrentClipPairThickz();
   
   p.C.clipState[0] =   SCENE.IsClipPlaneEnabled(1);
   if( p.C.clipState[0] == 2) p.C.clipState[0] = 3;
   p.C.clipState[1] =   SCENE.IsClipPlaneEnabled(2);
   if( p.C.clipState[1] == 2) p.C.clipState[1] = 3;
   p.C.clipState[2] =   SCENE.IsClipPlaneEnabled(3);
   if( p.C.clipState[2] == 2) p.C.clipState[2] = 3;
   

   if(SCENE.IfClipPlaneVisiable(1)) p.C.clipState[0]|8;
   if(SCENE.IfClipPlaneVisiable(2)) p.C.clipState[1]|8;
   if(SCENE.IfClipPlaneVisiable(3)) p.C.clipState[2]|8;


   if(p.DoModal() == IDCANCEL) return;

   //To reset the style and volume of the scene
   if(p.V.style&scene_Style_Perspective)
	   SCENE.SetAsPerspective();
   else
	   SCENE.SetAsOrtho();

   if(p.V.style&scene_Style_ShowVolume)
	   SCENE.SetVolumeShown();
   else
	   SCENE.SetVolumeHiden();

   if(p.V.updatechoice == scene_Update_ByRequire) SCENE.SetAsUpdateByRequire();
   else SCENE.SetAsUpdateAuto();

   //To set the action parameters
   if(p.A.systemchoice & scene_System_Labrotary) 
       SCENE.SetAsLaboratorySystem();
   else
       SCENE.SetAsRelativeSystem();

   SCENE.ChangeRotationStepx(p.A.rotationStepx);
   SCENE.ChangeRotationStepy(p.A.rotationStepy);
   SCENE.ChangeRotationStepz(p.A.rotationStepz);
   SCENE.ChangeTransStepx(p.A.itransStepx);
   SCENE.ChangeTransStepy(p.A.itransStepy);
   SCENE.ChangeTransStepz(p.A.itransStepz);
   SCENE.ChangeZoomPercent(p.A.zoomPercent);
   //to reset the parameter for clipplane
   SCENE.ChangeClipStepx(p.C.iclipStep[0]);
   SCENE.ChangeClipStepy(p.C.iclipStep[1]);
   SCENE.ChangeClipStepz(p.C.iclipStep[2]);
   SCENE.ChangeClipPairThickx(p.C.iclipThick[0]);
   SCENE.ChangeClipPairThicky(p.C.iclipThick[1]);
   SCENE.ChangeClipPairThickz(p.C.iclipThick[2]);
   //to reset the volumn
   SCENE.SetVolumeX0(p.V.left);
   SCENE.SetVolumeX1(p.V.right);
   SCENE.SetVolumeY0(p.V.bottom);
   SCENE.SetVolumeY1(p.V.top);
   SCENE.SetVolumeZ0(p.V.nearz);
   SCENE.SetVolumeZ1(p.V.farz);
   
   wglMakeCurrent(m_hDC,m_hRC);
   if(p.V.changed)
   {
     SCENE.CreateScene(p.V.left, p.V.right, p.V.bottom, p.V.top, p.V.nearz, p.V.farz);
     //To set the light
     SCENE.TurnLighton(1);	
     SCENE.TurnLighton(2);
   }
   //to set the parameter for clipplane
   SCENE.Response(action_Object_Clipx);
   SCENE.Response(action_Object_ClipDP);
   if( (p.C.clipState[0]&1) && (p.C.clipState[0]&2) ) 
	    SCENE.Response(action_Object_ClipEP);
   else
      if(p.C.clipState[0]&1) SCENE.Response(action_Object_ClipE);

   SCENE.Response(action_Object_Clipy);
   SCENE.Response(action_Object_ClipDP);
   if( (p.C.clipState[1]&1) && (p.C.clipState[1]&2) ) 
	    SCENE.Response(action_Object_ClipEP);
   else
      if(p.C.clipState[1]&1) SCENE.Response(action_Object_ClipE);

   SCENE.Response(action_Object_Clipz);
   SCENE.Response(action_Object_ClipDP);
   if( (p.C.clipState[2]&1) && (p.C.clipState[2]&2) ) 
	    SCENE.Response(action_Object_ClipEP);
   else
      if(p.C.clipState[2]&1) SCENE.Response(action_Object_ClipE);


   wglMakeCurrent(NULL,NULL);   
   if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnEditCopy() 
{

	CDlg_CopyChoice p(this);

   if(m_Sample == NULL) return;

	if(p.DoModal() == IDCANCEL) return;
	switch (p.choice)
	{
	case operate_copyselectedatom:
	     m_SampleCopy->CopySelectedAtoms(m_Sample);
		 break;
    case operate_copysubsample:
	     m_SampleCopy->CopySubSample(m_Sample);
		 break;
    case operate_copysample:
	     m_SampleCopy->CopySample(m_Sample);
		 break;
	}

    Bitmap Snapshot=Bitmap();
    wglMakeCurrent(m_hDC,m_hRC);
        Snapshot.ReadFromViewport();
        Snapshot.SaveToClipBoard();
	wglMakeCurrent(NULL,NULL);

}

void CVisAtoms21View::OnEditCut() 
{
   CDlg_CopyChoice p(this);

   if(m_Sample == NULL) return;

	if(p.DoModal() == IDCANCEL) return;
	switch (p.choice)
	{
	case operate_copyselectedatom:
	     m_SampleCopy->CopySelectedAtoms(m_Sample);
		 m_Sample->Delete_SelectedAtoms( );
         if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		 break;
    case operate_copysubsample:
	     m_SampleCopy->CopySubSample(m_Sample);
	     m_Sample->Delete_SubSample();
         if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		 break;
    case operate_copysample:
	     m_SampleCopy->CopySample(m_Sample);
         if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
		 break;
	}

    Bitmap Snapshot=Bitmap();
    wglMakeCurrent(m_hDC,m_hRC);
        Snapshot.ReadFromViewport();
        Snapshot.SaveToClipBoard();
	wglMakeCurrent(NULL,NULL);

}


void CVisAtoms21View::OnEditPaste() 
{
	
   if(m_Sample == NULL)
   {
      MessageBox( "No target found", "Warning", MB_ICONASTERISK|MB_OK); 
      return;
   }

   if(m_SampleCopy == 0)
   {
      MessageBox( "No source found", "Warning", MB_ICONASTERISK|MB_OK); 
      return;
   }

   m_Sample->Paste(m_SampleCopy);
   if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnButton32806() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipx);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnButton32807() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipx);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32808() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipy);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32809() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipy);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32810() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipz);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32811() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipz);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}


void CVisAtoms21View::OnActionClipplaneInvertdirectionofclipplaneinx() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipx);
     SCENE.Response(action_Object_ClipR);
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
}

void CVisAtoms21View::OnActionClipplaneInvertdirectionofclipplaneiny() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipy);
     SCENE.Response(action_Object_ClipR);
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnActionClipplaneInvertdirectionofclipplaneinz() 
{
	wglMakeCurrent(m_hDC,m_hRC);
	 SCENE.Response(action_Object_Clipz);
     SCENE.Response(action_Object_ClipR);
	wglMakeCurrent(NULL,NULL);
	if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32836() 
{
    Invalidate(FALSE);
}

void CVisAtoms21View::OnFileSaveimageas() 
{
 	//OPENFILENAME ofn;
	static char szFile[256]="*.bmp";
	char szFilter[]="*.bmp";
	char szTitle[] = "Save the image as";
	char szExt[40] = "bmp";

    /*ofn.lStructSize = sizeof(OPENFILENAME); 
    ofn.hwndOwner = this->m_hWnd; 
    ofn.hInstance = NULL; 
    ofn.lpstrFile = szFile; 
    ofn.lpstrFilter = szFilter;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter    = 0;
    ofn.nFilterIndex      = 1;
    ofn.nMaxFile          = 256;
    //ofn.lpstrFileTitle    = szFileTitle;
    ofn.nMaxFileTitle     = 256;
    ofn.lpstrInitialDir  = NULL;
    ofn.lpstrTitle       = szTitle;
    ofn.nFileOffset       = 0;
    ofn.nFileExtension    = 40;
    ofn.lpstrDefExt       = szExt;
    ofn.lCustData         = 0;
    ofn.Flags = OFN_OVERWRITEPROMPT;
	*/
	CFileDialog p(FALSE, szTitle, szFilter, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, "Bitmap file:*.bmp", this);
 

	if(p.DoModal() == IDCANCEL) return;
	strcpy(szFile, p.GetPathName( ));
	//if( GetSaveFileName(&ofn) )
	{
      Bitmap Snapshot=Bitmap();
	  wglMakeCurrent(m_hDC,m_hRC);
         Snapshot.ReadFromViewport();
         Snapshot.SaveToFile(szFile);
	  wglMakeCurrent(NULL,NULL);
	}
} 
  
void CVisAtoms21View::OnFileNew() 
{
	CVisAtoms21Doc*p = GetDocument(); 
	m_Sample = (p->GetSample());
    m_Sample->ReleaseAll();
	m_Sample->MakeActive();

    wglMakeCurrent(m_hDC,m_hRC);
	 glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    wglMakeCurrent(NULL,NULL);
	Invalidate(FALSE);

}


void CVisAtoms21View::OnToolsSummary() 
{
	CDlg_Summary p;

	p.theSample = m_Sample->GetcurActiveSample();
	p.DoModal();
	
}


void CVisAtoms21View::OnButton32842() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateZ);
     SCENE.Response(Key_DOWN);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnButton32845() 
{
	wglMakeCurrent(m_hDC,m_hRC);
     SCENE.Response(action_Object_TranslateZ);
     SCENE.Response(Key_UP);	
	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	
}

void CVisAtoms21View::OnOptionPickatom() 
{

    CDlg_PickOption p;

	p.choice = m_Sample->GetPickOption();

	if(p.DoModal() == IDCANCEL) return;

	 switch (m_Sample->GetPickOption())
	 {
	 case atom_pick_Option_Single:
		 {
		   break;
		 }
	 case atom_pick_Option_Subsample:
		 {
		   break;
		 }
	 case atom_pick_Option_Multiple:
		 {
		   break;
		 }
	 case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
			
		   }
	 case atom_pick_Option_Tripoints:
		   {
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);

	float tcurX, tcurY, tcurZ;
    m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();
	m_Sample->SetPickOption(p.choice);
	m_Sample->ClearPickStatu();

}


void CVisAtoms21View::OnButton32857() 
{
  switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);
	  float tcurX, tcurY, tcurZ;
      m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();

	m_Sample->SetPickOption(atom_pick_Option_Single);
	m_Sample->ClearPickStatu();
    
}

void CVisAtoms21View::OnButton32858() 
{
  switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);
	  float tcurX, tcurY, tcurZ;
      m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();
	
	m_Sample->SetPickOption(atom_pick_Option_Multiple);
	m_Sample->ClearPickStatu();

}

void CVisAtoms21View::OnButton32859() 
{
  switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);
	  float tcurX, tcurY, tcurZ;
      m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();
	
	m_Sample->SetPickOption(atom_pick_Option_Subsample);
	m_Sample->ClearPickStatu();

}

void CVisAtoms21View::OnButton32860() 
{
  switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);
	  float tcurX, tcurY, tcurZ;
      m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();
	m_Sample->SetPickOption(atom_pick_Option_Square);
	m_Sample->ClearPickStatu();
}

void CVisAtoms21View::OnButton32861() 
{
  switch (m_Sample->GetPickOption())
	 {
	   case atom_pick_Option_Square:
		   {
		    DrawFocusRect(m_hDC, &Focus);
			Focus.left = 0;
			Focus.right = 0;
			Focus.top = 0;
			Focus.bottom = 0;
		    break;
		   }
		   
	 }
	wglMakeCurrent(m_hDC,m_hRC);
	  float tcurX, tcurY, tcurZ;
      m_Sample->DropPickedAtom(10, 10, &SCENE, &tcurX, &tcurY, &tcurZ);
	wglMakeCurrent(NULL,NULL);
    m_Sample->unSelect_AllAtoms();

	m_Sample->SetPickOption(atom_pick_Option_Tripoints);
	m_Sample->ClearPickStatu();

}

void CVisAtoms21View::OnButton32871() 
{
     if( SCENE.GetUpdateStyle() == scene_Update_ByRequire)
	      SCENE.SetAsUpdateAuto();
	 else
		  SCENE.SetAsUpdateByRequire();
}


void CVisAtoms21View::OnToolsGroupatomsbycolor() 
{
	if(!m_Sample->ifHasColor())
	{	MessageBeep(0xFFFFFFFF);
		MessageBox("No color information for atoms", "Warning", MB_OK|	MB_ICONASTERISK);
		return;
	}
    if(m_Sample->GroupAtomsbyColor()>1) Invalidate(FALSE);	
}

void CVisAtoms21View::OnButton32777() 
{
	if(m_Sample->Lzoomout())
	{
      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	}
	
}

void CVisAtoms21View::OnButton32778() 
{
	if(m_Sample->Lzoomin())
	{
      if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	}
	
}

void CVisAtoms21View::OnOptionsFileformat() 
{
	CVisAtoms21Doc *p = GetDocument();
	p->fmt.DoModal(); 

	
}

void CVisAtoms21View::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	wglMakeCurrent(m_hDC,m_hRC);
     int curLab = SCENE.GetSystemStyle();
	 SCENE.SetAsLaboratorySystem();
     SCENE.Response(action_Object_TranslateY);
	 if(nSBCode == SB_LINEDOWN) SCENE.Response(Key_UP);	
	 if(nSBCode == SB_LINEUP) SCENE.Response(Key_DOWN);	

     if(curLab & scene_System_Labrotary) 
       SCENE.SetAsLaboratorySystem();
     else
       SCENE.SetAsRelativeSystem();

	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);

	CView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CVisAtoms21View::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	wglMakeCurrent(m_hDC,m_hRC);
     int curLab = SCENE.GetSystemStyle();
	 SCENE.SetAsLaboratorySystem();
     SCENE.Response(action_Object_TranslateX);
	 if(nSBCode == SB_LINEDOWN) SCENE.Response(Key_DOWN);	
	 if(nSBCode == SB_LINEUP) SCENE.Response(Key_UP);	

     if(curLab & scene_System_Labrotary) 
       SCENE.SetAsLaboratorySystem();
     else
       SCENE.SetAsRelativeSystem();

	wglMakeCurrent(NULL,NULL);
    if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);

	
	CView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CVisAtoms21View::OnToolsMakemovie() 
{
	char szFile[256]="*.avi";
	char szFilter[]="*.avi";
	char szTitle[] = "Save the movei as";
	char szExt[40] = "avi";

	if(!iMovieOpen)
	{
      if(MessageBox("When you start movie, any movement of object will be recorded. The AVI file may occupy a lof of space.",
							          "",MB_ICONWARNING|MB_OKCANCEL) ==IDOK)
     {
	      CFileDialog p(FALSE, szTitle, szFilter, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, "AVI file:*.avi", this);
		  if(p.DoModal() == IDCANCEL) return;
	      strcpy(szFile, p.GetPathName( ));

		  AviSnapshot.CreateAVIFile(szFile);
		  iMovie = 1;
	      iMovieOpen = 1;
		  CheckMenuItem((GetParentFrame()->GetMenu())->m_hMenu,ID_TOOLS_MAKEMOVIE,MF_CHECKED);
	 }
	}
	else
	{
		 if(iMovie) 
		 {
			iMovie = 0;
		    CheckMenuItem( (GetParentFrame()->GetMenu())->m_hMenu,ID_TOOLS_MAKEMOVIE,MF_UNCHECKED);
		 }
		 else 
		 {
			iMovie = 1;
		    CheckMenuItem((GetParentFrame()->GetMenu())->m_hMenu,ID_TOOLS_MAKEMOVIE,MF_CHECKED);
		 }
		 return;
	}

}



void CVisAtoms21View::OnToolsDensityofsample() 
{
	//CDlg_Density p;

	//p.theSample = (Atoms21*)m_Sample->GetcurActiveSample();
	//if(p.theSample == NULL) return;
	//p.DoModal();
}


void CVisAtoms21View::OnEditNormalization() 
{
   if(m_Sample == NULL) return;

   float left, right,top, bottom,nearz, farz, z0;
   m_Sample->GetSampleBoxRangeX(&left, &right);
   m_Sample->GetSampleBoxRangeY(&bottom, &top);
   m_Sample->GetSampleBoxRangeZ(&nearz, &farz);

   
   z0 = max(fabs(nearz), fabs(farz));
   farz  = z0;
   nearz = -z0;

   wglMakeCurrent(m_hDC,m_hRC);
     SCENE.CreateScene(left, right, bottom, top, nearz, farz);
     SCENE.TurnLighton(1);	
     SCENE.TurnLighton(2);

    int clipState =   SCENE.IsClipPlaneEnabled(1);
        SCENE.Response(action_Object_Clipx);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
		
        clipState =   SCENE.IsClipPlaneEnabled(2);
        SCENE.Response(action_Object_Clipy);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
		  
        clipState =   SCENE.IsClipPlaneEnabled(3);
        SCENE.Response(action_Object_Clipz);
        SCENE.Response(action_Object_ClipDP);
        if( clipState ==2) 
	        SCENE.Response(action_Object_ClipEP);
        else
            if(clipState == 1) SCENE.Response(action_Object_ClipE);
  
   wglMakeCurrent(NULL,NULL);   
   Invalidate(FALSE);
}

void CVisAtoms21View::OnEditMakesubsample() 
{
	static CMakeClusters P("Make clusters", this, 0);
	
	if(m_Sample->GetcurActiveSample() == NULL)
	{
	MessageBox("For the first, you should have a sample", "Warning", 	MB_ICONASTERISK|MB_OK);
	return;
	}
    
	P.DrawingSty.R = (float)rand()/(float)RAND_MAX; 
	P.DrawingSty.G = (float)rand()/(float)RAND_MAX; 
	P.DrawingSty.B = (float)rand()/(float)RAND_MAX; 
	wglMakeCurrent(m_hDC,m_hRC);
	float color[4];
	  glGetFloatv(GL_COLOR_CLEAR_VALUE, color);
	  P.DrawingSty.bR = color[0];
	  P.DrawingSty.bG = color[1];
	  P.DrawingSty.bB = color[2];
	wglMakeCurrent(NULL,NULL);
	if(P.DoModal() == IDCANCEL) return;

	int I = m_Sample->GetNumb_of_type()+1;
	int err;
	switch (P.Boundary.style&3)
	{
	  case makestyle_picked:
	  {
	   err = m_Sample->MakeSubSamplefrom(I);
	   break;
	  }
      case makestyle_boundary:
	  {
	    err = m_Sample->MakeSubSamplefrom(I, P.Boundary.numb, P.Boundary.str, P.Boundary.lstate);
	    break;
	  }
      case makestyle_mix:
	  {
	    err = m_Sample->MakeSubSamplefrom(I, P.Boundary.percentage);
		break;
	  }
      case 3:
	  {
	    err = m_Sample->MakeSubSamplefrom(I, P.Boundary.percentage, P.Boundary.numb, P.Boundary.str, P.Boundary.lstate);
		break;
	  }

	}

	//To change the drawing style and property
	if(err)
	{
       m_Sample->ChangeColor_subSample(I, P.DrawingSty.R, P.DrawingSty.G, P.DrawingSty.B, P.DrawingSty.A);
	   m_Sample->ChangeStyle_subSample(I, P.DrawingSty.style+1);
	  if(SCENE.GetUpdateStyle() == scene_Update_Automatic) Invalidate(FALSE);
	}
}
