// Dlg_ReadinProgress.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_ReadinProgress dialog

class CDlg_ReadinProgress : public CDialog
{
// Construction
public:
	CDlg_ReadinProgress(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_ReadinProgress)
	enum { IDD = IDD_READINPROGRESS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

char str[256];
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_ReadinProgress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_ReadinProgress)
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
