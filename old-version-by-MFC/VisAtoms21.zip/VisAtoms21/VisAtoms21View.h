// VisAtoms21View.h : interface of the CVisAtoms21View class
//
/////////////////////////////////////////////////////////////////////////////
#include "Glc.h"
#include "Atoms21.h"
#include "Dlg_ChangeProperty.h"
#include "Dlg_AtomOrSubSample.h"
#include "MakeClusters.h"
#include "Dlg_Show.h"
#include "ScenPropertySheet.h"
#include "Dlg_Summary.h"
#include "Dlg_PickOption.h"
#include "Dlg_CopyChoice.h"
#include "PropertyBackG.h"
#include "Dlg_Density.h"


class CVisAtoms21View : public CView
{
protected: // create from serialization only
	CVisAtoms21View();
	DECLARE_DYNCREATE(CVisAtoms21View)

// Attributes
public:
	CVisAtoms21Doc* GetDocument();
	HGLRC m_hRC;	// Rendering Context
	HDC m_hDC;		// Device Context
	Atoms21*m_Sample; 
	Atoms21*m_SampleCopy; 
    Scene  SCENE;
    //GLFont Font;

    RECT  Focus;
	float curX, curY, curZ;
	int iMovie, iMovieOpen;
    AviBitmap AviSnapshot;

	void GetTransMatrix(double*);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVisAtoms21View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVisAtoms21View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CVisAtoms21View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnButton32772();
	afx_msg void OnButton32773();
	afx_msg void OnButton32774();
	afx_msg void OnButton32775();
	afx_msg void OnButton32779();
	afx_msg void OnButton32780();
	afx_msg void OnButton32782();
	afx_msg void OnButton32783();
	afx_msg void OnButton32784();
	afx_msg void OnButton32785();
	afx_msg void OnButton32787();
	afx_msg void OnButton32788();
	afx_msg void OnButton32789();
	afx_msg void OnButton32790();
	afx_msg void OnButton32791();
	afx_msg void OnButton32792();
	afx_msg void OnButton32794();
	afx_msg void OnButton32795();
	afx_msg void OnButton32806();
	afx_msg void OnButton32807();
	afx_msg void OnButton32808();
	afx_msg void OnButton32809();
	afx_msg void OnButton32810();
	afx_msg void OnButton32811();
	afx_msg void OnButton32836();
	afx_msg void OnButton32842();
	afx_msg void OnButton32845();
	afx_msg void OnButton32857();
	afx_msg void OnButton32858();
	afx_msg void OnButton32859();
	afx_msg void OnButton32860();
	afx_msg void OnButton32861();
	afx_msg void OnButton32871();
	afx_msg void OnOptionBackground();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnEditProperty();
	afx_msg void OnEditShow();
	afx_msg void OnEditHide();
	afx_msg void OnEditDelete();
	afx_msg void OnOptionScene();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnActionClipplaneInvertdirectionofclipplaneinx();
	afx_msg void OnActionClipplaneInvertdirectionofclipplaneiny();
	afx_msg void OnActionClipplaneInvertdirectionofclipplaneinz();
	afx_msg void OnFileSaveimageas();
	afx_msg void OnFileNew();
	afx_msg void OnToolsSummary();
	afx_msg void OnOptionPickatom();
	afx_msg void OnToolsGroupatomsbycolor();
	afx_msg void OnButton32777();
	afx_msg void OnButton32778();
	afx_msg void OnOptionsFileformat();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnToolsMakemovie();
	afx_msg void OnToolsDensityofsample();
	afx_msg void OnEditNormalization();
	afx_msg void OnEditMakesubsample();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in VisAtoms21View.cpp
inline CVisAtoms21Doc* CVisAtoms21View::GetDocument()
   { return (CVisAtoms21Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
