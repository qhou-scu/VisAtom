// Dlg_Density.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Atoms21.h"
#include "Dlg_Density.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_Density dialog


CDlg_Density::CDlg_Density(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_Density::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_Density)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg_Density::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_Density)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_Density, CDialog)
	//{{AFX_MSG_MAP(CDlg_Density)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_Density message handlers

BOOL CDlg_Density::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	char str[40];
	float D = (float)theSample->CalDensity_Sample();
	sprintf(str, "%f",D); 

	GetDlgItem(IDC_STATIC1)->SetWindowText(str);

	D = (float)theSample->CalDensity_Selected();
	sprintf(str, "%f",D); 

	GetDlgItem(IDC_STATIC2)->SetWindowText(str);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
