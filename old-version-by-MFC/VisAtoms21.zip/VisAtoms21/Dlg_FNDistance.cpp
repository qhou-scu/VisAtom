// Dlg_FNDistance.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_FNDistance.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_FNDistance dialog
extern "C" { void __stdcall GETVALUE(char*,float*,int*ERR);
             void __stdcall SETLATTICEPARA(float*);
             void __stdcall GETLATTICEPARA(float*);
			 void __stdcall SETGROUPNUMB(int*);
			 void __stdcall GETGROUPNUMB(int*);
             void __stdcall SETLAYER_FN_DISTANCE(int*);
             void __stdcall GETLAYER_FN_DISTANCE(int*);
             void __stdcall GETILAYER_FN_DISTANCE(int*);
             void __stdcall SETNN_FN_DISTANCE(int*);
             void __stdcall GETNN_FN_DISTANCE(int*);
             void __stdcall IMPORTSAMPLE_FN_DISTANCE(int*,int*,float*, float*,float*);

             void __stdcall CAL_FN_DISTANCE();
             void __stdcall GETVALUE_FN_DISTANCE_ALL(int*,float*,float*,float*);
             void __stdcall GETVALUE_FN_DISTANCE_11(int*, int*, float*, float*,float*);
             void __stdcall GETVALUE_FN_DISTANCE_NAALL(int*,float*,float*);
             void __stdcall GETVALUE_FN_DISTANCE_NA11(int*,int*,float*,float*);
             void __stdcall END_FN_DISTANCE();
             void __stdcall RELEASE_ANALYSISDATA();

           }

UINT Cal_FN_DistanceProc( LPVOID pParam )
{
   	CAL_FN_DISTANCE();
	return 0;	// thread completed successfully
} 


CDlg_FNDistance::CDlg_FNDistance(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_FNDistance::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_FNDistance)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg_FNDistance::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_FNDistance)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_FNDistance, CDialog)
	//{{AFX_MSG_MAP(CDlg_FNDistance)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
	ON_BN_CLICKED(IDC_RADIO6, OnRadio6)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_WM_TIMER()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_FNDistance message handlers

BOOL CDlg_FNDistance::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RECT rect,rect1;
	int W, H, L, L1;
	this->GetWindowRect(&rect);
	GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	W  = rect.right - rect1.left-16;
	L  = rect.left;
	L1 = rect1.left;
	this->GetClientRect(&rect);
	H = rect.bottom - rect.top-16;
	rect.top    = 8;
	rect.left   = L1-L;
	rect.right  = rect.left +W;
	rect.bottom = rect.top + H;

	Fig.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,rect,this,0,NULL);

	float temp;
	int    itemp;
	char str[32];
	GETLATTICEPARA(&temp);
	sprintf(str,"%f",temp);
	SetDlgItemText(IDC_EDITLU, str);
    
    GETLAYER_FN_DISTANCE(&itemp);
	SetDlgItemInt(IDC_EDIT1, itemp);

    GETNN_FN_DISTANCE(&itemp);
	SetDlgItemInt(IDC_EDIT2, itemp);

    OnRadio1(); 
    OnRadio5(); 

	int i,n;
	GETGROUPNUMB(&n);
	for(i=1;i<=n; i++)
	{
	  sprintf(str,"%i",i);
	  ((CComboBox*)GetDlgItem(IDC_ATOM2))->AddString(str);
	}
    ((CComboBox*)GetDlgItem(IDC_ATOM2))->SetCurSel(0);

	HICON icon = LoadIcon(AfxGetInstanceHandle( ), MAKEINTRESOURCE(IDR_MAINFRAME));
	this->SetIcon(icon, FALSE);

    Kernal = NULL;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_FNDistance::ImportSample(Atoms21*sor) 
{
  int nxyz, nGroup;
  int *ityp;
  float*x,*y,*z;
  nxyz = sor->NumberofAtom();
  ityp = sor->GetSampleTypeP();
  x = sor->GetSampleXP();
  y = sor->GetSampleYP();
  z = sor->GetSampleZP();
  nGroup = sor->GetNumb_of_type();
  SETGROUPNUMB(&nGroup);
  IMPORTSAMPLE_FN_DISTANCE(&nxyz,ityp,x,y,z);
}


void CDlg_FNDistance::OnRadio1() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);
  GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
}

void CDlg_FNDistance::OnRadio2() 
{
  CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);
  GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);
}

void CDlg_FNDistance::OnRadio5() 
{
  CheckRadioButton(IDC_RADIO5, IDC_RADIO6, IDC_RADIO5);
}

void CDlg_FNDistance::OnRadio6() 
{
  CheckRadioButton(IDC_RADIO5, IDC_RADIO6, IDC_RADIO6);
	
}

void CDlg_FNDistance::OnChangeEdit2() 
{
	int i = GetDlgItemInt(IDC_EDIT2);
	if(i <=0) 
	{
		MessageBox("This value should be at least 1","",MB_OK); 
        GETNN_FN_DISTANCE(&i);
	    SetDlgItemInt(IDC_EDIT2, i);
		return;
	}
   SETNN_FN_DISTANCE(&i);
}

void CDlg_FNDistance::OnDestroy() 
{
	CDialog::OnDestroy();
	
    END_FN_DISTANCE();
    RELEASE_ANALYSISDATA();
}

void CDlg_FNDistance::OnExit() 
{
	CDialog::OnOK();
}

void CDlg_FNDistance::OnOK() 
{
   OnButtonStart();
}

void CDlg_FNDistance::OnButtonStart() 
{
	//*** to get lattice unit
    char str[32];
    float t;
    int err;

    GetDlgItemText(IDC_EDITLU, str,32);
    GETVALUE(str, &t, &err);
    if(t<= 0.f) 
    {
	  MessageBox("The lattice parameter smaller than zero.", "",MB_OK);
      GETLATTICEPARA(&t);	
	  sprintf(str,"%f",t);
      SetDlgItemText(IDC_EDITLU, str);
	  return;
    }
    SETLATTICEPARA(&t);	
	//to get number of layer
    err = GetDlgItemInt(IDC_EDIT1);
    if(err <= 0)
    {
	  MessageBox("The number of layer concerned should be greater than zero", "",MB_OK);
      GETLAYER_FN_DISTANCE(&err);	
      SetDlgItemInt(IDC_EDIT1, err);
	  return;
    }
    SETLAYER_FN_DISTANCE(&err);	

    Kernal = AfxBeginThread(Cal_FN_DistanceProc, NULL, THREAD_PRIORITY_NORMAL, 0, 0, NULL );
	if(Kernal != NULL) //disable all contrals
	{
	   GetDlgItem(IDC_EDITLU)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	   GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
	   GetDlgItem(IDC_BUTTON_START)->EnableWindow(FALSE);
       SetTimer(nIDEvent, 100, NULL);
    }

	return;

}

void CDlg_FNDistance::OnTimer(UINT nIDEvent) 
{
    DWORD  lpExitCode;
	if(Kernal == NULL) 
	{
	   GetDlgItem(IDC_PROMPT)->SetWindowText("");
	   return;
	}
	static int i=0;
	GetExitCodeThread(Kernal->m_hThread, &lpExitCode);
	{
	   if(lpExitCode != STILL_ACTIVE)
	   {
	     float*X, *Y,*XERR, *YERR;
	     int bins, ATOM, j;

	     GETILAYER_FN_DISTANCE(&bins);
	     if(bins == 0) return;
         X   = new float[bins];
         Y   = new float[bins];
         XERR = new float[bins];
         YERR = new float[bins];
		 for(j=0; j<bins; j++) XERR[j] = 0.f;
		 ATOM = ((CComboBox*)GetDlgItem(IDC_ATOM2))->GetCurSel()+1;
         if(IsDlgButtonChecked(IDC_RADIO1) )
		 {
            if(IsDlgButtonChecked(IDC_RADIO5) )
			{
             GETVALUE_FN_DISTANCE_ALL(&bins,X,Y,YERR);

	         Fig.NewCurve(4, bins, X, Y,XERR,YERR);
             Fig.ChangeCurveSymbColor();
             Fig.ChangeCurveSymbSize(0.02f);
			}
			else
			{
              GETVALUE_FN_DISTANCE_NAALL(&bins,X,Y);
	          Fig.NewCurve(0, bins, X, Y);
              Fig.Addsymbole(XY_SYMB_SOLIDSQUARE);
              Fig.ChangeCurveSymbColor();    
              Fig.ChangeCurveSymbSize(0.03f);
			}
		 }
		 else
		 {
             if(IsDlgButtonChecked(IDC_RADIO5) )
			{
             GETVALUE_FN_DISTANCE_11(&ATOM,&bins,X,Y,YERR);
	         Fig.NewCurve(4, bins, X, Y,XERR,YERR);
             Fig.ChangeCurveSymbColor();
             Fig.ChangeCurveSymbSize(0.02f);
			}
			else
			{
              GETVALUE_FN_DISTANCE_NA11(&ATOM,&bins,X,Y);
	          Fig.NewCurve(0, bins, X, Y);
              Fig.Addsymbole(XY_SYMB_SOLIDSQUARE);
              Fig.ChangeCurveSymbColor();
              Fig.ChangeCurveSymbSize(0.03f);
			}
		 }

	     Fig.AutoYRange();
	     int temp;
	     temp = ((int)(bins/2)+1)*2;
         Fig.ChangeXAxsis_nTick(temp);
	     Fig.ChangeXRange(0.f, temp);
 	     Fig.CreateXAxsisLabel("%2.0f");
         Fig.ChangeXLabelScal(0.07f, 0.08f);
 	     Fig.CreateYAxsisLabel("%5.3f");
         Fig.ChangeYLabelScal(0.07f, 0.08f);
	     Fig.CreateXTitle("Shell");
         if(IsDlgButtonChecked(IDC_RADIO5) )
           Fig.CreateYTitle("Shell Seperation (in LU)");
         else
           Fig.CreateYTitle("Number of Atoms on Shell");
	     delete X;
	     delete Y;
		 delete XERR;
		 delete YERR;
		 Invalidate(FALSE);
		 Kernal = NULL;

		 //recover the status
	     GetDlgItem(IDC_EDITLU)->EnableWindow(TRUE);

	     GetDlgItem(IDC_EDIT1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_EDIT2)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO1)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO2)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO5)->EnableWindow(TRUE);
	     GetDlgItem(IDC_RADIO6)->EnableWindow(TRUE);
         if(IsDlgButtonChecked(IDC_RADIO1) )
	       GetDlgItem(IDC_ATOM2)->EnableWindow(FALSE);
		 else
	       GetDlgItem(IDC_ATOM2)->EnableWindow(TRUE);

	     GetDlgItem(IDC_BUTTON_START)->EnableWindow(TRUE);
         KillTimer(nIDEvent);
		 GetDlgItem(IDC_PROMPT)->SetWindowText("");
	     CDialog::OnTimer(nIDEvent);
		 return;
	   }
	}
	if(i < 10) 
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("Please Waiting...");
		i++;
	}
	else
	{
		GetDlgItem(IDC_PROMPT)->SetWindowText("");
		i++;
		if(i >= 15) i= 0;
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlg_FNDistance::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	CDialog::OnSize(nType, cx, cy);
	
	if(GetDlgItem(IDC_FIGFRAME) != NULL)
	{
	 RECT rect,rect1;
	 int W, H, L, L1;
	 this->GetWindowRect(&rect);
	 GetDlgItem(IDC_FIGFRAME)->GetWindowRect(&rect1);
	 W  = rect.right - rect1.left-16;
	 L  = rect.left;
	 L1 = rect1.left;
	 this->GetClientRect(&rect);
	 H = rect.bottom - rect.top-16;
	 rect.top    = 8;
	 rect.left   = L1-L;
	 rect.right  = rect.left +W;
	 rect.bottom = rect.top + H;
	 Fig.MoveWindow(&rect, TRUE);
	}
	
}
