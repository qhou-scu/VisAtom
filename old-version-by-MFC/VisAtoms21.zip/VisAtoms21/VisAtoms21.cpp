// VisAtoms21.cpp : Defines the class behaviors for the application.
//
#include "stdafx.h"
#include "VisAtoms21.h"

#include "MainFrm.h"
#include "VisAtoms21Doc.h"
#include "VisAtoms21View.h"
#include "Splash.h"
#include "Dlg_Choice.h"
#include "Dlg_PCorre.h"
#include "Dlg_PDistrib.h"
#include "Dlg_SFactor.h"
#include "Dlg_ZDistrib.h"
#include "Dlg_CoordNumb.h"
#include "Dlg_FNDistance.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21App

BEGIN_MESSAGE_MAP(CVisAtoms21App, CWinApp)
	ON_COMMAND(CG_IDS_TIPOFTHEDAY, ShowTipOfTheDay)
	//{{AFX_MSG_MAP(CVisAtoms21App)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_TOOLS_ANALYSIS_PAIRCORRELATION, OnToolsAnalysisPaircorrelation)
	ON_COMMAND(ID_TOOLS_ANALYSIS_PARTICLEDISTRIBUSTIONAROUND, OnToolsAnalysisParticledistribustionaround)
	ON_COMMAND(ID_TOOLS_ANALYSIS_STRUCTUREFACTOR, OnToolsAnalysisStructurefactor)
	ON_COMMAND(ID_TOOLS_ANALYSIS_PARTICLEDISTRIBUTIONALONGZAXSIS, OnToolsAnalysisParticledistributionalongzaxsis)
	ON_COMMAND(ID_TOOLS_ANALYSIS_COORDINATIONNUMBERDISTRIBUTION, OnToolsAnalysisCoordinationnumberdistribution)
	ON_COMMAND(ID_TOOLS_ANALYSIS_SHELLSTRUCTURE, OnToolsAnalysisShellstructure)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21App construction

CVisAtoms21App::CVisAtoms21App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CVisAtoms21App object

CVisAtoms21App theApp;

//This is added by the Hou Qing
CVisAtoms21View*theView;
CVisAtoms21Doc *theDoc;
CMainFrame      *theMainFrame;

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21App initialization

BOOL CVisAtoms21App::InitInstance()
{

	// CG: The following block was added by the Splash Screen component.

	{
		CCommandLineInfo cmdInfo;

		ParseCommandLine(cmdInfo);

		CSplashWnd::EnableSplashScreen(cmdInfo.m_bShowSplash);
	}
	
	// to check the system times
    SYSTEMTIME lpSystemTime; 
    GetSystemTime(&lpSystemTime);   
    if(lpSystemTime.wYear*100+lpSystemTime.wMonth >= 199910)
    {
         //MessageBox(NULL,"You are using a beta version of VisAtoms, the time is expired", "Warning", MB_OK|MB_ICONWARNING);
		 //return FALSE;
	}
	
	// Standard initialization
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CVisAtoms21Doc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CVisAtoms21View));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	//To get the point to the document and view and mainframe
	POSITION rPos;
	rPos = pDocTemplate->GetFirstDocPosition( );
	theDoc = (CVisAtoms21Doc*)pDocTemplate->GetNextDoc(rPos );

	rPos = theDoc->GetFirstViewPosition( );
	theView = (CVisAtoms21View*)theDoc->GetNextView(rPos);

	theMainFrame = (CMainFrame*)theView->GetParentFrame();

 
	// CG: This line inserted by 'Tip of the Day' component.
	ShowTipAtStartup();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CVisAtoms21App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CVisAtoms21App commands

BOOL CVisAtoms21App::OnIdle(LONG lCount) 
{
	float x,y,z;
	int id;
	char str[80];
	RECT rect;

	//To set the panel style
	UINT nID, nStyle; int cxWidth;
	(theMainFrame->GetStatusBar())->GetPaneInfo(1, nID, nStyle, cxWidth ); 
	(theMainFrame->GetStatusBar())->SetPaneInfo(1, nID, nStyle, 100 ); 
	//To show the size of client 
	((CVisAtoms21View*)(theMainFrame->GetActiveView( )))
		->GetClientRect(&rect);
	sprintf(str, "Client area(%i, %i)", rect.right-rect.left+1, rect.bottom-rect.top+1);
	(theMainFrame->GetStatusBar())->SetPaneText(1, str, TRUE);
	//To show the statu of picked atoms
	if( (theDoc->GetSample())->GetPickStatu())
	{
     id = (theDoc->GetSample())->GetCurAtom();
	 x = theView->curX;
	 y = theView->curY;
	 z = theView->curZ;
	 sprintf(str, "Atom #%i (%f, %f, %f)", id, x,y,z);
	(theMainFrame->GetStatusBar())->SetPaneText(2, str, TRUE);
	}
	else
	{
	 strcpy(str, "No atom picked");
	 (theMainFrame->GetStatusBar())->SetPaneText(2, str, TRUE);
	}
	// to show if movie recording
    if( ((CVisAtoms21View*)(theMainFrame->GetActiveView( )))->iMovie)
	{
	   
	   CheckMenuItem((theMainFrame->GetMenu())->m_hMenu,ID_TOOLS_MAKEMOVIE,MF_CHECKED);
	   (theMainFrame->GetStatusBar())->SetPaneText(3, "Movie in recording",TRUE);
	}
	else
	{
	    CheckMenuItem((theMainFrame->GetMenu())->m_hMenu,ID_TOOLS_MAKEMOVIE,MF_UNCHECKED);
       (theMainFrame->GetStatusBar())->SetPaneText(3, "",TRUE);
	}

	
	//To update the transformation matrix for axsis flag
	double mat[16];
	((CVisAtoms21View*)(theMainFrame->GetActiveView( )))->GetTransMatrix(mat);
	theMainFrame->UpdateAxsisFlag(mat);

	//To calculate center of massetc
	if(lCount == 0)
	{
      (theDoc->GetSample())->CalSubSampleCenterofMass_in();
      (theDoc->GetSample())->CalSubSampleBoxRangeX_in();
      (theDoc->GetSample())->CalSubSampleBoxRangeY_in();
      (theDoc->GetSample())->CalSubSampleBoxRangeZ_in();
      (theDoc->GetSample())->CalSampleBoxSizeX();
      (theDoc->GetSample())->CalSampleBoxSizeY();
      (theDoc->GetSample())->CalSampleBoxSizeZ();
	}

	return CWinApp::OnIdle(lCount);
}

BOOL CVisAtoms21App::PreTranslateMessage(MSG* pMsg)
{

	// CG: The following line was added by the Splash Screen component.

	CSplashWnd::PreTranslateAppMessage(pMsg);
	return CWinApp::PreTranslateMessage(pMsg);
}

void CVisAtoms21App::ShowTipAtStartup(void)
{
	// CG: This function added by 'Tip of the Day' component.

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	if (cmdInfo.m_bShowSplash)
	{
		CTipDlg dlg;
		if (dlg.m_bStartup)
			dlg.DoModal();
	}

}

void CVisAtoms21App::ShowTipOfTheDay(void)
{
	// CG: This function added by 'Tip of the Day' component.

	CTipDlg dlg;
	dlg.DoModal();

}

void CVisAtoms21App::OnToolsAnalysisPaircorrelation() 
{
	
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_PCorre dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
}

void CVisAtoms21App::OnToolsAnalysisParticledistribustionaround() 
{
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_PDistrib dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
	
}

void CVisAtoms21App::OnToolsAnalysisStructurefactor() 
{
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_SFactor dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
}

void CVisAtoms21App::OnToolsAnalysisParticledistributionalongzaxsis() 
{
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_ZDistrib dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
}

void CVisAtoms21App::OnToolsAnalysisCoordinationnumberdistribution() 
{
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_CoordNumb dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
	
}

void CVisAtoms21App::OnToolsAnalysisShellstructure() 
{
	Atoms21*m_Sample = theDoc->GetSample();
	if(m_Sample->NumberofAtom() <= 0)
	{
	   AfxMessageBox( "No sample exist.", MB_OK, 0);
	   return;
	}

    CDlg_Choice p;
    if(p.DoModal() == IDCANCEL) return;
	
	Atoms21*temp = new Atoms21();

	switch (p.choice)
	{
	case operate_copyselectedatom:
	     temp->CopySelectedAtoms(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No atom selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysubsample:
	     temp->CopySubSample(m_Sample);
	     if(temp->NumberofAtom() <= 0)
	     {
	        AfxMessageBox( "No subsample selected.", MB_OK, 0);
	        return;
	     }
		 break;
    case operate_copysample:
	     temp->CopySample(m_Sample);
		 break;
	}
	CDlg_FNDistance dlg;
	dlg.ImportSample(temp);
	delete temp;
    dlg.DoModal();
	
}
