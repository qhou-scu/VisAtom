// Dlg_ZDistrib.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_ZDistrib dialog
#include "Atoms21.h"
#include "WndGL_xyFig.h"

class CDlg_ZDistrib : public CDialog
{
// Construction
public:
	CDlg_ZDistrib(CWnd* pParent = NULL);   // standard constructor
	~CDlg_ZDistrib();   

// Dialog Data
	//{{AFX_DATA(CDlg_ZDistrib)
	enum { IDD = IDD_ZDISTRIB };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_ZDistrib)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_ZDistrib)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnChangeEdit2();
	afx_msg void OnExit();
	afx_msg void OnButtonStart();
	afx_msg void OnDestroy();
	afx_msg void OnRadio3();
	afx_msg void OnRadio4();
	virtual void OnOK();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelchangeAtom1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	CWndGL_xyFig Fig;
public:
	void ImportSample(Atoms21*);

};
