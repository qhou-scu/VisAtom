// Dlg_GL_Axsis.h : header file
//
#include "WndGL_Axsis.h"
/////////////////////////////////////////////////////////////////////////////
// CDlg_GL_Axsis dialog

class CDlg_GL_Axsis : public CDialog
{
// Construction
public:
	CDlg_GL_Axsis(CWnd* pParent = NULL);   // standard constructor
    void UpdateMatrix(double mat[]); 
// Dialog Data
	//{{AFX_DATA(CDlg_GL_Axsis)
	enum { IDD = IDD_GLAXSIS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_GL_Axsis)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
    CWndGL_Axsis m_Axsis;
	// Generated message map functions
	//{{AFX_MSG(CDlg_GL_Axsis)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
