// Dlg_CopyChoice.cpp : implementation file
//

#include "stdafx.h"
#include "VisAtoms21.h"
#include "Dlg_CopyChoice.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg_CopyChoice dialog


CDlg_CopyChoice::CDlg_CopyChoice(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg_CopyChoice::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlg_CopyChoice)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	choice = operate_copyselectedatom;
}


void CDlg_CopyChoice::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg_CopyChoice)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlg_CopyChoice, CDialog)
	//{{AFX_MSG_MAP(CDlg_CopyChoice)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg_CopyChoice message handlers

BOOL CDlg_CopyChoice::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(choice == operate_copyselectedatom)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO1);

	if(choice == operate_copysubsample)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO2);


	if(choice == operate_copysample)
	   CheckRadioButton(IDC_RADIO1, IDC_RADIO3, IDC_RADIO3);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlg_CopyChoice::OnOK() 
{
	if(((CButton*) GetDlgItem(IDC_RADIO1))->GetCheck() ) 
	{
		choice = operate_copyselectedatom;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO2))->GetCheck() ) 
	{
		choice = operate_copysubsample;
	}

	if(((CButton*) GetDlgItem(IDC_RADIO3))->GetCheck() ) 
	{
		choice = operate_copysample;
	}
	

	CDialog::OnOK();
}
