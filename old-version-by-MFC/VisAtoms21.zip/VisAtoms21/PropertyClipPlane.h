// PropertyClipPlane.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane dialog

class CPropertyClipPlane : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyClipPlane)

// Construction
public:
	CPropertyClipPlane();
	~CPropertyClipPlane();
public:
	float   iclipStep[3];
	float   iclipThick[3];
	int     clipState[3];
// Dialog Data
	//{{AFX_DATA(CPropertyClipPlane)
	enum { IDD = IDD_PROPPAGE_SCENE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyClipPlane)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyClipPlane)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheck1();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnCheck3();
	afx_msg void OnCheck2();
	afx_msg void OnChangeEdit1();
	afx_msg void OnChangeEdit2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CPropertyClipPlane dialog

class CPropertyClipPlane : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyClipPlane)

// Construction
public:
	CPropertyClipPlane();
	~CPropertyClipPlane();

// Dialog Data
	//{{AFX_DATA(CPropertyClipPlane)
	enum { IDD = IDD_PROPPAGE_SCENE2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyClipPlane)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyClipPlane)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
