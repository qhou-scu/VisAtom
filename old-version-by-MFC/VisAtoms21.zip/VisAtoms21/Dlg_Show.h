// Dlg_Show.h : header file
//
#include "Sample.h"
#define choice_pickedatom 0
#define choice_subsample  1
/////////////////////////////////////////////////////////////////////////////
// CDlg_Show dialog

class CDlg_Show : public CDialog
{
// Construction
public:
	CDlg_Show(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_Show)
	enum { IDD = IDD_DIALOG5 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
public:
	Sample* theSample;
	int AtomeOrSample;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_Show)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_Show)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnSetfocusList1();
	afx_msg void OnSetfocusList2();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnSelchangeList1();
	afx_msg void OnSelchangeList2();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
