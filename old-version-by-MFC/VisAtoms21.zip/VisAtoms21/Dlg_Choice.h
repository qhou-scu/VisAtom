// Dlg_Choice.h : header file
//
#define operate_copyselectedatom    0
#define operate_copysubsample       1
#define operate_copysample          2
/////////////////////////////////////////////////////////////////////////////
// CDlg_Choice dialog
class CDlg_Choice : public CDialog
{
// Construction
public:
	CDlg_Choice(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg_Choice)
	enum { IDD = IDD_DIALOG8 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_Choice)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
     int choice;

protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_Choice)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
