// Dlg_PCorre.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg_PCorre dialog
#include "WndGL_xyFig.h"
#include "Atoms21.h"

class CDlg_PCorre : public CDialog
{
// Construction
public:
	CDlg_PCorre(CWnd* pParent = NULL);   // standard constructor
	~CDlg_PCorre();                      // standard destroy
	// Dialog Data
	//{{AFX_DATA(CDlg_PCorre)
	enum { IDD = IDD_PCORRELATION };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg_PCorre)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg_PCorre)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckx();
	afx_msg void OnChecky();
	afx_msg void OnCheckz();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnButtonStart();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	virtual void OnOK();
	afx_msg void OnChangeEdit2();
	afx_msg void OnDestroy();
	afx_msg void OnExit();
	afx_msg void OnSelchangeAtom1();
	afx_msg void OnSelchangeAtom2();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	CWndGL_xyFig Fig;
    CWinThread*Kernal;
	UINT nIDEvent;

public:
	void ImportSample(Atoms21*);
};
