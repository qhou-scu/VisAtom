#include "VisAtom2017.h"

VisAtom2017::VisAtom2017(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
