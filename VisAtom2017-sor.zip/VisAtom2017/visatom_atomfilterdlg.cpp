#include "visatom_atomfilterdlg.h"
#include "VisAtomDataSheet.h"
#include "VisAtomSample.h"
#include "VisAtomTrajectory.h"

Visatom_AtomfilterDlg::Visatom_AtomfilterDlg(QWidget *parent)
	:QDialog(parent)
{
	ui.setupUi(this);
	
}

Visatom_AtomfilterDlg::~Visatom_AtomfilterDlg()
{

}

