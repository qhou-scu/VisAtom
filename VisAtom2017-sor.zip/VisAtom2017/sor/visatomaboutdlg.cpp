#include "visatomaboutdlg.h"

VisAtomAboutDlg::VisAtomAboutDlg(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

VisAtomAboutDlg::~VisAtomAboutDlg()
{

}
